/* netmap — interface web (Cytoscape.js). Toutes les chaînes venant du réseau
 * (noms DHCP, LLDP...) sont échappées : un nom d'hôte peut être contrôlé par n'importe qui. */
(function () {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const KIND_LABEL = {
    internet: "Internet", router: "Routeur", switch: "Switch", ap: "Point d'accès", hypervisor: "Hyperviseur",
    vm: "VM", ct: "Conteneur", server: "Serveur", nas: "NAS", client: "Client", phone: "Téléphone",
    printer: "Imprimante", tv: "TV", iot: "Objet connecté", management: "Management", unknown: "Inconnu",
    unmanaged: "Non géré (déduit)", "switch-unmanaged": "Switch non géré", "router-unmanaged": "Routeur",
  };
  const KIND_COLOR = {
    internet: "#64748b", router: "#2563eb", switch: "#0891b2", ap: "#7c3aed", hypervisor: "#ea580c",
    vm: "#f97316", ct: "#f59e0b", server: "#16a34a", nas: "#059669", client: "#475569", phone: "#475569",
    printer: "#475569", tv: "#475569", iot: "#0d9488", management: "#0d9488", unknown: "#94a3b8",
    unmanaged: "#a16207", "switch-unmanaged": "#a16207", "router-unmanaged": "#64748b",
  };
  const VIA_LABEL = { lldp: "LLDP", cdp: "CDP", mndp: "MNDP", fdb: "tables MAC", config: "configuration", manual: "lien manuel", proxmox: "Proxmox" };

  // Pictogrammes (24×24, trait) — rendus en SVG data-URI pour Cytoscape
  const GLYPH = {
    internet: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/>',
    router: '<rect x="3" y="12" width="18" height="7" rx="2"/><path d="M7 15.5h.01M11 15.5h.01M8 9l4-4 4 4M12 5v7"/>',
    switch: '<rect x="2" y="7" width="20" height="10" rx="2"/><path d="M6 11v2M9 11v2M12 11v2M15 11v2M18 11v2"/>',
    ap: '<circle cx="12" cy="17" r="1.5"/><path d="M8.5 13.5a5 5 0 0 1 7 0M5.5 10.5a9 9 0 0 1 13 0M2.5 7.5a13 13 0 0 1 19 0"/>',
    hypervisor: '<rect x="3" y="3" width="18" height="6" rx="1.5"/><rect x="3" y="11" width="18" height="6" rx="1.5"/><path d="M7 6h.01M7 14h.01M11 20h2M12 17v3"/>',
    server: '<rect x="4" y="3" width="16" height="7" rx="1.5"/><rect x="4" y="13" width="16" height="7" rx="1.5"/><path d="M8 6.5h.01M8 16.5h.01M12 6.5h4M12 16.5h4"/>',
    nas: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h8"/>',
    vm: '<rect x="3" y="4" width="18" height="15" rx="2"/><path d="M3 8h18M6 6h.01M8.5 6h.01"/>',
    ct: '<path d="M12 3 20 7.5v9L12 21l-8-4.5v-9z"/><path d="M12 12 20 7.5M12 12 4 7.5M12 12v9"/>',
    client: '<rect x="4" y="5" width="16" height="11" rx="1.5"/><path d="M2 19h20"/>',
    phone: '<rect x="7" y="2.5" width="10" height="19" rx="2"/><path d="M11 18.5h2"/>',
    printer: '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
    tv: '<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8"/>',
    iot: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
    management: '<path d="M12 3 4 6v6c0 4.5 3.4 8.2 8 9 4.6-.8 8-4.5 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
    unknown: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6M12 17h.01"/>',
    unmanaged: '<rect x="2" y="7" width="20" height="10" rx="2" stroke-dasharray="3 2"/><path d="M7 12h.01M12 12h.01M17 12h.01"/>',
  };
  GLYPH["switch-unmanaged"] = GLYPH.unmanaged;
  GLYPH["router-unmanaged"] = GLYPH.router;

  function iconURI(kind, color) {
    const g = GLYPH[kind] || GLYPH.unknown;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${g}</svg>`;
    return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
  }

  const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  const fmtDate = (iso) => {
    if (!iso) return "";
    const d = new Date(iso);
    return d.toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
  };
  const isVirtual = (n) => n.kind === "vm" || n.kind === "ct";
  const isClientish = (n) => ["client", "phone", "printer", "tv", "iot"].includes(n.kind);

  let cy = null;
  let graph = null;
  let currentScan = null;
  let positions = {};
  let saveTimer = null;
  const filters = { virtual: true, clients: true, unknown: true, stopped: false, gone: false, ports: false };

  function toast(msg, ms = 2600) {
    const t = $("#toast");
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(() => (t.hidden = true), ms);
  }

  async function api(path, opts) {
    const r = await fetch(path, Object.assign({ headers: { "Content-Type": "application/json" } }, opts));
    if (!r.ok && r.status !== 409) throw new Error(`${path} : HTTP ${r.status}`);
    return r.json();
  }

  // --- style Cytoscape -------------------------------------------------------
  function edgeWidth(e) {
    const s = e.data("speed") || 0;
    if (s >= 10000) return 5;
    if (s >= 2500) return 4;
    if (s >= 1000) return 2.6;
    if (s > 0) return 1.6;
    return 1.6;
  }

  function cyStyle() {
    const surface = css("--surface"), text = css("--text"), muted = css("--muted");
    const edge = css("--edge"), infra = css("--edge-infra"), warn = css("--warn"), bad = css("--bad"), ok = css("--new");
    return [
      { selector: "node", style: {
        "shape": "round-rectangle", "width": 52, "height": 52, "background-color": surface,
        "border-width": 2, "border-color": "data(color)", "background-image": "data(icon)",
        "background-width": "58%", "background-height": "58%", "background-fit": "none", "background-clip": "none",
        "label": "data(label)", "font-size": 11, "color": text, "text-valign": "bottom", "text-halign": "center",
        "text-margin-y": 6, "text-wrap": "wrap", "text-max-width": 116, "min-zoomed-font-size": 6,
        "text-background-color": css("--bg"), "text-background-opacity": 0.75, "text-background-padding": 2,
        "text-background-shape": "round-rectangle",
      } },
      { selector: "node[?managed]", style: { "width": 66, "height": 66, "border-width": 3, "font-size": 12.5, "font-weight": 600 } },
      { selector: 'node[kind="internet"]', style: { "shape": "ellipse", "width": 70, "height": 70 } },
      { selector: 'node[kind="vm"], node[kind="ct"]', style: { "width": 38, "height": 38, "font-size": 10, "text-max-width": 92, "border-width": 1.5 } },
      { selector: 'node[kind="client"], node[kind="phone"], node[kind="unknown"], node[kind="iot"], node[kind="printer"], node[kind="tv"]', style: { "shape": "ellipse", "width": 44, "height": 44 } },
      { selector: 'node[kind="unmanaged"]', style: { "border-style": "dashed" } },
      { selector: 'node[status="unreachable"]', style: { "border-color": bad, "border-style": "double", "border-width": 5 } },
      { selector: 'node[status="stopped"], node[status="offline"]', style: { "opacity": 0.45 } },
      { selector: "node.new", style: { "underlay-color": ok, "underlay-opacity": 0.28, "underlay-padding": 9, "underlay-shape": "round-rectangle" } },
      { selector: "node.gone", style: { "opacity": 0.5, "border-style": "dashed", "border-color": bad } },
      { selector: "node:selected", style: { "border-color": css("--accent"), "border-width": 4, "underlay-color": css("--accent"), "underlay-opacity": 0.18, "underlay-padding": 8 } },
      { selector: "node.dim", style: { "opacity": 0.15 } },
      { selector: "node.hit", style: { "underlay-color": warn, "underlay-opacity": 0.35, "underlay-padding": 10 } },

      { selector: "edge", style: {
        "curve-style": "bezier", "width": edgeWidth, "line-color": edge, "opacity": 0.9,
        "label": "", "font-size": 9.5, "color": muted, "text-rotation": "autorotate",
        "text-background-color": css("--bg"), "text-background-opacity": 0.9, "text-background-padding": 2,
      } },
      { selector: 'edge[kind="infra"], edge[kind="wan"]', style: { "line-color": infra } },
      { selector: 'edge[kind="wan"]', style: { "line-style": "dashed", "line-dash-pattern": [8, 5] } },
      { selector: 'edge[kind="virtual"]', style: { "line-style": "dotted", "width": 1.4 } },
      { selector: 'edge[?inferred][kind != "virtual"]', style: { "opacity": 0.75 } },
      { selector: "edge[?blocked]", style: { "line-color": warn, "line-style": "dashed", "line-dash-pattern": [6, 4], "width": 2 } },
      { selector: "edge.gone", style: { "line-color": bad, "line-style": "dashed", "opacity": 0.5 } },
      { selector: "edge.new", style: { "line-color": ok } },
      { selector: "edge.labels, edge:selected, edge.hover", style: { "label": "data(label)" } },
      { selector: "edge:selected", style: { "line-color": css("--accent"), "opacity": 1 } },
      { selector: "edge.dim", style: { "opacity": 0.08 } },
    ];
  }

  function edgeLabel(l) {
    const parts = l.members.filter((m) => m.source_port || m.target_port)
      .map((m) => (m.source_port && m.target_port ? `${m.source_port} ↔ ${m.target_port}` : m.source_port || m.target_port));
    let s = parts.length > 2 ? `${parts.length} liens` : parts.join(" · ");
    if (l.speed_label) s += (s ? " · " : "") + (l.lag ? `LAG ${l.speed_label}` : l.speed_label);
    if (l.blocked) s += " · bloqué STP";
    return s;
  }

  // --- construction des éléments -----------------------------------------------
  function visible(n) {
    if (n._gone && !filters.gone) return false;
    if (isVirtual(n) && !filters.virtual) return false;
    if (isVirtual(n) && n.status === "stopped" && !filters.stopped) return false;
    if (isClientish(n) && !filters.clients) return false;
    if (n.kind === "unknown" && !filters.unknown) return false;
    return true;
  }

  function elementsFor(g) {
    const diff = g.diff || { new_nodes: [], gone_nodes: [], new_links: [], gone_links: [] };
    const newN = new Set(diff.new_nodes);
    const newL = new Set(diff.new_links);
    let nodes = g.nodes.slice();
    let links = g.links.slice();
    if (filters.gone) {
      const ids = new Set(nodes.map((n) => n.id));
      nodes = nodes.concat(diff.gone_nodes.filter((n) => !ids.has(n.id)).map((n) => Object.assign({}, n, { _gone: true })));
      const all = new Set(nodes.map((n) => n.id));
      links = links.concat(diff.gone_links.filter((l) => all.has(l.source) && all.has(l.target)).map((l) => Object.assign({}, l, { _gone: true })));
    }
    const shown = nodes.filter(visible);
    const ids = new Set(shown.map((n) => n.id));
    const els = [];
    for (const n of shown) {
      const color = KIND_COLOR[n.kind] || KIND_COLOR.unknown;
      els.push({
        group: "nodes",
        // « parent » est réservé par Cytoscape (nœuds composés) : on le renomme
        data: Object.assign({}, n, { parent: undefined, hv: n.parent, color, icon: iconURI(n.kind, color), label: n.label }),
        classes: [n._gone ? "gone" : "", newN.has(n.id) ? "new" : ""].join(" ").trim(),
      });
    }
    for (const l of links) {
      if (!ids.has(l.source) || !ids.has(l.target)) continue;
      els.push({
        group: "edges",
        data: Object.assign({}, l, { label: edgeLabel(l) }),
        classes: [l._gone ? "gone" : "", newL.has(l.id) ? "new" : "", filters.ports ? "labels" : ""].join(" ").trim(),
      });
    }
    return els;
  }

  function render(keepView) {
    if (!graph) return;
    const view = cy && keepView ? { zoom: cy.zoom(), pan: cy.pan() } : null;
    const auto = window.NetmapLayout.compute({ nodes: graph.nodes, links: graph.links }).positions;
    const els = elementsFor(graph);
    for (const el of els) {
      if (el.group !== "nodes") continue;
      const p = positions[el.data.id] || auto[el.data.id];
      el.position = p ? { x: p.x, y: p.y } : { x: 0, y: -200 };
    }
    if (!cy) {
      cy = cytoscape({
        container: $("#cy"), elements: els, layout: { name: "preset" }, style: cyStyle(),
        minZoom: 0.1, maxZoom: 3, boxSelectionEnabled: false,
      });
      bindCy();
    } else {
      cy.batch(() => {
        cy.elements().remove();
        cy.add(els);
      });
    }
    if (view) cy.viewport(view);
    else cy.fit(undefined, innerWidth < 720 ? 16 : 60);
    applySearch();
  }

  function bindCy() {
    cy.on("tap", "node", (ev) => showNode(ev.target.id()));
    cy.on("tap", "edge", (ev) => showEdge(ev.target.id()));
    cy.on("tap", (ev) => { if (ev.target === cy) closePanel(); });
    cy.on("mouseover", "edge", (ev) => ev.target.addClass("hover"));
    cy.on("mouseout", "edge", (ev) => ev.target.removeClass("hover"));
    cy.on("dragfree", "node", (ev) => {
      // on déplace aussi les VM d'un hyperviseur ? non : chaque nœud est libre
      const n = ev.target;
      positions[n.id()] = Object.assign({}, n.position());
      clearTimeout(saveTimer);
      const batch = {};
      cy.nodes().forEach((x) => { if (positions[x.id()]) batch[x.id()] = positions[x.id()]; });
      saveTimer = setTimeout(() => api("/api/positions", { method: "PUT", body: JSON.stringify(batch) }).catch(() => toast("Position non enregistrée")), 500);
    });
  }

  // --- panneau de détail ----------------------------------------------------------
  const nodeById = (id) => graph.nodes.find((n) => n.id === id) || (graph.diff?.gone_nodes || []).find((n) => n.id === id);
  const labelOf = (id) => nodeById(id)?.label ?? id;

  function openPanel(html) {
    $("#panelBody").innerHTML = html;
    $("#panel").hidden = false;
    $("#panelBody").querySelectorAll("[data-goto]").forEach((a) => a.addEventListener("click", () => focusNode(a.dataset.goto)));
  }
  function closePanel() {
    $("#panel").hidden = true;
    cy && cy.elements().unselect();
  }

  function focusNode(id) {
    const n = cy.getElementById(id);
    if (!n.length) { showNode(id); return; }
    cy.elements().unselect();
    n.select();
    cy.animate({ center: { eles: n }, zoom: Math.max(cy.zoom(), 1) }, { duration: 350 });
    showNode(id);
  }

  const kv = (rows) => "<dl class='kv'>" + rows.filter((r) => r[1] !== undefined && r[1] !== null && r[1] !== "" && !(Array.isArray(r[1]) && !r[1].length))
    .map(([k, v, raw]) => `<dt>${esc(k)}</dt><dd>${raw ? v : esc(Array.isArray(v) ? v.join(", ") : v)}</dd>`).join("") + "</dl>";
  const goto = (id, text) => `<a class="link" data-goto="${esc(id)}">${esc(text ?? labelOf(id))}</a>`;

  function connections(n) {
    const rows = [];
    for (const l of graph.links) {
      if (l.source !== n.id && l.target !== n.id) continue;
      const other = l.source === n.id ? l.target : l.source;
      const ports = l.members.map((m) => {
        const mine = l.source === n.id ? m.source_port : m.target_port;
        const theirs = l.source === n.id ? m.target_port : m.source_port;
        if (mine && theirs) return `<span class="mono">${esc(mine)} ↔ ${esc(theirs)}</span>`;
        if (theirs) return `port <span class="mono">${esc(theirs)}</span>`;
        if (mine) return `via <span class="mono">${esc(mine)}</span>`;
        return "";
      }).filter(Boolean).join("<br>");
      const flags = [l.speed_label && (l.lag ? `LAG ${l.speed_label}` : l.speed_label), l.blocked && "bloqué STP", l.inferred && "déduit"].filter(Boolean);
      rows.push(`<li>${goto(other)} ${flags.map((f) => `<span class="badge${f === "bloqué STP" ? " warn" : ""}">${esc(f)}</span>`).join("")}${ports ? "<br>" + ports : ""}</li>`);
    }
    return rows.length ? `<ul class="plain">${rows.join("")}</ul>` : "<p class='scaninfo'>Aucun lien</p>";
  }

  function showNode(id) {
    const n = nodeById(id);
    if (!n) return;
    const color = KIND_COLOR[n.kind] || KIND_COLOR.unknown;
    const status = n._gone ? `<span class="badge bad">disparu</span>`
      : n.status === "unreachable" ? `<span class="badge bad">injoignable</span>`
      : n.status === "stopped" ? `<span class="badge">arrêtée</span>`
      : (graph.diff?.new_nodes || []).includes(n.id) ? `<span class="badge ok">nouveau</span>` : "";
    let html = `<div class="head"><img alt="" src="${iconURI(n.kind, color)}"><div><h2>${esc(n.label)}</h2>
      <span class="badge">${esc(KIND_LABEL[n.kind] || n.kind)}</span>${status}${n.random_mac ? '<span class="badge">MAC aléatoire</span>' : ""}</div></div>`;
    html += "<h3>Informations</h3>" + kv([
      ["IP", n.ips && n.ips.length ? n.ips : n.ip],
      ["MAC", (n.macs || []).map((m) => `<span class="mono">${esc(m)}</span>`).join("<br>"), true],
      ["Fabricant", n.vendor],
      ["Modèle", n.model],
      ["Version", n.version],
      ["Série", n.serial],
      ["Plateforme", n.platform],
      ["VLAN", n.vlans],
      ["Réseau", n.subnet],
      ["Hyperviseur", n.parent ? goto(n.parent) : null, true],
      ["VMID", n.guest ? n.guest.vmid : null],
      ["Note", n.note],
      ["Scan", n.duration_s != null ? `${n.duration_s} s` : null],
    ]);
    const names = n.names ? Object.entries(n.names) : [];
    if (names.length > 1) html += "<h3>Noms connus</h3>" + kv(names.map(([k, v]) => [k, v]));
    if (n.errors && n.errors.length) html += "<h3>Erreurs de collecte</h3>" + n.errors.map((e) => `<div class="err">${esc(e)}</div>`).join("");

    if (n.ports && n.ports.length) {
      const rows = n.ports.map((p) => {
        const peers = p.peers.map((x) => `${goto(x.node, x.label)}${x.port ? ` <span class="mono">${esc(x.port)}</span>` : ""}`).join("<br>");
        const dot = p.stp_blocked ? "blocked" : p.up ? "up" : "";
        const extra = [p.bond && `→ ${p.bond}`, p.members && p.members.length && `(${p.members.join(", ")})`, p.pvid && `PVID ${p.pvid}`].filter(Boolean).join(" ");
        const info = peers || (p.fdb_count ? `<span class="scaninfo">${p.fdb_count} MAC</span>` : "") || esc(p.alias || "");
        return `<tr class="${p.up ? "" : "down"}"><td><span class="dot ${dot}"></span><span class="mono">${esc(p.name)}</span>${extra ? `<br><span class="scaninfo">${esc(extra)}</span>` : ""}</td>
          <td>${esc(p.speed || (p.up ? "" : "—"))}${p.uplink ? ' <span class="badge">uplink</span>' : ""}</td><td>${info}</td></tr>`;
      }).join("");
      html += `<h3>Ports</h3><table class="ports"><thead><tr><th>Port</th><th>Vitesse</th><th>Connecté à</th></tr></thead><tbody>${rows}</tbody></table>`;
    } else {
      html += "<h3>Connexions</h3>" + connections(n);
    }
    if (n.kind === "hypervisor") {
      const guests = graph.nodes.filter((g) => g.parent === n.id).sort((a, b) => (a.guest?.vmid || 0) - (b.guest?.vmid || 0));
      if (guests.length) {
        html += "<h3>VM et conteneurs</h3><ul class='plain'>" + guests.map((g) =>
          `<li>${goto(g.id)} <span class="badge">${esc(g.kind === "ct" ? "CT" : "VM")} ${esc(g.guest?.vmid ?? "")}</span>${g.status === "stopped" ? '<span class="badge">arrêtée</span>' : ""}${g.ip ? ` <span class="mono">${esc(g.ip)}</span>` : ""}</li>`).join("") + "</ul>";
      }
    }
    openPanel(html);
  }

  function showEdge(id) {
    const l = graph.links.find((x) => x.id === id) || (graph.diff?.gone_links || []).find((x) => x.id === id);
    if (!l) return;
    let html = `<h2>${goto(l.source)} ↔ ${goto(l.target)}</h2>`;
    html += `<span class="badge">${esc({ infra: "Inter-équipements", access: "Accès", virtual: "Virtuel", wan: "WAN" }[l.kind] || l.kind)}</span>`;
    if (l.lag) html += '<span class="badge">LAG</span>';
    if (l.blocked) html += '<span class="badge warn">Bloqué par STP</span>';
    else if (l.partially_blocked) html += '<span class="badge warn">Partiellement bloqué</span>';
    html += "<h3>Détail</h3>" + kv([
      ["Débit", l.speed_label],
      ["Découvert par", l.via.map((v) => VIA_LABEL[v] || v)],
      ["Fiabilité", l.inferred ? "déduit des tables MAC (pas de LLDP sur ce lien)" : "constaté"],
    ]);
    const rows = l.members.map((m) => `<tr><td class="mono">${esc(m.source_port || "?")}</td><td class="mono">${esc(m.target_port || "?")}</td><td>${esc(m.speed ? (m.speed >= 1000 ? m.speed / 1000 + "G" : m.speed + "M") : "")}${m.blocked ? ' <span class="badge warn">STP</span>' : ""}</td></tr>`).join("");
    html += `<h3>Membres</h3><table class="ports"><thead><tr><th>${esc(labelOf(l.source))}</th><th>${esc(labelOf(l.target))}</th><th>Débit</th></tr></thead><tbody>${rows}</tbody></table>`;
    openPanel(html);
  }

  function showDiff() {
    const d = graph.diff;
    if (!d) return;
    const li = (arr, fn) => arr.length ? `<ul class="plain">${arr.map(fn).join("")}</ul>` : "<p class='scaninfo'>Aucun</p>";
    let html = `<h2>Changements</h2><p class="scaninfo">Depuis le scan du ${esc(fmtDate(d.since))}</p>`;
    html += "<h3>Nouveaux</h3>" + li(d.new_nodes, (id) => `<li>${goto(id)}</li>`);
    html += "<h3>Disparus</h3>" + li(d.gone_nodes, (n) => `<li>${esc(n.label)} <span class="badge">${esc(KIND_LABEL[n.kind] || n.kind)}</span>${n.ip ? ` <span class="mono">${esc(n.ip)}</span>` : ""}</li>`);
    html += "<h3>Déplacés</h3>" + li(d.moved, (m) => `<li>${goto(m.id, m.label)}<br><span class="mono">${esc(m.from.join(", "))} → ${esc(m.to.join(", "))}</span></li>`);
    if (d.gone_nodes.length) html += `<p><a class="link" id="showGone">Afficher les disparus sur le schéma</a></p>`;
    openPanel(html);
    const sg = $("#showGone");
    if (sg) sg.addEventListener("click", () => { setFilter("gone", true); });
  }

  // --- recherche -------------------------------------------------------------
  function applySearch() {
    if (!cy) return;
    const q = $("#search").value.trim().toLowerCase();
    cy.batch(() => {
      cy.elements().removeClass("dim hit");
      if (!q) return;
      const hits = cy.nodes().filter((n) => {
        const d = n.data();
        return [d.label, d.ip, ...(d.ips || []), ...(d.macs || []), d.model, d.vendor].some((v) => v && String(v).toLowerCase().includes(q));
      });
      cy.elements().not(hits).not(hits.connectedEdges()).addClass("dim");
      hits.addClass("hit");
    });
  }

  // --- données ----------------------------------------------------------------------
  async function loadScans() {
    try {
      const scans = await api("/api/scans");
      const sel = $("#history");
      sel.innerHTML = scans.map((s, i) => `<option value="${s.id}">${i === 0 ? "Dernier · " : ""}${esc(fmtDate(s.ts))} · ${s.nodes} nœuds${s.errors ? " ⚠" : ""}</option>`).join("");
      sel.hidden = scans.length < 2;
      if (currentScan) sel.value = String(currentScan);
    } catch (e) { /* silencieux */ }
  }

  async function loadGraph(scanId, keepView) {
    const g = await api("/api/graph" + (scanId ? `?scan=${scanId}` : ""));
    if (g.empty) {
      $("#empty").hidden = false;
      $("#scaninfo").textContent = "Aucun scan";
      if (g.status && g.status.running) watchScan();
      return;
    }
    $("#empty").hidden = true;
    graph = g;
    currentScan = g.scan_id;
    positions = g.positions || {};
    const st = g.stats;
    const errs = Object.keys(g.errors || {}).length;
    $("#scaninfo").innerHTML = `Scan du ${esc(fmtDate(g.ts))}${g.duration_s ? ` · ${esc(g.duration_s)} s` : ""} · ${st.nodes} nœuds · ${st.links} liens` +
      (st.unreachable.length ? ` · <span class="err">${st.unreachable.length} injoignable(s)</span>` : "") +
      (errs ? ` · <span title="Voir le détail des équipements">${errs} avertissement(s)</span>` : "");
    const d = g.diff;
    const badge = $("#diffBadge");
    if (d && (d.new_nodes.length || d.gone_nodes.length || d.moved.length)) {
      badge.hidden = false;
      badge.textContent = `+${d.new_nodes.length} · −${d.gone_nodes.length}${d.moved.length ? ` · ${d.moved.length} déplacé(s)` : ""}`;
      badge.classList.toggle("has-gone", d.gone_nodes.length > 0);
    } else badge.hidden = true;
    render(keepView);
    renderLegend();
    if (g.status && g.status.running) watchScan();
  }

  function renderLegend() {
    $("#legend").innerHTML = `
      <span><span class="sw infra"></span>Inter-équipements</span><span><span class="sw"></span>Accès</span>
      <span><span class="sw blocked"></span>Bloqué (STP)</span><span><span class="sw virtual"></span>Virtuel (VM)</span>
      <span><span class="sw inferred"></span>Déduit (tables MAC)</span><span>Épaisseur = débit</span>`;
  }

  let watching = false;
  async function watchScan() {
    if (watching) return;
    watching = true;
    const btn = $("#btnScan");
    btn.disabled = true;
    btn.classList.add("spinning");
    btn.querySelector("span").textContent = "Scan…";
    try {
      for (;;) {
        await new Promise((r) => setTimeout(r, 1500));
        const s = await api("/api/status");
        if (!s.running) {
          if (s.last_error) toast("Scan en échec : " + s.last_error, 6000);
          else toast(`Scan terminé en ${s.last_duration} s`);
          currentScan = null;
          await loadGraph(null, true);
          await loadScans();
          break;
        }
      }
    } catch (e) {
      toast(String(e));
    } finally {
      watching = false;
      btn.disabled = false;
      btn.classList.remove("spinning");
      btn.querySelector("span").textContent = "Scanner";
    }
  }

  function setFilter(name, value) {
    filters[name] = value;
    const box = document.querySelector(`[data-filter="${name}"]`);
    if (box) box.checked = value;
    try { localStorage.setItem("netmap.filters", JSON.stringify(filters)); } catch (e) { /* stockage indisponible */ }
    if (name === "ports") cy && cy.edges().toggleClass("labels", value);
    else render(true);
  }

  function download(name, href) {
    const a = document.createElement("a");
    a.href = href; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
  }

  function applyTheme(t) {
    if (t) document.documentElement.dataset.theme = t;
    else delete document.documentElement.dataset.theme;
    if (cy) { cy.style(cyStyle()); }
  }

  // --- initialisation ---------------------------------------------------------------
  function init() {
    if (typeof cytoscape === "undefined") {
      $("#scaninfo").innerHTML = '<span class="err">Cytoscape.js introuvable : connexion Internet requise, ou lance <code>netmap fetch-assets</code>.</span>';
      return;
    }
    try {
      Object.assign(filters, JSON.parse(localStorage.getItem("netmap.filters") || "{}"));
      const t = localStorage.getItem("netmap.theme");
      if (t) applyTheme(t);
    } catch (e) { /* stockage indisponible */ }
    document.querySelectorAll("[data-filter]").forEach((box) => {
      box.checked = !!filters[box.dataset.filter];
      box.addEventListener("change", () => setFilter(box.dataset.filter, box.checked));
    });
    $("#btnScan").addEventListener("click", async () => {
      try {
        const r = await api("/api/scan", { method: "POST" });
        if (!r.started) toast("Un scan est déjà en cours");
        watchScan();
      } catch (e) { toast(String(e)); }
    });
    $("#history").addEventListener("change", (e) => loadGraph(e.target.value, true));
    $("#diffBadge").addEventListener("click", showDiff);
    $("#panelClose").addEventListener("click", closePanel);
    $("#search").addEventListener("input", applySearch);
    $("#search").addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || !cy) return;
      const hit = cy.nodes(".hit")[0];
      if (hit) focusNode(hit.id());
    });
    const pop = $("#menuPop");
    $("#btnMenu").addEventListener("click", (e) => { e.stopPropagation(); pop.hidden = !pop.hidden; });
    document.addEventListener("click", () => (pop.hidden = true));
    pop.addEventListener("click", async (e) => {
      const act = e.target.dataset.act;
      if (!act) return;
      if (act === "relayout") {
        await api("/api/positions", { method: "DELETE" });
        positions = {};
        render(false);
      } else if (act === "fit") {
        cy && cy.fit(undefined, 40);
      } else if (act === "png") {
        download("topologie.png", cy.png({ full: true, scale: 2, bg: css("--bg") }));
      } else if (act === "dot") {
        download("topologie.dot", `/api/export/${currentScan || "latest"}.dot`);
      } else if (act === "json") {
        download(`netmap-scan-${currentScan}.json`, `/api/raw/${currentScan}`);
      } else if (act === "theme") {
        const dark = document.documentElement.dataset.theme
          ? document.documentElement.dataset.theme === "dark"
          : matchMedia("(prefers-color-scheme: dark)").matches;
        const next = dark ? "light" : "dark";
        applyTheme(next);
        try { localStorage.setItem("netmap.theme", next); } catch (err) { /* stockage indisponible */ }
      }
    });
    matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => cy && cy.style(cyStyle()));
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closePanel();
      if (e.key === "/" && document.activeElement !== $("#search")) { e.preventDefault(); $("#search").focus(); }
    });
    loadGraph().then(loadScans).catch((e) => ($("#scaninfo").textContent = String(e)));
  }

  init();
})();
