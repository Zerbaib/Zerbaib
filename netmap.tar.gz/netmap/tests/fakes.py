"""Faux équipements pour les tests : routeur RouterOS (API TCP) et agent SNMP (UDP)."""

from __future__ import annotations

import socket
import threading

from netmap import snmp as S
from netmap.ros_api import encode_word


# --- RouterOS -------------------------------------------------------------------

class FakeRouterOS:
    """Serveur API RouterOS minimal. `menus` = {'/ip/neighbor': [ {...}, ... ]}."""

    def __init__(self, menus: dict, user="netmap", password="secret", monitor=None):
        self.menus = menus
        self.user = user
        self.password = password
        self.monitor = monitor or {}
        self.commands: list[list[str]] = []
        self.sock = socket.socket()
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(4)
        self.port = self.sock.getsockname()[1]
        threading.Thread(target=self._serve, daemon=True).start()

    def close(self):
        self.sock.close()

    def _serve(self):
        while True:
            try:
                conn, _ = self.sock.accept()
            except OSError:
                return
            threading.Thread(target=self._client, args=(conn,), daemon=True).start()

    @staticmethod
    def _read_len(f):
        b = f.read(1)
        if not b:
            raise EOFError
        b = b[0]
        if b < 0x80:
            return b
        if b < 0xC0:
            return ((b & 0x3F) << 8) | f.read(1)[0]
        if b < 0xE0:
            return ((b & 0x1F) << 16) | int.from_bytes(f.read(2), "big")
        if b < 0xF0:
            return ((b & 0x0F) << 24) | int.from_bytes(f.read(3), "big")
        return int.from_bytes(f.read(4), "big")

    def _sentence(self, f):
        words = []
        while True:
            n = self._read_len(f)
            if n == 0:
                return words
            words.append(f.read(n).decode())

    def _send(self, conn, *words):
        conn.sendall(b"".join(encode_word(w) for w in words) + b"\x00")

    def _client(self, conn):
        f = conn.makefile("rb")
        authed = False
        try:
            while True:
                words = self._sentence(f)
                if not words:
                    continue
                self.commands.append(words)
                cmd = words[0]
                attrs = dict(w[1:].split("=", 1) for w in words[1:] if w.startswith("="))
                if cmd == "/login":
                    if attrs.get("name") == self.user and attrs.get("password") == self.password:
                        authed = True
                        self._send(conn, "!done")
                    else:
                        self._send(conn, "!trap", "=message=invalid user name or password (6)")
                        self._send(conn, "!done")
                    continue
                if not authed:
                    self._send(conn, "!fatal", "not logged in")
                    return
                if cmd == "/interface/ethernet/monitor":
                    for name in attrs.get("numbers", "").split(","):
                        if name in self.monitor:
                            self._send(conn, "!re", f"=name={name}", f"=rate={self.monitor[name]}", "=status=link-ok")
                    self._send(conn, "!done")
                    continue
                if cmd.endswith("/print"):
                    menu = cmd[: -len("/print")]
                    if menu not in self.menus:
                        self._send(conn, "!trap", "=message=no such command prefix")
                        self._send(conn, "!done")
                        continue
                    rows = self.menus[menu]
                    if not rows:
                        self._send(conn, "!empty")
                    for i, row in enumerate(rows):
                        self._send(conn, "!re", f"=.id=*{i:X}", *(f"={k}={v}" for k, v in row.items()))
                    self._send(conn, "!done")
                    continue
                self._send(conn, "!trap", "=message=no such command")
                self._send(conn, "!done")
        except (EOFError, OSError, IndexError):
            pass
        finally:
            conn.close()


# --- SNMP -------------------------------------------------------------------------

class Gauge(int):
    pass


class Counter(int):
    pass


def _enc_value(v) -> bytes:
    if v is None:
        return S._tlv(S.NULL, b"")
    if isinstance(v, Gauge):
        return S._tlv(S.GAUGE32, int(v).to_bytes(max(1, (int(v).bit_length() + 8) // 8), "big"))
    if isinstance(v, Counter):
        return S._tlv(S.COUNTER32, int(v).to_bytes(max(1, (int(v).bit_length() + 8) // 8), "big"))
    if isinstance(v, bool):
        v = int(v)
    if isinstance(v, int):
        return S._enc_int(v)
    if isinstance(v, str):
        return S._tlv(S.OCTET_STRING, v.encode())
    if isinstance(v, bytes):
        return S._tlv(S.OCTET_STRING, v)
    if isinstance(v, tuple):
        return S._enc_oid(v)
    raise TypeError(v)


class FakeSnmpAgent:
    """Agent SNMP v1/v2c en mémoire : `data` = {oid_tuple: valeur}."""

    def __init__(self, data: dict, community="public", versions=("1", "2c")):
        self.data = {S.parse_oid(k): v for k, v in data.items()}
        self.oids = sorted(self.data)
        self.community = community
        self.versions = {0 if v == "1" else 1 for v in versions}
        self.requests = 0
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("127.0.0.1", 0))
        self.port = self.sock.getsockname()[1]
        threading.Thread(target=self._serve, daemon=True).start()

    def close(self):
        self.sock.close()

    def _next(self, oid):
        for o in self.oids:
            if o > oid:
                return o
        return None

    def _serve(self):
        while True:
            try:
                pkt, addr = self.sock.recvfrom(65535)
            except OSError:
                return
            try:
                resp = self._handle(pkt)
            except Exception:  # paquet invalide : ignoré, comme un vrai agent
                continue
            if resp:
                self.sock.sendto(resp, addr)

    def _handle(self, pkt: bytes) -> bytes | None:
        self.requests += 1
        _, msg, _ = S._dec_tlv(pkt, 0)
        _, ver, p = S._dec_tlv(msg, 0)
        _, comm, p = S._dec_tlv(msg, p)
        ptype, pdu, _ = S._dec_tlv(msg, p)
        version = int.from_bytes(ver, "big")
        if comm.decode() != self.community or version not in self.versions:
            return None  # comme un vrai agent : silence
        _, rid, q = S._dec_tlv(pdu, 0)
        _, a, q = S._dec_tlv(pdu, q)
        _, b, q = S._dec_tlv(pdu, q)
        _, vbl, _ = S._dec_tlv(pdu, q)
        oids = []
        p = 0
        while p < len(vbl):
            _, vb, p = S._dec_tlv(vbl, p)
            _, ob, _ = S._dec_tlv(vb, 0)
            oids.append(S._dec_oid(ob))
        out = []
        err = 0
        if ptype == S.GET:
            for o in oids:
                if o in self.data:
                    out.append((o, _enc_value(self.data[o])))
                elif version == 0:
                    err = 2
                    out.append((o, _enc_value(None)))
                else:
                    out.append((o, S._tlv(S.NO_SUCH_OBJECT, b"")))
        elif ptype == S.GETNEXT:
            for o in oids:
                n = self._next(o)
                if n is None:
                    if version == 0:
                        err = 2
                        out.append((o, _enc_value(None)))
                    else:
                        out.append((o, S._tlv(S.END_OF_MIB, b"")))
                else:
                    out.append((n, _enc_value(self.data[n])))
        elif ptype == S.GETBULK:
            if version == 0:
                return None
            max_rep = int.from_bytes(b, "big")
            cur = oids[0]
            for _ in range(max_rep):
                n = self._next(cur)
                if n is None:
                    out.append((cur, S._tlv(S.END_OF_MIB, b"")))
                    break
                out.append((n, _enc_value(self.data[n])))
                cur = n
        vbs = b"".join(S._tlv(S.SEQUENCE, S._enc_oid(o) + v) for o, v in out)
        rpdu = S._tlv(S.RESPONSE, S._tlv(S.INTEGER, rid) + S._enc_int(err) + S._enc_int(1 if err else 0) + S._tlv(S.SEQUENCE, vbs))
        return S._tlv(S.SEQUENCE, S._enc_int(version) + S._tlv(S.OCTET_STRING, comm) + rpdu)


def mac_index(mac: str) -> tuple[int, ...]:
    return tuple(int(x, 16) for x in mac.split(":"))


def mac_bytes(mac: str) -> bytes:
    return bytes(mac_index(mac))
