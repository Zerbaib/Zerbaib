# netmap

Topologie réseau automatique façon UniFi pour un homelab **MikroTik (RouterOS / SwOS) + switchs SNMP + Proxmox**.

netmap interroge tes routeurs et switchs, récupère leurs voisins (LLDP / CDP / MNDP) et leurs tables MAC, croise tout avec l'ARP, le DHCP et Proxmox, puis dessine le schéma : Internet → routeurs → switchs → serveurs, VM et clients, avec les ports et les débits sur chaque lien.

![Aperçu](docs/apercu.png)

- **Aucune dépendance** : Python 3.11+ standard uniquement (Debian 13 : rien à installer). Client API RouterOS, client SNMP et serveur web sont intégrés.
- **Interface web** : schéma interactif, vue « ports » de chaque switch, recherche (nom / IP / MAC), historique des scans, changements depuis le scan précédent, export PNG / Graphviz / JSON, thème clair et sombre, utilisable sur mobile.
- **Lecture seule** partout : utilisateur API RouterOS sans droit d'écriture, SNMP en lecture, jeton Proxmox `PVEAuditor`.

![Vue ports](docs/apercu-ports.png)

## Démarrage rapide

```bash
# Voir l'interface sur des données de démonstration (aucun matériel requis)
python3 -m netmap demo --serve          # http://127.0.0.1:8650

# Sur ton réseau
cp config.example.toml netmap.toml      # puis adapter IP / identifiants
python3 -m netmap check                  # teste chaque équipement un par un
python3 -m netmap scan                   # scan + schéma en texte dans le terminal
python3 -m netmap serve --scan           # interface web
```

## Comment les liens sont trouvés

| Étape | Source | Fiabilité |
|---|---|---|
| 1 | **LLDP / CDP** (RouterOS, Netgear, Proxmox avec `lldpd`) | Lien direct certain, ports exacts des deux côtés |
| 2 | **Tables MAC** : S:P et D:Q sont reliés si ce que S voit derrière P et ce que D voit derrière Q sont disjoints et couvrent tout le réseau | Fiable, marqué « déduit » |
| 3 | **MNDP** (broadcast, traverse les switchs) | Utilisé seulement s'il est sans ambiguïté sur le port |
| 4 | **Config** : port WAN, liens `[[link]]` forcés | Manuel |

Ensuite chaque MAC apprise sur un **port d'accès** (non-uplink) devient un appareil, nommé par Proxmox, le bail DHCP, LLDP, MNDP ou le DNS inverse, et typé selon son sous-réseau (`[[subnet]]`). Plusieurs appareils sur un même port font apparaître un **switch / AP non géré** déduit. Si un voisin LLDP de type AP est sur le port, ses clients Wi-Fi sont rangés derrière lui. Les VM et CT Proxmox sont rattachés à leur hyperviseur. Le lien redondant bloqué par **STP/RSTP** est affiché en pointillé orange.

### Cas du CSS326 (SwOS)

SwOS ne gère **ni LLDP ni Q-BRIDGE** : seulement SNMP v1/v2c avec IF-MIB et BRIDGE-MIB. Il se déclare donc en `type = "snmp"`. Ses liens sont retrouvés par les tables MAC (étape 2) et par le MNDP vu des routeurs. Dans SwOS, active SNMP (onglet SNMP) et « Mikrotik Discovery Protocol » (onglet System). Quand les CRS328 arriveront, passe-les en `type = "routeros"`.

## Préparer les équipements

**RouterOS v7** (routeurs, futurs CRS328) : utilisateur API en lecture seule, limité à l'IP du serveur netmap.

```routeros
/user group add name=netmap policy=read,api
/user add name=netmap group=netmap password="..." address=192.168.255.10/32
/ip service set api address=192.168.255.0/26
/ip neighbor discovery-settings set discover-interface-list=all protocol=cdp,lldp,mndp
```

Pour l'API chiffrée : `/ip service enable api-ssl`, puis `tls = true` (et `tls_verify = false` si le certificat est auto-signé) dans la config.

**Netgear GS724T** : activer SNMP v2c avec une communauté en lecture seule, restreinte à l'IP de netmap, et activer LLDP (System › LLDP).

**Proxmox** : jeton en lecture seule.

```bash
pveum user add netmap@pve
pveum aclmod / -user netmap@pve -role PVEAuditor
pveum user token add netmap@pve topo --privsep 0
```

Astuce : `apt install lldpd` sur chaque nœud Proxmox. Les switchs voient alors le nom exact du serveur et de sa carte réseau sur chaque port, ce qui fiabilise les serveurs à deux cartes.

## Installation en service (Debian 13, LXC conseillé dans le VLAN management)

```bash
sudo useradd --system --home /var/lib/netmap --shell /usr/sbin/nologin netmap
sudo mkdir -p /opt/netmap /etc/netmap
sudo cp -r netmap README.md /opt/netmap/
sudo cp config.example.toml /etc/netmap/netmap.toml
sudo install -m 600 systemd/netmap.env.example /etc/netmap/netmap.env   # secrets
sudo cp systemd/netmap.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now netmap
journalctl -u netmap -f
```

Le service sert l'interface sur le port 8650 et relance un scan toutes les `scan_interval` secondes. Cytoscape.js est livré dans `netmap/web/vendor/`, donc l'interface fonctionne sans Internet.

## Commandes

| Commande | Rôle |
|---|---|
| `netmap check [R1 SW1] [-p]` | Interroge les équipements un par un : voisins, nombre de MAC, erreurs, détail par port avec `-p` |
| `netmap scan [--dump brut.json] [--json]` | Scanne, enregistre, affiche l'arbre et les changements |
| `netmap serve [--scan] [--host] [--port]` | Interface web + scans périodiques |
| `netmap build brut.json` | Rejoue un scan brut hors ligne, utile pour déboguer |
| `netmap export --format text\|json\|dot` | Exporte le dernier scan (Graphviz : `dot -Tsvg`) |
| `netmap demo [--serve]` | Démo sur un réseau simulé |

## API

`GET /api/graph[?scan=ID]` · `GET /api/scans` · `POST /api/scan` · `GET /api/status` · `PUT|DELETE /api/positions` · `GET /api/raw/ID` · `GET /api/export/ID.dot`

## Tests

```bash
python3 -m unittest discover -s tests -t .
```

Les tests utilisent un faux routeur qui parle le vrai protocole API RouterOS, un faux agent SNMP v1/v2c avec un vrai encodage BER (profils Netgear et SwOS), une API Proxmox simulée, et le réseau de démonstration complet : STP, MNDP traversant les switchs, AP Wi-Fi, switch de bureau non géré, hyperviseurs à deux cartes.

## Limites connues

- SNMP v3 non géré (v1/v2c seulement) : le limiter au VLAN management.
- Un appareil silencieux (MAC expirée des tables, ~5 min) n'apparaît pas tant qu'il n'émet pas.
- Les clients Wi-Fi d'un AP non MikroTik sans LLDP sont regroupés sous un « équipement non géré ».
