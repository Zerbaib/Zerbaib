"""Collecteurs : interrogent les équipements et renvoient des données brutes (netmap.model)."""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from ..config import Config, DeviceConfig
from ..model import DeviceData, HypervisorData, RawScan
from ..util import log


def collect_device(dc: DeviceConfig) -> DeviceData:
    start = time.monotonic()
    try:
        if dc.type == "routeros":
            from .routeros import collect
        else:
            from .snmp_switch import collect
        data = collect(dc)
    except Exception as e:  # un équipement injoignable ne doit pas bloquer le scan
        log.warning("%s (%s) : %s", dc.name, dc.host, e)
        data = DeviceData(id=dc.name, host=dc.host, platform=dc.type, role=dc.role,
                          label=dc.label, wan_port=dc.wan_port, reachable=False,
                          errors=[f"{type(e).__name__}: {e}"])
    data.duration_s = round(time.monotonic() - start, 2)
    return data


def scan(cfg: Config) -> RawScan:
    start = time.monotonic()
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with ThreadPoolExecutor(max_workers=max(1, cfg.parallel)) as pool:
        dev_futures = [pool.submit(collect_device, d) for d in cfg.devices]
        hv_futures = []
        if cfg.proxmox:
            from .proxmox import collect as collect_px
            for px in cfg.proxmox:
                hv_futures.append((px, pool.submit(collect_px, px)))
        devices = [f.result() for f in dev_futures]
        hypervisors: list[HypervisorData] = []
        for px, f in hv_futures:
            try:
                hypervisors.append(f.result())
            except Exception as e:
                log.warning("Proxmox %s : %s", px.host, e)
                hypervisors.append(HypervisorData(cluster=px.host, errors=[f"{type(e).__name__}: {e}"]))
    return RawScan(ts=ts, devices=devices, hypervisors=hypervisors,
                   duration_s=round(time.monotonic() - start, 2))
