"""Ligne de commande : netmap scan | serve | build | check | export | demo | fetch-assets."""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path

from . import __version__
from .config import ConfigError, load
from .util import log

DEFAULT_PATHS = ("netmap.toml", "/etc/netmap/netmap.toml")


def _find_config(path: str | None) -> str:
    if path:
        return path
    env = os.environ.get("NETMAP_CONFIG")
    if env:
        return env
    for p in DEFAULT_PATHS:
        if Path(p).is_file():
            return p
    raise ConfigError("Aucun fichier de configuration (-c, $NETMAP_CONFIG, ./netmap.toml ou /etc/netmap/netmap.toml)")


def _scan_and_store(cfg, store, dump: str | None = None) -> int:
    from .collectors import scan
    from .topology import build

    raw = scan(cfg)
    raw_dict = raw.to_dict()
    if dump:
        Path(dump).write_text(json.dumps(raw_dict, indent=2, ensure_ascii=False))
    graph = build(raw, cfg)
    return store.save_scan(raw_dict, graph, cfg.retention)


def _print_report(graph: dict) -> None:
    from .topology import text_tree

    print(text_tree(graph))
    st = graph["stats"]
    kinds = ", ".join(f"{v} {k}" for k, v in sorted(st["by_kind"].items(), key=lambda x: -x[1]))
    print(f"\n{st['nodes']} nœuds, {st['links']} liens ({kinds})")
    for dev, errs in graph.get("errors", {}).items():
        for e in errs:
            print(f"  ⚠ {dev} : {e}", file=sys.stderr)


def cmd_scan(args) -> int:
    from .store import Store

    cfg = load(_find_config(args.config))
    store = Store(args.db or cfg.database)
    try:
        sid = _scan_and_store(cfg, store, args.dump)
        graph = store.graph_with_diff(sid)
    finally:
        store.close()
    if args.json:
        print(json.dumps(graph, indent=2, ensure_ascii=False))
    else:
        _print_report(graph)
        d = graph.get("diff")
        if d and (d["new_nodes"] or d["gone_nodes"] or d["moved"]):
            print(f"\nDepuis le scan précédent : +{len(d['new_nodes'])} / -{len(d['gone_nodes'])} nœuds, "
                  f"{len(d['moved'])} déplacé(s)")
            for n in d["gone_nodes"]:
                print(f"  - disparu : {n['label']}")
    return 0 if not graph["stats"]["unreachable"] else 2


def cmd_build(args) -> int:
    from .model import RawScan
    from .topology import build

    cfg = load(_find_config(args.config)) if (args.config or os.environ.get("NETMAP_CONFIG") or any(Path(p).is_file() for p in DEFAULT_PATHS)) else None
    if cfg is None:
        from .demo import demo_config
        cfg = demo_config()
    raw = RawScan.from_dict(json.loads(Path(args.raw).read_text()))
    graph = build(raw, cfg, resolve_dns=False)
    if args.json:
        Path(args.json).write_text(json.dumps(graph, indent=2, ensure_ascii=False))
        print(f"Graphe écrit dans {args.json}")
    else:
        _print_report(graph)
    return 0


def cmd_check(args) -> int:
    """Interroge un seul équipement et affiche ce qui a été récupéré (diagnostic)."""
    from .collectors import collect_device

    cfg = load(_find_config(args.config))
    targets = [d for d in cfg.devices if not args.device or d.name in args.device]
    if not targets:
        print("Aucun équipement correspondant dans la config.", file=sys.stderr)
        return 1
    rc = 0
    for dc in targets:
        d = collect_device(dc)
        status = "OK" if d.reachable else "INJOIGNABLE"
        print(f"\n== {dc.name} ({dc.type} {dc.host}) : {status} en {d.duration_s}s")
        if not d.reachable:
            rc = 2
        print(f"   nom={d.name}  modèle={d.model}  version={d.version}")
        up = [p for p in d.ports.values() if p.up]
        print(f"   ports : {len(d.ports)} ({len(up)} actifs) — MAC propres : {len(d.macs)}")
        print(f"   table MAC : {len(d.fdb)} entrées — ARP : {len(d.arp)} — baux DHCP : {len(d.leases)}")
        print(f"   voisins : {len(d.neighbors)}")
        for n in d.neighbors:
            print(f"     {n.local_port or '?':<14} {n.protocol:<14} {n.remote_name or '?'} [{n.remote_port or '?'}] {n.remote_ip or ''} {n.remote_mac or ''}")
        for e in d.errors:
            print(f"   ⚠ {e}")
        if args.verbose_ports:
            for p in d.ports.values():
                n_mac = sum(1 for e in d.fdb if e.port == p.name)
                print(f"     {p.name:<16} up={p.up!s:<5} {p.speed_mbps or '-':>6} Mb/s  MAC={n_mac:<4} {p.alias or ''}")
    return rc


def cmd_serve(args) -> int:
    from .server import Scanner, serve
    from .store import Store

    cfg = load(_find_config(args.config))
    if args.host:
        cfg.web_host = args.host
    if args.port:
        cfg.web_port = args.port
    store = Store(args.db or cfg.database)
    scanner = Scanner(lambda: _scan_and_store(cfg, store), interval=cfg.scan_interval)
    if args.scan or store.get_graph() is None:
        scanner.start()
    serve(store, scanner, cfg)
    return 0


def cmd_demo(args) -> int:
    from .demo import demo_config, demo_raw
    from .server import Scanner, serve
    from .store import Store
    from .topology import build

    cfg = demo_config()
    cfg.web_host = args.host or "127.0.0.1"
    cfg.web_port = args.port or 8650
    store = Store(args.db or ":memory:")

    def run():
        raw = demo_raw()
        return store.save_scan(raw.to_dict(), build(raw, cfg, resolve_dns=False), 50)

    run()
    if not args.serve:
        _print_report(store.graph_with_diff())
        return 0
    serve(store, Scanner(run), cfg, title="netmap — démo")
    return 0


def cmd_export(args) -> int:
    from .export import to_dot
    from .store import Store
    from .topology import text_tree

    cfg = load(_find_config(args.config))
    store = Store(args.db or cfg.database)
    got = store.get_graph(args.scan)
    store.close()
    if not got:
        print("Aucun scan en base.", file=sys.stderr)
        return 1
    graph = got[1]
    if args.format == "dot":
        print(to_dot(graph), end="")
    elif args.format == "json":
        print(json.dumps(graph, indent=2, ensure_ascii=False))
    else:
        print(text_tree(graph))
    return 0


def cmd_fetch_assets(args) -> int:
    """Télécharge Cytoscape.js en local (interface utilisable sans Internet)."""
    import urllib.request
    from .server import CDN_CYTOSCAPE, WEB_DIR

    target = WEB_DIR / "vendor" / "cytoscape.min.js"
    target.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(CDN_CYTOSCAPE, timeout=30) as r:
        data = r.read()
    if b"cytoscape" not in data[:2000].lower() and len(data) < 100_000:
        print("Téléchargement inattendu, fichier non écrit.", file=sys.stderr)
        return 1
    target.write_bytes(data)
    print(f"Cytoscape.js enregistré dans {target} ({len(data) // 1024} Ko)")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="netmap", description="Topologie réseau automatique (RouterOS, SNMP, Proxmox)")
    ap.add_argument("-c", "--config", help="fichier TOML (défaut : ./netmap.toml ou /etc/netmap/netmap.toml)")
    ap.add_argument("--db", help="base SQLite (remplace general.database)")
    ap.add_argument("-v", "--verbose", action="count", default=0)
    ap.add_argument("--version", action="version", version=f"netmap {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("scan", help="scanner le réseau, enregistrer et afficher la topologie")
    s.add_argument("--dump", metavar="FICHIER", help="enregistrer aussi les données brutes (JSON)")
    s.add_argument("--json", action="store_true", help="sortie JSON")
    s.set_defaults(func=cmd_scan)

    s = sub.add_parser("serve", help="lancer l'interface web")
    s.add_argument("--host")
    s.add_argument("--port", type=int)
    s.add_argument("--scan", action="store_true", help="scanner au démarrage")
    s.set_defaults(func=cmd_serve)

    s = sub.add_parser("check", help="tester la collecte sur un ou plusieurs équipements")
    s.add_argument("device", nargs="*", help="nom(s) d'équipement (défaut : tous)")
    s.add_argument("-p", "--ports", dest="verbose_ports", action="store_true", help="détail par port")
    s.set_defaults(func=cmd_check)

    s = sub.add_parser("build", help="reconstruire la topologie depuis un fichier brut (--dump)")
    s.add_argument("raw")
    s.add_argument("--json", metavar="SORTIE")
    s.set_defaults(func=cmd_build)

    s = sub.add_parser("export", help="exporter le dernier scan (texte, json, dot)")
    s.add_argument("--format", choices=["text", "json", "dot"], default="text")
    s.add_argument("--scan", type=int)
    s.set_defaults(func=cmd_export)

    s = sub.add_parser("demo", help="données de démonstration (sans matériel)")
    s.add_argument("--serve", action="store_true", help="ouvrir l'interface web sur la démo")
    s.add_argument("--host")
    s.add_argument("--port", type=int)
    s.set_defaults(func=cmd_demo)

    s = sub.add_parser("fetch-assets", help="télécharger Cytoscape.js pour un usage hors ligne")
    s.set_defaults(func=cmd_fetch_assets)

    args = ap.parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose > 1 else logging.INFO if args.verbose or args.cmd in ("serve", "demo") else logging.WARNING,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    try:
        return args.func(args)
    except ConfigError as e:
        log.error("Configuration : %s", e)
        return 1
