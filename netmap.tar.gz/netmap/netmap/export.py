"""Exports : Graphviz (.dot) et texte."""

from __future__ import annotations

_SHAPES = {
    "internet": "cloud", "router": "box3d", "switch": "box", "ap": "ellipse",
    "hypervisor": "box", "vm": "component", "ct": "component", "unmanaged": "box",
}


def _q(s) -> str:
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def to_dot(graph: dict) -> str:
    out = ["graph topologie {", "  rankdir=TB; splines=true; node [fontname=Helvetica fontsize=10]; edge [fontname=Helvetica fontsize=8];"]
    for n in graph["nodes"]:
        label = n["label"] + (f"\\n{n['ip']}" if n.get("ip") else "")
        shape = _SHAPES.get(n["kind"], "ellipse")
        style = "filled" + (",dashed" if n["kind"] == "unmanaged" or n.get("status") in ("stopped", "unreachable") else "")
        fill = "#dbeafe" if n.get("managed") else "#f3f4f6"
        out.append(f"  {_q(n['id'])} [label={_q(label)} shape={shape} style={_q(style)} fillcolor={_q(fill)}];")
    for e in graph["links"]:
        ports = ", ".join(f"{m['source_port'] or '?'} ↔ {m['target_port'] or '?'}" for m in e["members"] if m["source_port"] or m["target_port"])
        label = " · ".join(x for x in (ports, e.get("speed_label")) if x)
        attrs = [f"label={_q(label)}"]
        if e.get("blocked"):
            attrs.append('style=dashed color="#d97706"')
        elif e.get("inferred") or e["kind"] == "virtual":
            attrs.append("style=dotted")
        if e.get("speed") and e["speed"] >= 10000:
            attrs.append("penwidth=3")
        out.append(f"  {_q(e['source'])} -- {_q(e['target'])} [{' '.join(attrs)}];")
    out.append("}")
    return "\n".join(out) + "\n"
