import unittest
from unittest import mock

from netmap.collectors import collect_device
from netmap.collectors import proxmox as px
from netmap.config import DeviceConfig, ProxmoxConfig, SnmpAuth

from .fakes import FakeRouterOS, FakeSnmpAgent, Gauge, mac_bytes, mac_index

ROS_MENUS = {
    "/system/identity": [{"name": "R1-RB4011"}],
    "/system/resource": [{"board-name": "RB4011iGS+", "version": "7.20.1 (stable)"}],
    "/system/routerboard": [{"routerboard": "true", "model": "RB4011iGS+", "serial-number": "HEX123"}],
    "/interface": [
        {"name": "ether1", "type": "ether", "mac-address": "48:8F:5A:10:00:01", "running": "true", "disabled": "false"},
        {"name": "ether2", "type": "ether", "mac-address": "48:8F:5A:10:00:02", "running": "true", "disabled": "false"},
        {"name": "ether3", "type": "ether", "mac-address": "48:8F:5A:10:00:03", "running": "false", "disabled": "false"},
        {"name": "ether5", "type": "ether", "mac-address": "48:8F:5A:10:00:05", "running": "true", "disabled": "false"},
        {"name": "ether6", "type": "ether", "mac-address": "48:8F:5A:10:00:06", "running": "true", "disabled": "false"},
        {"name": "ether9", "type": "ether", "mac-address": "48:8F:5A:10:00:09", "running": "false", "disabled": "true"},
        {"name": "sfp-sfpplus1", "type": "ether", "mac-address": "48:8F:5A:10:00:0B", "running": "true", "disabled": "false", "comment": "uplink SW1"},
        {"name": "bond1", "type": "bond", "mac-address": "48:8F:5A:10:00:05", "running": "true", "disabled": "false"},
        {"name": "BR1", "type": "bridge", "mac-address": "48:8F:5A:10:00:02", "running": "true", "disabled": "false"},
        {"name": "vlan1000", "type": "vlan", "mac-address": "48:8F:5A:10:00:02", "running": "true", "disabled": "false"},
        {"name": "vrrp1", "type": "vrrp", "mac-address": "00:00:5E:00:01:0A", "running": "true", "disabled": "false"},
    ],
    "/interface/bridge": [{"name": "BR1"}],
    "/interface/bonding": [{"name": "bond1", "slaves": "ether5,ether6", "mode": "802.3ad"}],
    "/interface/bridge/port": [
        {"interface": "ether2", "bridge": "BR1", "forwarding": "false", "inactive": "false", "pvid": "1"},
        {"interface": "sfp-sfpplus1", "bridge": "BR1", "forwarding": "true", "inactive": "false", "pvid": "1"},
        {"interface": "bond1", "bridge": "BR1", "forwarding": "true", "inactive": "false", "pvid": "100"},
    ],
    "/interface/bridge/host": [
        {"mac-address": "74:4D:28:30:00:01", "on-interface": "sfp-sfpplus1", "bridge": "BR1", "vid": "1000", "local": "false"},
        {"mac-address": "00:08:9B:AA:00:01", "on-interface": "bond1", "bridge": "BR1", "vid": "100", "local": "false"},
        {"mac-address": "48:8F:5A:10:00:02", "on-interface": "BR1", "bridge": "BR1", "local": "true"},
    ],
    "/ip/neighbor": [
        {"interface": "ether2,BR1", "discovered-by": "lldp", "identity": "SW2-GS724T", "interface-name": "g2",
         "mac-address": "A0:40:A0:40:00:01", "address": "192.168.200.4", "system-caps-enabled": "bridge"},
        {"interface": "vlan1000", "discovered-by": "mndp", "identity": "SW1-CSS326", "mac-address": "74:4D:28:30:00:01",
         "address4": "192.168.200.3", "platform": "MikroTik", "board": "CSS326-24G-2S+"},
    ],
    "/ip/address": [{"address": "192.168.200.1/24", "interface": "vlan1000", "disabled": "false"}],
    "/ip/arp": [{"address": "10.0.0.10", "mac-address": "00:08:9B:AA:00:01", "interface": "vlan100"},
                {"address": "10.0.0.99", "mac-address": "", "interface": "vlan100", "invalid": "true"}],
    "/ip/dhcp-server/lease": [{"address": "192.168.0.20", "active-address": "192.168.0.20",
                               "mac-address": "D8:BB:C1:12:34:56", "host-name": "pc-fixe", "status": "bound"}],
}


class RouterOSCollectorTest(unittest.TestCase):
    def test_collect(self):
        srv = FakeRouterOS(ROS_MENUS, monitor={"ether1": "1Gbps", "ether2": "1Gbps", "ether5": "1Gbps",
                                               "ether6": "1Gbps", "sfp-sfpplus1": "10Gbps"})
        try:
            dc = DeviceConfig(name="R1", host="127.0.0.1", type="routeros", role="router", username="netmap",
                              password="secret", port=srv.port, wan_port="ether1", timeout=3)
            d = collect_device(dc)
        finally:
            srv.close()
        self.assertTrue(d.reachable, d.errors)
        self.assertEqual((d.name, d.model, d.serial), ("R1-RB4011", "RB4011iGS+", "HEX123"))
        self.assertNotIn("BR1", d.ports)
        self.assertNotIn("vlan1000", d.ports)
        self.assertNotIn("ether9", d.ports)  # désactivé
        self.assertNotIn("00:00:5E:00:01:0A", d.macs)  # MAC VRRP partagée
        self.assertEqual(d.ports["sfp-sfpplus1"].speed_mbps, 10000)
        self.assertEqual(d.ports["sfp-sfpplus1"].alias, "uplink SW1")
        self.assertEqual(d.ports["bond1"].members, ["ether5", "ether6"])
        self.assertEqual(d.ports["ether5"].bond, "bond1")
        self.assertEqual(d.ports["bond1"].speed_mbps, 2000)
        self.assertIs(d.ports["ether2"].stp_forwarding, False)
        self.assertEqual(d.ports["bond1"].pvid, 100)
        self.assertEqual({(e.mac, e.port, e.vlan) for e in d.fdb},
                         {("74:4D:28:30:00:01", "sfp-sfpplus1", 1000), ("00:08:9B:AA:00:01", "bond1", 100)})
        lldp = next(n for n in d.neighbors if n.protocol == "lldp")
        self.assertEqual((lldp.local_port, lldp.remote_port, lldp.caps), ("ether2", "g2", ["bridge"]))
        mndp = next(n for n in d.neighbors if n.protocol == "mndp")
        # vu sur une interface VLAN -> port physique retrouvé via la table MAC
        self.assertEqual((mndp.local_port, mndp.remote_ip, mndp.model), ("sfp-sfpplus1", "192.168.200.3", "CSS326-24G-2S+"))
        self.assertEqual([(a.ip, a.mac) for a in d.arp], [("10.0.0.10", "00:08:9B:AA:00:01")])
        self.assertEqual(d.leases[0].hostname, "pc-fixe")
        self.assertEqual(d.ips, ["192.168.200.1"])

    def test_unreachable_device_does_not_raise(self):
        dc = DeviceConfig(name="R9", host="127.0.0.1", type="routeros", port=1, timeout=1)
        d = collect_device(dc)
        self.assertFalse(d.reachable)
        self.assertTrue(d.errors)


def _ifmib(names, macs=None, speeds=None, oper=None, types=None):
    data = {}
    for i, n in names.items():
        data[f"1.3.6.1.2.1.2.2.1.2.{i}"] = n
        data[f"1.3.6.1.2.1.31.1.1.1.1.{i}"] = n
        data[f"1.3.6.1.2.1.2.2.1.3.{i}"] = (types or {}).get(i, 6)
        data[f"1.3.6.1.2.1.2.2.1.8.{i}"] = (oper or {}).get(i, 1)
        data[f"1.3.6.1.2.1.31.1.1.1.15.{i}"] = Gauge((speeds or {}).get(i, 1000))
        if macs and i in macs:
            data[f"1.3.6.1.2.1.2.2.1.6.{i}"] = mac_bytes(macs[i])
    return data


class SnmpCollectorTest(unittest.TestCase):
    def test_netgear_qbridge_lldp_lag(self):
        names = {i: f"g{i}" for i in range(1, 5)}
        names[1000] = "ch1"  # LAG
        data = {"1.3.6.1.2.1.1.5.0": "SW2-GS724T", "1.3.6.1.2.1.1.1.0": "GS724Tv4 ProSafe 24-port Gigabit Smart Switch",
                "1.3.6.1.2.1.17.1.1.0": mac_bytes("A0:40:A0:40:00:01")}
        data.update(_ifmib(names, oper={2: 1, 4: 2}, types={1000: 161}))
        data["1.2.840.10006.300.43.1.2.1.1.13.3"] = 1000  # g3 membre de ch1
        for bp in range(1, 5):
            data[f"1.3.6.1.2.1.17.1.4.1.2.{bp}"] = bp
        data["1.3.6.1.2.1.17.2.15.1.3.2"] = 2  # g2 bloqué STP
        data["1.3.6.1.2.1.17.2.15.1.3.1"] = 5
        # Q-BRIDGE : fdbId 7 -> VLAN 100 ; une entrée « self »
        data["1.3.6.1.2.1.17.7.1.4.2.1.3.0.100"] = 7
        e1 = "1.3.6.1.2.1.17.7.1.2.2.1.{col}.7." + ".".join(map(str, mac_index("58:47:CA:00:01:11")))
        e2 = "1.3.6.1.2.1.17.7.1.2.2.1.{col}.7." + ".".join(map(str, mac_index("A0:40:A0:40:00:01")))
        data[e1.format(col=2)] = 3
        data[e1.format(col=3)] = 3
        data[e2.format(col=2)] = 0
        data[e2.format(col=3)] = 4
        # LLDP : voisin sur le port local 2 (R1, ether2) avec IP de management
        rem = "1.0.8802.1.1.2.1.4.1.1.{col}.0.2.1"
        data[rem.format(col=4)] = 4
        data[rem.format(col=5)] = mac_bytes("48:8F:5A:10:00:02")
        data[rem.format(col=6)] = 5  # interfaceName
        data[rem.format(col=7)] = "ether2"
        data[rem.format(col=9)] = "R1-RB4011"
        data[rem.format(col=10)] = "MikroTik RouterOS 7.20.1 (stable)\nRB4011"
        data[rem.format(col=12)] = bytes([0x28, 0x00])  # bridge + router
        data["1.0.8802.1.1.2.1.3.7.1.3.2"] = "g2"
        data["1.0.8802.1.1.2.1.4.2.1.3.0.2.1.1.4.192.168.200.1"] = 2
        ag = FakeSnmpAgent(data, versions=("2c",))
        try:
            dc = DeviceConfig(name="SW2", host="127.0.0.1", type="snmp", snmp=SnmpAuth(port=ag.port, timeout=1))
            d = collect_device(dc)
        finally:
            ag.close()
        self.assertTrue(d.reachable, d.errors)
        self.assertEqual(d.name, "SW2-GS724T")
        self.assertIn("A0:40:A0:40:00:01", d.macs)
        self.assertEqual(d.ports["ch1"].members, ["g3"])
        self.assertEqual(d.ports["g3"].bond, "ch1")
        self.assertIs(d.ports["g2"].stp_forwarding, False)
        self.assertIs(d.ports["g4"].up, False)
        self.assertEqual([(e.mac, e.port, e.vlan) for e in d.fdb], [("58:47:CA:00:01:11", "g3", 100)])
        n = d.neighbors[0]
        self.assertEqual((n.local_port, n.remote_name, n.remote_port, n.remote_mac, n.remote_ip),
                         ("g2", "R1-RB4011", "ether2", "48:8F:5A:10:00:02", "192.168.200.1"))
        self.assertEqual(n.caps, ["bridge", "router"])
        self.assertEqual(n.platform, "MikroTik RouterOS 7.20.1 (stable)")

    def test_swos_bridge_mib_v1(self):
        names = {i: f"Port{i}" for i in range(1, 4)}
        data = {"1.3.6.1.2.1.1.5.0": "SW1-CSS326", "1.3.6.1.2.1.1.1.0": "CSS326-24G-2S+ SwOS"}
        data.update(_ifmib(names, macs={1: "74:4D:28:30:00:01"}))
        for bp in range(1, 4):
            data[f"1.3.6.1.2.1.17.1.4.1.2.{bp}"] = bp
        idx = ".".join(map(str, mac_index("00:08:9B:AA:00:01")))
        data[f"1.3.6.1.2.1.17.4.3.1.2.{idx}"] = 2
        data[f"1.3.6.1.2.1.17.4.3.1.3.{idx}"] = 3
        ag = FakeSnmpAgent(data, versions=("1",))
        try:
            dc = DeviceConfig(name="SW1", host="127.0.0.1", type="snmp", snmp=SnmpAuth(version="1", port=ag.port, timeout=1))
            d = collect_device(dc)
        finally:
            ag.close()
        self.assertTrue(d.reachable, d.errors)
        self.assertEqual(d.name, "SW1-CSS326")
        self.assertEqual([(e.mac, e.port, e.vlan) for e in d.fdb], [("00:08:9B:AA:00:01", "Port2", None)])
        self.assertEqual(d.neighbors, [])
        self.assertIn("74:4D:28:30:00:01", d.macs)


class ProxmoxCollectorTest(unittest.TestCase):
    def test_collect(self):
        responses = {
            "/cluster/status": [{"type": "cluster", "name": "homelab"}, {"type": "node", "name": "pve1", "ip": "10.0.0.1"}],
            "/nodes": [{"node": "pve1", "status": "online"}, {"node": "pve2", "status": "offline"}],
            "/nodes/pve1/network": [{"iface": "nic0", "type": "eth"}],
            "/nodes/pve1/qemu": [{"vmid": 103, "name": "jellyfin", "status": "running"}],
            "/nodes/pve1/qemu/103/config": {"net0": "virtio=BC:24:11:00:01:03,bridge=vmbr0,tag=100,firewall=1", "agent": "1"},
            "/nodes/pve1/qemu/103/agent/network-get-interfaces": {"result": [
                {"name": "lo", "ip-addresses": [{"ip-address-type": "ipv4", "ip-address": "127.0.0.1"}]},
                {"name": "eth0", "ip-addresses": [{"ip-address-type": "ipv4", "ip-address": "10.100.100.103"}]}]},
            "/nodes/pve1/lxc": [{"vmid": 101, "name": "ns1", "status": "running"}],
            "/nodes/pve1/lxc/101/config": {"hostname": "ns1", "net0": "name=eth0,bridge=vmbr0,hwaddr=BC:24:11:00:01:01,ip=10.53.53.1/8,tag=100"},
        }
        with mock.patch.object(px.PveClient, "get", lambda self, path: responses.get(path)):
            data = px.collect(ProxmoxConfig(host="pve", token_id="a@pve!t", token_secret="x"))
        self.assertEqual(data.cluster, "homelab")
        self.assertEqual([(n.name, n.ip, n.online) for n in data.nodes], [("pve1", "10.0.0.1", True), ("pve2", None, False)])
        vm = next(g for g in data.guests if g.vmid == 103)
        self.assertEqual((vm.macs, vm.vlans, vm.ips), (["BC:24:11:00:01:03"], [100], ["10.100.100.103"]))
        ct = next(g for g in data.guests if g.vmid == 101)
        self.assertEqual((ct.type, ct.macs, ct.ips), ("lxc", ["BC:24:11:00:01:01"], ["10.53.53.1"]))


if __name__ == "__main__":
    unittest.main()
