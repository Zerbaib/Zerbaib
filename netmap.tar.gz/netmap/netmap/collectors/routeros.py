"""Collecteur RouterOS v7 via l'API (lecture seule).

Droits nécessaires sur le routeur/switch (utilisateur dédié recommandé) :
    /user group add name=netmap policy=read,api
    /user add name=netmap group=netmap password=... address=<IP du serveur netmap>
"""

from __future__ import annotations

from ..config import DeviceConfig
from ..model import ArpEntry, DeviceData, FdbEntry, Lease, Neighbor, Port
from ..ros_api import RosError, RouterOS, as_bool
from ..util import log, norm_mac, parse_rate_mbps

_PHYS_TYPES = {"ether", "wlan", "wifi", "wifiwave2", "bond"}


def _port_type(iface_type: str, name: str) -> str:
    if iface_type == "bond":
        return "bond"
    if iface_type in ("wlan", "wifi", "wifiwave2", "w60g"):
        return "wifi"
    if name.startswith(("sfp", "qsfp")):
        return "sfp"
    if iface_type == "ether":
        return "ether"
    return "other"


def collect(dc: DeviceConfig) -> DeviceData:
    data = DeviceData(id=dc.name, host=dc.host, platform="routeros", role=dc.role,
                      wan_port=dc.wan_port, label=dc.label)
    with RouterOS(dc.host, dc.username, dc.password, port=dc.port, tls=dc.tls,
                  tls_verify=dc.tls_verify, timeout=dc.timeout) as api:

        def safe(menu: str, proplist=None):
            try:
                return api.print(menu, proplist)
            except RosError as e:
                data.errors.append(f"{menu} : {e}")
                log.debug("%s %s : %s", dc.name, menu, e)
                return []

        ident = safe("/system/identity")
        data.name = ident[0].get("name") if ident else dc.name
        res = safe("/system/resource")
        if res:
            data.model = res[0].get("board-name")
            data.version = res[0].get("version")
        rb = safe("/system/routerboard")
        if rb and rb[0].get("routerboard") == "true":
            data.model = rb[0].get("model") or data.model
            data.serial = rb[0].get("serial-number")

        # --- interfaces -----------------------------------------------------
        bridges = {b.get("name") for b in safe("/interface/bridge")}
        for it in safe("/interface"):
            name = it.get("name")
            typ = it.get("type", "")
            mac = norm_mac(it.get("mac-address"))
            if mac and typ != "vrrp" and mac not in data.macs:  # MAC VRRP partagée : ignorée
                data.macs.append(mac)
            if not name or name in bridges or typ not in _PHYS_TYPES and not name.startswith(("ether", "sfp", "qsfp", "wlan", "wifi")):
                continue
            if as_bool(it.get("disabled")):
                continue
            data.ports[name] = Port(
                name=name,
                type=_port_type(typ, name),
                mac=mac,
                up=as_bool(it.get("running")),
                alias=it.get("comment") or None,
            )

        for b in safe("/interface/bonding"):
            name = b.get("name")
            members = [m for m in (b.get("slaves") or "").split(",") if m]
            if name in data.ports:
                data.ports[name].members = members
            for m in members:
                if m in data.ports:
                    data.ports[m].bond = name

        # Débit négocié (monitor once) — une seule requête pour tous les ports cuivre/SFP
        eth_names = [p.name for p in data.ports.values() if p.type in ("ether", "sfp") and p.up]
        if eth_names:
            try:
                for mon in api.call("/interface/ethernet/monitor", numbers=",".join(eth_names), once=""):
                    pname = mon.get("name")
                    if pname in data.ports:
                        data.ports[pname].speed_mbps = parse_rate_mbps(mon.get("rate"))
            except RosError as e:
                data.errors.append(f"ethernet monitor : {e}")
        # Vitesse d'un bond = somme des membres actifs
        for p in data.ports.values():
            if p.type == "bond" and p.members:
                speeds = [data.ports[m].speed_mbps or 0 for m in p.members if m in data.ports and data.ports[m].up]
                p.speed_mbps = sum(speeds) or None

        # --- bridge : STP, PVID, table MAC ---------------------------------
        for bp in safe("/interface/bridge/port"):
            iface = bp.get("interface")
            if iface in data.ports:
                fwd = as_bool(bp.get("forwarding"))
                if fwd is not None and as_bool(bp.get("inactive")) is not True:
                    data.ports[iface].stp_forwarding = fwd
                try:
                    data.ports[iface].pvid = int(bp.get("pvid", "")) if bp.get("pvid") else None
                except ValueError:
                    pass

        host_port: dict[str, str] = {}
        for h in safe("/interface/bridge/host"):
            mac = norm_mac(h.get("mac-address"))
            if not mac:
                continue
            if as_bool(h.get("local")):
                if mac not in data.macs:
                    data.macs.append(mac)
                continue
            port = h.get("on-interface") or h.get("interface")
            if not port or port in bridges:
                continue
            vid = h.get("vid")
            data.fdb.append(FdbEntry(mac=mac, port=port, vlan=int(vid) if vid and vid.isdigit() else None))
            host_port.setdefault(mac, port)

        # --- voisins (LLDP / CDP / MNDP) -----------------------------------
        for n in safe("/ip/neighbor"):
            mac = norm_mac(n.get("mac-address"))
            local = _pick_local_port(n.get("interface", ""), data.ports, bridges, host_port.get(mac or ""))
            caps = [c for c in (n.get("system-caps-enabled") or n.get("system-caps") or "").split(",") if c]
            addr = n.get("address4") or n.get("address") or None
            data.neighbors.append(Neighbor(
                local_port=local,
                protocol=n.get("discovered-by") or "mndp",
                remote_name=n.get("identity") or n.get("system-description") or None,
                remote_port=n.get("interface-name") or None,
                remote_mac=mac,
                remote_ip=addr,
                platform=n.get("platform") or None,
                model=n.get("board") or None,
                caps=caps,
            ))

        # --- couche 3 : IP, ARP, DHCP -------------------------------------
        for a in safe("/ip/address"):
            ip = (a.get("address") or "").split("/")[0]
            if ip and as_bool(a.get("disabled")) is not True:
                data.ips.append(ip)
        for a in safe("/ip/arp"):
            mac = norm_mac(a.get("mac-address"))
            ip = a.get("address")
            if mac and ip and as_bool(a.get("invalid")) is not True:
                data.arp.append(ArpEntry(ip=ip, mac=mac, interface=a.get("interface")))
        for l in safe("/ip/dhcp-server/lease"):
            mac = norm_mac(l.get("active-mac-address") or l.get("mac-address"))
            ip = l.get("active-address") or l.get("address")
            if mac and ip:
                data.leases.append(Lease(ip=ip, mac=mac, hostname=l.get("host-name") or None,
                                         comment=l.get("comment") or None))
    return data


def _pick_local_port(field: str, ports: dict[str, Port], bridges: set[str], fdb_port: str | None) -> str | None:
    """Le champ `interface` d'un voisin vaut p.ex. 'ether3,BR1' ou 'vlan1000'.

    On garde le port physique ; à défaut (voisin vu sur une interface VLAN),
    on se rabat sur le port où la MAC du voisin est apprise dans le bridge.
    """
    tokens = [t for t in field.split(",") if t]
    for t in tokens:
        if t in ports and t not in bridges:
            # membre d'un bond -> on garde le membre (le LAG est reconstitué ensuite)
            return t
    if fdb_port and fdb_port in ports:
        return fdb_port
    return tokens[0] if tokens else None
