"""Collecteur SNMP générique (switchs non-RouterOS : SwOS, Netgear, Cisco, HP...).

MIB utilisées (toutes standard) :
  SNMPv2-MIB  : sysName, sysDescr
  IF-MIB      : ifName / ifDescr / ifAlias / ifPhysAddress / ifOperStatus / ifHighSpeed
  BRIDGE-MIB  : dot1dBasePortIfIndex, dot1dTpFdbPort (table MAC), dot1dStpPortState
  Q-BRIDGE-MIB: dot1qTpFdbPort (table MAC par VLAN)          — si disponible
  LLDP-MIB    : lldpRemTable, lldpLocPortTable, lldpRemManAddr — si disponible
  IEEE8023-LAG-MIB : dot3adAggPortAttachedAggID (membres de LAG) — si disponible

SwOS (CSS326) : SNMP v1/v2c, IF-MIB + BRIDGE-MIB, pas de LLDP ni de Q-BRIDGE.
Ses liens sont alors déduits des tables MAC et de MNDP vu par les RouterOS voisins.
"""

from __future__ import annotations

import ipaddress

from ..config import DeviceConfig
from ..model import DeviceData, FdbEntry, Neighbor, Port
from ..snmp import SnmpClient, SnmpError, text
from ..util import log, norm_mac

SYS_DESCR = "1.3.6.1.2.1.1.1.0"
SYS_NAME = "1.3.6.1.2.1.1.5.0"
IF_DESCR = "1.3.6.1.2.1.2.2.1.2"
IF_TYPE = "1.3.6.1.2.1.2.2.1.3"
IF_SPEED = "1.3.6.1.2.1.2.2.1.5"
IF_MAC = "1.3.6.1.2.1.2.2.1.6"
IF_OPER = "1.3.6.1.2.1.2.2.1.8"
IF_NAME = "1.3.6.1.2.1.31.1.1.1.1"
IF_HIGHSPEED = "1.3.6.1.2.1.31.1.1.1.15"
IF_ALIAS = "1.3.6.1.2.1.31.1.1.1.18"
BRIDGE_ADDR = "1.3.6.1.2.1.17.1.1.0"
BASE_PORT_IFINDEX = "1.3.6.1.2.1.17.1.4.1.2"
STP_PORT_STATE = "1.3.6.1.2.1.17.2.15.1.3"
D1D_FDB_PORT = "1.3.6.1.2.1.17.4.3.1.2"
D1D_FDB_STATUS = "1.3.6.1.2.1.17.4.3.1.3"
D1Q_FDB_PORT = "1.3.6.1.2.1.17.7.1.2.2.1.2"
D1Q_FDB_STATUS = "1.3.6.1.2.1.17.7.1.2.2.1.3"
D1Q_VLAN_FDBID = "1.3.6.1.2.1.17.7.1.4.2.1.3"
PVID = "1.3.6.1.2.1.17.7.1.4.5.1.1"
LLDP_LOC_PORT_ID = "1.0.8802.1.1.2.1.3.7.1.3"
LLDP_LOC_PORT_DESC = "1.0.8802.1.1.2.1.3.7.1.4"
LLDP_REM = "1.0.8802.1.1.2.1.4.1.1"
LLDP_REM_MANADDR = "1.0.8802.1.1.2.1.4.2.1.3"
LAG_ATTACHED = "1.2.840.10006.300.43.1.2.1.1.13"

# Types IF-MIB considérés comme ports physiques
_PHYS_IFTYPES = {6, 62, 69, 117, 161, 71}  # ethernetCsmacd, fastEther, ..., ieee8023adLag(161), ieee80211(71)
_LLDP_CAPS = ["other", "repeater", "bridge", "wlan-ap", "router", "telephone", "docsis", "station"]


def _int(v) -> int | None:
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _lldp_id(subtype: int | None, value) -> str | None:
    """Rend lisible un chassis-id / port-id LLDP selon son sous-type."""
    if value is None:
        return None
    if isinstance(value, bytes):
        if subtype in (4, 3) and len(value) == 6:  # macAddress
            return norm_mac(value)
        if subtype == 5 and len(value) in (5, 17):  # networkAddress (1 octet de famille)
            try:
                return str(ipaddress.ip_address(value[1:]))
            except ValueError:
                pass
        t = text(value)
        if t and all(32 <= ord(c) < 127 for c in t):
            return t
        return norm_mac(value) if len(value) == 6 else value.hex(":")
    return str(value)


def _caps(bits) -> list[str]:
    if not isinstance(bits, bytes) or not bits:
        return []
    out = []
    for i, name in enumerate(_LLDP_CAPS):
        byte, bit = divmod(i, 8)
        if byte < len(bits) and bits[byte] & (0x80 >> bit):
            out.append(name)
    return out


def collect(dc: DeviceConfig) -> DeviceData:
    s = dc.snmp
    data = DeviceData(id=dc.name, host=dc.host, platform="snmp", role=dc.role,
                      wan_port=dc.wan_port, label=dc.label)
    with SnmpClient(dc.host, community=s.community, version=s.version, port=s.port,
                    timeout=s.timeout, retries=s.retries, max_repetitions=s.max_repetitions) as c:

        def tbl(oid: str) -> dict:
            try:
                return c.table(oid)
            except SnmpError as e:
                if "pas de réponse" in str(e):
                    raise
                data.errors.append(f"{oid} : {e}")
                return {}

        sysvals = c.get(SYS_NAME, SYS_DESCR)
        data.name = text(sysvals.get((1, 3, 6, 1, 2, 1, 1, 5, 0))) or dc.name
        descr = text(sysvals.get((1, 3, 6, 1, 2, 1, 1, 1, 0)))
        data.model = descr.splitlines()[0][:80] if descr else None
        try:
            br = c.get(BRIDGE_ADDR)
            for v in br.values():
                m = norm_mac(v)
                if m:
                    data.macs.append(m)
        except SnmpError:
            pass

        # --- interfaces -------------------------------------------------------
        descrs = tbl(IF_DESCR)
        names = tbl(IF_NAME)
        types = tbl(IF_TYPE)
        macs = tbl(IF_MAC)
        opers = tbl(IF_OPER)
        hs = tbl(IF_HIGHSPEED)
        sp = tbl(IF_SPEED) if not hs else {}
        aliases = tbl(IF_ALIAS)
        lag = tbl(LAG_ATTACHED)

        ifname: dict[int, str] = {}
        for idx, d in descrs.items():
            i = idx[0]
            iftype = _int(types.get(idx))
            name = text(names.get(idx)) or text(d) or f"if{i}"
            ifname[i] = name
            mac = norm_mac(macs.get(idx))
            if mac and mac not in data.macs:
                data.macs.append(mac)
            if iftype is not None and iftype not in _PHYS_IFTYPES:
                continue
            speed = _int(hs.get(idx)) if hs else None
            if speed is None and sp:
                bps = _int(sp.get(idx))
                speed = bps // 1_000_000 if bps else None
            up = _int(opers.get(idx))
            data.ports[name] = Port(
                name=name,
                type="bond" if iftype == 161 else ("wifi" if iftype == 71 else ("sfp" if "sfp" in name.lower() else "ether")),
                mac=mac,
                speed_mbps=speed if up == 1 else None,
                up=(up == 1) if up is not None else None,
                alias=text(aliases.get(idx)),
            )
        for idx, agg in lag.items():
            member, parent = ifname.get(idx[0]), ifname.get(_int(agg) or -1)
            if member and parent and member != parent and member in data.ports and parent in data.ports:
                data.ports[member].bond = parent
                if member not in data.ports[parent].members:
                    data.ports[parent].members.append(member)

        # --- bridge : port de pont -> ifIndex --------------------------------
        bport_if = {idx[0]: _int(v) for idx, v in tbl(BASE_PORT_IFINDEX).items()}

        def bport_name(bp: int) -> str | None:
            ifi = bport_if.get(bp, bp)  # certains agents : bport == ifIndex
            return ifname.get(ifi) if ifi is not None else None

        for idx, st in tbl(STP_PORT_STATE).items():
            name = bport_name(idx[0])
            state = _int(st)
            if name in data.ports and state in (2, 5):  # 2=blocking, 5=forwarding
                data.ports[name].stp_forwarding = state == 5
        for idx, v in tbl(PVID).items():
            name = bport_name(idx[0])
            if name in data.ports:
                data.ports[name].pvid = _int(v)

        # --- table MAC : Q-BRIDGE puis BRIDGE --------------------------------
        fdb_q = tbl(D1Q_FDB_PORT)
        if fdb_q:
            status = tbl(D1Q_FDB_STATUS)
            fdbid_vlan = {}
            for idx, fid in tbl(D1Q_VLAN_FDBID).items():
                # index = TimeMark.VlanIndex
                if len(idx) >= 2:
                    fdbid_vlan[_int(fid)] = idx[-1]
            for idx, port in fdb_q.items():
                if len(idx) != 7:
                    continue
                fid, mac = idx[0], norm_mac(bytes(idx[1:]))
                self_entry = _int(status.get(idx)) in (4, 5)
                _add_fdb(data, mac, _int(port), bport_name, fdbid_vlan.get(fid, fid), self_entry)
        else:
            status = tbl(D1D_FDB_STATUS)
            for idx, port in tbl(D1D_FDB_PORT).items():
                if len(idx) != 6:
                    continue
                mac = norm_mac(bytes(idx))
                self_entry = _int(status.get(idx)) in (4, 5)
                _add_fdb(data, mac, _int(port), bport_name, None, self_entry)

        # --- LLDP ---------------------------------------------------------------
        rem = tbl(LLDP_REM)
        if rem:
            loc_id = tbl(LLDP_LOC_PORT_ID)
            loc_desc = tbl(LLDP_LOC_PORT_DESC)
            by_text = {}
            for ifi, n in ifname.items():
                by_text[n.lower()] = n
            for ifi, n in ifname.items():
                d = text(descrs.get((ifi,)))
                if d:
                    by_text.setdefault(d.lower(), n)

            def local_port(num: int) -> str | None:
                for candidate in (text(loc_id.get((num,))), text(loc_desc.get((num,)))):
                    if candidate and candidate.lower() in by_text:
                        return by_text[candidate.lower()]
                return bport_name(num) or ifname.get(num)

            entries: dict[tuple[int, int], dict[int, object]] = {}
            for idx, v in rem.items():
                # idx = colonne.TimeMark.LocalPortNum.Index
                if len(idx) < 4:
                    continue
                col, key = idx[0], (idx[2], idx[3])
                entries.setdefault(key, {})[col] = v
            manaddr: dict[tuple[int, int], str] = {}
            for idx, _v in tbl(LLDP_REM_MANADDR).items():
                # TimeMark.LocalPortNum.Index.AddrSubtype.AddrLen.addr...
                if len(idx) >= 9 and idx[3] == 1 and idx[4] == 4:
                    manaddr.setdefault((idx[1], idx[2]), ".".join(map(str, idx[5:9])))
            for (lport, ridx), cols in entries.items():
                chassis = _lldp_id(_int(cols.get(4)), cols.get(5))
                portid = _lldp_id(_int(cols.get(6)), cols.get(7))
                pdesc = text(cols.get(8))
                data.neighbors.append(Neighbor(
                    local_port=local_port(lport),
                    protocol="lldp",
                    remote_name=text(cols.get(9)),
                    remote_port=portid if portid and not norm_mac(portid) else (pdesc or portid),
                    remote_mac=norm_mac(chassis) if chassis else None,
                    remote_ip=manaddr.get((lport, ridx)),
                    platform=(text(cols.get(10)) or "").splitlines()[0][:80] or None,
                    caps=_caps(cols.get(12)) or _caps(cols.get(11)),
                ))
    return data


def _add_fdb(data: DeviceData, mac: str | None, bport: int | None, bport_name, vlan, self_entry: bool):
    if not mac:
        return
    if self_entry or bport in (None, 0):
        if mac not in data.macs:
            data.macs.append(mac)
        return
    name = bport_name(bport)
    if not name:
        log.debug("%s : port de pont %s inconnu pour %s", data.id, bport, mac)
        return
    data.fdb.append(FdbEntry(mac=mac, port=name, vlan=vlan))
