"""Serveur web intégré (bibliothèque standard) : interface + API JSON.

API :
  GET    /api/graph[?scan=ID]   graphe (+ diff avec le scan précédent, + positions)
  GET    /api/scans             historique
  POST   /api/scan              lance un scan en arrière-plan
  GET    /api/status            état du scan en cours
  PUT    /api/positions         {"node_id": {"x":..,"y":..}, ...}
  DELETE /api/positions         réinitialise la disposition
  GET    /api/raw/ID            données brutes d'un scan (débogage)
  GET    /api/export/ID.dot     export Graphviz
"""

from __future__ import annotations

import base64
import hmac
import json
import mimetypes
import threading
import time
import traceback
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable
from urllib.parse import parse_qs, urlparse

from .config import Config
from .store import Store
from .util import log

WEB_DIR = Path(__file__).parent / "web"
CDN_CYTOSCAPE = "https://cdn.jsdelivr.net/npm/cytoscape@3/dist/cytoscape.min.js"


class Scanner:
    """Exécute les scans en arrière-plan, un seul à la fois."""

    def __init__(self, run: Callable[[], int], interval: int = 0):
        self._run = run
        self._lock = threading.Lock()
        self.running = False
        self.last_error: str | None = None
        self.last_scan_id: int | None = None
        self.last_duration: float | None = None
        self.started_at: float | None = None
        if interval > 0:
            threading.Thread(target=self._periodic, args=(interval,), daemon=True).start()

    def start(self) -> bool:
        if not self._lock.acquire(blocking=False):
            return False
        self.running = True
        self.started_at = time.time()
        threading.Thread(target=self._worker, daemon=True).start()
        return True

    def _worker(self):
        t0 = time.monotonic()
        try:
            self.last_scan_id = self._run()
            self.last_error = None
        except Exception as e:  # pragma: no cover - remonté à l'interface
            self.last_error = f"{type(e).__name__}: {e}"
            log.error("Scan en échec : %s\n%s", e, traceback.format_exc())
        finally:
            self.last_duration = round(time.monotonic() - t0, 1)
            self.running = False
            self._lock.release()

    def _periodic(self, interval: int):
        while True:
            time.sleep(interval)
            self.start()

    def status(self) -> dict:
        return {
            "running": self.running,
            "last_error": self.last_error,
            "last_scan_id": self.last_scan_id,
            "last_duration": self.last_duration,
            "started_at": self.started_at,
        }


def make_handler(store: Store, scanner: Scanner, cfg: Config, title: str = "netmap"):
    auth_token = None
    if cfg.web_username and cfg.web_password:
        auth_token = base64.b64encode(f"{cfg.web_username}:{cfg.web_password}".encode()).decode()

    class Handler(BaseHTTPRequestHandler):
        server_version = "netmap"

        def log_message(self, fmt, *args):
            log.debug("%s - %s", self.address_string(), fmt % args)

        # -- utilitaires -------------------------------------------------------
        def _authorized(self) -> bool:
            if not auth_token:
                return True
            header = self.headers.get("Authorization", "")
            if header.startswith("Basic ") and hmac.compare_digest(header[6:].strip(), auth_token):
                return True
            self.send_response(HTTPStatus.UNAUTHORIZED)
            self.send_header("WWW-Authenticate", 'Basic realm="netmap"')
            self.send_header("Content-Length", "0")
            self.end_headers()
            return False

        def _json(self, obj, status=HTTPStatus.OK):
            body = json.dumps(obj, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _file(self, path: Path, ctype: str | None = None):
            if not path.is_file():
                return self._json({"error": "introuvable"}, HTTPStatus.NOT_FOUND)
            data = path.read_bytes()
            if path.name == "index.html":
                data = data.replace(b"{{TITLE}}", title.encode())
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", ctype or mimetypes.guess_type(path.name)[0] or "application/octet-stream")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(data)

        def _body(self):
            length = int(self.headers.get("Content-Length") or 0)
            if length > 5_000_000:
                raise ValueError("corps trop volumineux")
            return json.loads(self.rfile.read(length) or b"{}")

        def _same_origin(self) -> bool:
            # Protection CSRF simple pour les requêtes qui modifient l'état
            origin = self.headers.get("Origin")
            if not origin:
                return True
            return urlparse(origin).netloc == self.headers.get("Host")

        # -- routes --------------------------------------------------------------
        def do_GET(self):
            if not self._authorized():
                return
            url = urlparse(self.path)
            p = url.path
            q = parse_qs(url.query)
            try:
                if p in ("/", "/index.html"):
                    return self._file(WEB_DIR / "index.html", "text/html; charset=utf-8")
                if p.startswith("/static/"):
                    name = p[len("/static/"):]
                    target = (WEB_DIR / name).resolve()
                    if WEB_DIR.resolve() not in target.parents:
                        return self._json({"error": "interdit"}, HTTPStatus.FORBIDDEN)
                    return self._file(target)
                if p == "/vendor/cytoscape.min.js":
                    local = WEB_DIR / "vendor" / "cytoscape.min.js"
                    if local.is_file():
                        return self._file(local, "text/javascript")
                    self.send_response(HTTPStatus.FOUND)
                    self.send_header("Location", CDN_CYTOSCAPE)
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                if p == "/api/graph":
                    sid = int(q["scan"][0]) if "scan" in q else None
                    g = store.graph_with_diff(sid)
                    if not g:
                        return self._json({"empty": True, "status": scanner.status()})
                    g["positions"] = store.positions()
                    g["status"] = scanner.status()
                    return self._json(g)
                if p == "/api/scans":
                    return self._json(store.list_scans())
                if p == "/api/status":
                    return self._json(scanner.status())
                if p.startswith("/api/raw/"):
                    raw = store.get_raw(int(p.rsplit("/", 1)[1]))
                    return self._json(raw) if raw else self._json({"error": "introuvable"}, HTTPStatus.NOT_FOUND)
                if p.startswith("/api/export/") and p.endswith(".dot"):
                    from .export import to_dot
                    sid = p.rsplit("/", 1)[1][:-4]
                    got = store.get_graph(None if sid == "latest" else int(sid))
                    if not got:
                        return self._json({"error": "introuvable"}, HTTPStatus.NOT_FOUND)
                    body = to_dot(got[1]).encode()
                    self.send_response(HTTPStatus.OK)
                    self.send_header("Content-Type", "text/vnd.graphviz; charset=utf-8")
                    self.send_header("Content-Disposition", 'attachment; filename="topologie.dot"')
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                return self._json({"error": "introuvable"}, HTTPStatus.NOT_FOUND)
            except (ValueError, KeyError) as e:
                return self._json({"error": str(e)}, HTTPStatus.BAD_REQUEST)

        def do_POST(self):
            if not self._authorized():
                return
            if not self._same_origin():
                return self._json({"error": "origine refusée"}, HTTPStatus.FORBIDDEN)
            if urlparse(self.path).path == "/api/scan":
                started = scanner.start()
                return self._json({"started": started, "status": scanner.status()},
                                  HTTPStatus.ACCEPTED if started else HTTPStatus.CONFLICT)
            return self._json({"error": "introuvable"}, HTTPStatus.NOT_FOUND)

        def do_PUT(self):
            if not self._authorized():
                return
            if not self._same_origin():
                return self._json({"error": "origine refusée"}, HTTPStatus.FORBIDDEN)
            if urlparse(self.path).path == "/api/positions":
                try:
                    body = self._body()
                    if not isinstance(body, dict):
                        raise ValueError("objet attendu")
                    store.save_positions({k: v for k, v in body.items() if isinstance(v, dict) and "x" in v and "y" in v})
                    return self._json({"ok": True})
                except (ValueError, TypeError) as e:
                    return self._json({"error": str(e)}, HTTPStatus.BAD_REQUEST)
            return self._json({"error": "introuvable"}, HTTPStatus.NOT_FOUND)

        def do_DELETE(self):
            if not self._authorized():
                return
            if not self._same_origin():
                return self._json({"error": "origine refusée"}, HTTPStatus.FORBIDDEN)
            if urlparse(self.path).path == "/api/positions":
                store.reset_positions()
                return self._json({"ok": True})
            return self._json({"error": "introuvable"}, HTTPStatus.NOT_FOUND)

    return Handler


def serve(store: Store, scanner: Scanner, cfg: Config, title: str = "netmap") -> None:
    handler = make_handler(store, scanner, cfg, title)
    httpd = ThreadingHTTPServer((cfg.web_host, cfg.web_port), handler)
    httpd.daemon_threads = True
    if not (cfg.web_username and cfg.web_password) and cfg.web_host not in ("127.0.0.1", "localhost", "::1"):
        log.warning("Interface web accessible sans mot de passe sur %s — pense à [web] username/password", cfg.web_host)
    log.info("Interface web : http://%s:%s/", cfg.web_host, cfg.web_port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
