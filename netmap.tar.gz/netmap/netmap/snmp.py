"""Client SNMP v1 / v2c minimal (BER encodé à la main, UDP).

Suffisant pour parcourir (walk) les tables IF-MIB, BRIDGE-MIB, Q-BRIDGE-MIB et LLDP-MIB.
v2c utilise GETBULK (rapide) ; v1 utilise GETNEXT (SwOS accepte les deux).
"""

from __future__ import annotations

import ipaddress
import random
import socket
from dataclasses import dataclass

OID = tuple[int, ...]

# Types ASN.1 / SNMP
INTEGER, OCTET_STRING, NULL, OBJECT_ID, SEQUENCE = 0x02, 0x04, 0x05, 0x06, 0x30
IP_ADDRESS, COUNTER32, GAUGE32, TIMETICKS, OPAQUE, COUNTER64 = 0x40, 0x41, 0x42, 0x43, 0x44, 0x46
NO_SUCH_OBJECT, NO_SUCH_INSTANCE, END_OF_MIB = 0x80, 0x81, 0x82
GET, GETNEXT, RESPONSE, GETBULK = 0xA0, 0xA1, 0xA2, 0xA5


class SnmpError(Exception):
    pass


class SnmpTimeout(SnmpError):
    pass


class _EndOfMib:
    def __repr__(self):
        return "endOfMibView"


class _NoSuch:
    def __repr__(self):
        return "noSuch"


END = _EndOfMib()
NOSUCH = _NoSuch()


def parse_oid(text: str | OID) -> OID:
    if isinstance(text, tuple):
        return text
    return tuple(int(x) for x in text.strip(".").split("."))


def oid_str(oid: OID) -> str:
    return ".".join(map(str, oid))


# --- Encodage BER ---------------------------------------------------------------

def _enc_len(n: int) -> bytes:
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def _tlv(tag: int, value: bytes) -> bytes:
    return bytes([tag]) + _enc_len(len(value)) + value


def _enc_int(n: int, tag: int = INTEGER) -> bytes:
    length = max(1, (n + (n < 0)).bit_length() // 8 + 1)
    return _tlv(tag, n.to_bytes(length, "big", signed=True))


def _enc_oid(oid: OID) -> bytes:
    if len(oid) < 2:
        raise ValueError("OID trop court")
    out = bytearray([oid[0] * 40 + oid[1]])
    for arc in oid[2:]:
        if arc == 0:
            out.append(0)
            continue
        chunk = []
        while arc:
            chunk.append(arc & 0x7F)
            arc >>= 7
        chunk.reverse()
        for i, c in enumerate(chunk):
            out.append(c | (0x80 if i < len(chunk) - 1 else 0))
    return _tlv(OBJECT_ID, bytes(out))


def encode_request(version: int, community: str, pdu_type: int, req_id: int, oids: list[OID], non_rep: int = 0, max_rep: int = 0) -> bytes:
    varbinds = b"".join(_tlv(SEQUENCE, _enc_oid(o) + _tlv(NULL, b"")) for o in oids)
    pdu = _tlv(pdu_type, _enc_int(req_id) + _enc_int(non_rep) + _enc_int(max_rep) + _tlv(SEQUENCE, varbinds))
    return _tlv(SEQUENCE, _enc_int(version) + _tlv(OCTET_STRING, community.encode()) + pdu)


# --- Décodage BER ---------------------------------------------------------------

def _dec_tlv(data: bytes, pos: int) -> tuple[int, bytes, int]:
    if pos + 2 > len(data):
        raise SnmpError("paquet tronqué")
    tag = data[pos]
    length = data[pos + 1]
    pos += 2
    if length & 0x80:
        nb = length & 0x7F
        length = int.from_bytes(data[pos : pos + nb], "big")
        pos += nb
    end = pos + length
    if end > len(data):
        raise SnmpError("paquet tronqué")
    return tag, data[pos:end], end


def _dec_oid(b: bytes) -> OID:
    if not b:
        return ()
    first = b[0]
    out = [first // 40, first % 40] if first < 80 else [2, first - 80]
    val = 0
    for byte in b[1:]:
        val = (val << 7) | (byte & 0x7F)
        if not byte & 0x80:
            out.append(val)
            val = 0
    return tuple(out)


def _dec_value(tag: int, b: bytes):
    if tag == INTEGER:
        return int.from_bytes(b, "big", signed=True) if b else 0
    if tag in (COUNTER32, GAUGE32, TIMETICKS, COUNTER64):
        return int.from_bytes(b, "big", signed=False) if b else 0
    if tag in (OCTET_STRING, OPAQUE):
        return bytes(b)
    if tag == OBJECT_ID:
        return _dec_oid(b)
    if tag == IP_ADDRESS:
        return str(ipaddress.IPv4Address(b)) if len(b) == 4 else bytes(b)
    if tag == NULL:
        return None
    if tag == END_OF_MIB:
        return END
    if tag in (NO_SUCH_OBJECT, NO_SUCH_INSTANCE):
        return NOSUCH
    return bytes(b)


@dataclass
class Response:
    req_id: int
    error_status: int
    error_index: int
    varbinds: list[tuple[OID, object]]


def decode_response(data: bytes) -> Response:
    tag, msg, _ = _dec_tlv(data, 0)
    if tag != SEQUENCE:
        raise SnmpError("réponse invalide")
    _, _ver, p = _dec_tlv(msg, 0)
    _, _comm, p = _dec_tlv(msg, p)
    tag, pdu, _ = _dec_tlv(msg, p)
    if tag != RESPONSE:
        raise SnmpError(f"PDU inattendue 0x{tag:02x}")
    _, rid, q = _dec_tlv(pdu, 0)
    _, est, q = _dec_tlv(pdu, q)
    _, eix, q = _dec_tlv(pdu, q)
    _, vbl, _ = _dec_tlv(pdu, q)
    varbinds = []
    p = 0
    while p < len(vbl):
        _, vb, p = _dec_tlv(vbl, p)
        _, oidb, r = _dec_tlv(vb, 0)
        vtag, vval, _ = _dec_tlv(vb, r)
        varbinds.append((_dec_oid(oidb), _dec_value(vtag, vval)))
    return Response(
        req_id=int.from_bytes(rid, "big", signed=True),
        error_status=int.from_bytes(est, "big", signed=True),
        error_index=int.from_bytes(eix, "big", signed=True),
        varbinds=varbinds,
    )


# --- Client ---------------------------------------------------------------------

class SnmpClient:
    def __init__(self, host: str, community: str = "public", version: str = "2c", port: int = 161,
                 timeout: float = 2.0, retries: int = 2, max_repetitions: int = 25):
        self.host = host
        self.port = port
        self.community = community
        self.version = 0 if str(version) == "1" else 1
        self.timeout = timeout
        self.retries = retries
        self.max_rep = max_repetitions
        self._sock: socket.socket | None = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        if self._sock:
            self._sock.close()
            self._sock = None

    def _socket(self) -> socket.socket:
        if self._sock is None:
            info = socket.getaddrinfo(self.host, self.port, type=socket.SOCK_DGRAM)[0]
            self._sock = socket.socket(info[0], socket.SOCK_DGRAM)
            self._sock.connect(info[4])
            self._sock.settimeout(self.timeout)
        return self._sock

    def _request(self, pdu_type: int, oids: list[OID], non_rep: int = 0, max_rep: int = 0) -> Response:
        sock = self._socket()
        req_id = random.randint(1, 2**31 - 1)
        packet = encode_request(self.version, self.community, pdu_type, req_id, oids, non_rep, max_rep)
        for _attempt in range(self.retries + 1):
            sock.send(packet)
            try:
                while True:
                    data = sock.recv(65535)
                    resp = decode_response(data)
                    if resp.req_id == req_id:
                        return resp
            except socket.timeout:
                continue
            except ConnectionRefusedError:
                raise SnmpError(f"{self.host} : port SNMP fermé (ICMP refusé)") from None
        raise SnmpTimeout(f"{self.host} : pas de réponse SNMP (communauté / ACL / version ?)")

    def get(self, *oids: str | OID) -> dict[OID, object]:
        parsed = [parse_oid(o) for o in oids]
        resp = self._request(GET, parsed)
        if resp.error_status and self.version == 0:
            # v1 : noSuchName -> on renvoie ce qui existe un par un
            out = {}
            for o in parsed:
                r = self._request(GET, [o])
                if not r.error_status:
                    out.update(dict(r.varbinds))
            return out
        return {o: v for o, v in resp.varbinds if v is not NOSUCH}

    def walk(self, base: str | OID) -> list[tuple[OID, object]]:
        """Parcourt la sous-arborescence `base`. Renvoie [(oid, valeur)] triés."""
        root = parse_oid(base)
        out: list[tuple[OID, object]] = []
        current = root
        seen_last: OID | None = None
        while True:
            if self.version == 1:
                resp = self._request(GETBULK, [current], 0, self.max_rep)
            else:
                resp = self._request(GETNEXT, [current])
                if resp.error_status == 2:  # noSuchName = fin de MIB en v1
                    break
            if resp.error_status:
                raise SnmpError(f"{self.host} : erreur SNMP {resp.error_status} sur {oid_str(current)}")
            if not resp.varbinds:
                break
            done = False
            for oid, val in resp.varbinds:
                if val is END or oid[: len(root)] != root:
                    done = True
                    break
                if seen_last is not None and oid <= seen_last:
                    raise SnmpError(f"{self.host} : OID non croissant (agent défaillant)")
                out.append((oid, val))
                seen_last = oid
            if done:
                break
            current = seen_last  # type: ignore[assignment]
        return out

    def table(self, base: str | OID) -> dict[OID, object]:
        """Comme walk, mais renvoie {suffixe_index: valeur}."""
        root = parse_oid(base)
        return {oid[len(root):]: v for oid, v in self.walk(root)}


def text(value) -> str | None:
    if value is None or value is NOSUCH or value is END:
        return None
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace").strip("\x00").strip() or None
    return str(value)
