"""netmap — topologie réseau automatique façon UniFi, pour MikroTik / SNMP / Proxmox.

Aucune dépendance externe : bibliothèque standard Python 3.11+ uniquement.
"""

__version__ = "0.1.0"
