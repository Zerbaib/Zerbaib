"""Historique des scans (SQLite) + positions des nœuds déplacés dans l'interface."""

from __future__ import annotations

import json
import sqlite3
import threading
import zlib
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    raw BLOB NOT NULL,
    graph BLOB NOT NULL,
    nodes INTEGER, links INTEGER, errors INTEGER
);
CREATE TABLE IF NOT EXISTS positions (
    node_id TEXT PRIMARY KEY,
    x REAL NOT NULL,
    y REAL NOT NULL
);
"""


def _pack(obj) -> bytes:
    return zlib.compress(json.dumps(obj, separators=(",", ":")).encode(), 6)


def _unpack(blob: bytes):
    return json.loads(zlib.decompress(blob))


class Store:
    def __init__(self, path: str | Path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self.db.executescript(SCHEMA)
        self.db.commit()

    def close(self):
        self.db.close()

    # -- scans ------------------------------------------------------------------
    def save_scan(self, raw: dict, graph: dict, retention: int = 500) -> int:
        with self._lock:
            cur = self.db.execute(
                "INSERT INTO scans (ts, raw, graph, nodes, links, errors) VALUES (?,?,?,?,?,?)",
                (graph["ts"], _pack(raw), _pack(graph), len(graph["nodes"]), len(graph["links"]), len(graph.get("errors", {}))),
            )
            sid = cur.lastrowid
            if retention > 0:
                self.db.execute("DELETE FROM scans WHERE id NOT IN (SELECT id FROM scans ORDER BY id DESC LIMIT ?)", (retention,))
            self.db.commit()
            return sid

    def list_scans(self, limit: int = 100) -> list[dict]:
        with self._lock:
            rows = self.db.execute("SELECT id, ts, nodes, links, errors FROM scans ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [{"id": r[0], "ts": r[1], "nodes": r[2], "links": r[3], "errors": r[4]} for r in rows]

    def get_graph(self, scan_id: int | None = None) -> tuple[int, dict] | None:
        with self._lock:
            if scan_id is None:
                row = self.db.execute("SELECT id, graph FROM scans ORDER BY id DESC LIMIT 1").fetchone()
            else:
                row = self.db.execute("SELECT id, graph FROM scans WHERE id = ?", (scan_id,)).fetchone()
        return (row[0], _unpack(row[1])) if row else None

    def get_raw(self, scan_id: int) -> dict | None:
        with self._lock:
            row = self.db.execute("SELECT raw FROM scans WHERE id = ?", (scan_id,)).fetchone()
        return _unpack(row[0]) if row else None

    def previous_id(self, scan_id: int) -> int | None:
        with self._lock:
            row = self.db.execute("SELECT id FROM scans WHERE id < ? ORDER BY id DESC LIMIT 1", (scan_id,)).fetchone()
        return row[0] if row else None

    def graph_with_diff(self, scan_id: int | None = None) -> dict | None:
        cur = self.get_graph(scan_id)
        if not cur:
            return None
        sid, graph = cur
        graph["scan_id"] = sid
        prev_id = self.previous_id(sid)
        graph["diff"] = diff(self.get_graph(prev_id)[1], graph) if prev_id else None
        return graph

    # -- positions ----------------------------------------------------------------
    def positions(self) -> dict[str, dict]:
        with self._lock:
            rows = self.db.execute("SELECT node_id, x, y FROM positions").fetchall()
        return {r[0]: {"x": r[1], "y": r[2]} for r in rows}

    def save_positions(self, pos: dict[str, dict]) -> None:
        with self._lock:
            self.db.executemany(
                "INSERT INTO positions (node_id, x, y) VALUES (?,?,?) ON CONFLICT(node_id) DO UPDATE SET x=excluded.x, y=excluded.y",
                [(k, float(v["x"]), float(v["y"])) for k, v in pos.items()],
            )
            self.db.commit()

    def reset_positions(self) -> None:
        with self._lock:
            self.db.execute("DELETE FROM positions")
            self.db.commit()


def diff(old: dict, new: dict) -> dict:
    """Différences entre deux graphes : nœuds/liens apparus ou disparus."""
    on = {n["id"]: n for n in old["nodes"]}
    nn = {n["id"]: n for n in new["nodes"]}
    ol = {l["id"]: l for l in old["links"]}
    nl = {l["id"]: l for l in new["links"]}
    moved = []
    for nid in set(on) & set(nn):
        if on[nid].get("attach") and nn[nid].get("attach") and on[nid]["attach"] != nn[nid]["attach"]:
            moved.append({"id": nid, "label": nn[nid]["label"], "from": on[nid]["attach"], "to": nn[nid]["attach"]})
    return {
        "since": old.get("ts"),
        "new_nodes": sorted(set(nn) - set(on)),
        "gone_nodes": [on[k] for k in sorted(set(on) - set(nn))],
        "new_links": sorted(set(nl) - set(ol)),
        "gone_links": [ol[k] for k in sorted(set(ol) - set(nl))],
        "moved": moved,
    }
