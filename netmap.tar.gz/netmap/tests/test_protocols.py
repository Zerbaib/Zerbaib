import unittest

from netmap import snmp as S
from netmap.ros_api import RosTrap, RouterOS, encode_length

from .fakes import Counter, FakeRouterOS, FakeSnmpAgent, Gauge


class RouterOSApiTest(unittest.TestCase):
    def test_length_encoding_boundaries(self):
        cases = {0: b"\x00", 0x7F: b"\x7f", 0x80: b"\x80\x80", 0x3FFF: b"\xbf\xff", 0x4000: b"\xc0\x40\x00",
                 0x1FFFFF: b"\xdf\xff\xff", 0x200000: b"\xe0\x20\x00\x00", 0x10000000: b"\xf0\x10\x00\x00\x00"}
        for n, expected in cases.items():
            self.assertEqual(encode_length(n), expected, hex(n))

    def test_login_print_trap_and_empty(self):
        long_comment = "x" * 300  # mot > 127 octets : encodage sur 2 octets
        srv = FakeRouterOS({"/system/identity": [{"name": "R1"}],
                            "/interface": [{"name": "ether1", "comment": long_comment}],
                            "/ip/arp": []})
        try:
            with RouterOS("127.0.0.1", "netmap", "secret", port=srv.port, timeout=3) as api:
                self.assertEqual(api.print("/system/identity"), [{".id": "*0", "name": "R1"}])
                self.assertEqual(api.print("/interface")[0]["comment"], long_comment)
                self.assertEqual(api.print("/ip/arp"), [])  # !empty puis !done
                self.assertEqual(api.print("/does/not/exist"), [])  # trap « no such command » toléré
                with self.assertRaises(RosTrap):
                    api.call("/system/reboot")
            with self.assertRaises(RosTrap):
                RouterOS("127.0.0.1", "netmap", "mauvais", port=srv.port, timeout=3).connect()
        finally:
            srv.close()


class SnmpCodecTest(unittest.TestCase):
    def test_known_get_request_bytes(self):
        pkt = S.encode_request(0, "public", S.GET, 1, [S.parse_oid("1.3.6.1.2.1.1.1.0")])
        self.assertEqual(pkt.hex(), "302602010004067075626c6963a019020101020100020100300e300c06082b060102010101000500")

    def test_integer_and_oid_roundtrip(self):
        for n in (0, 1, 127, 128, 255, 256, -1, -128, -129, 2**31 - 1, -(2**31)):
            tlv = S._enc_int(n)
            tag, val, _ = S._dec_tlv(tlv, 0)
            self.assertEqual(S._dec_value(tag, val), n)
        for oid in ("1.3.6.1.2.1.17.7.1.2.2.1.2.100.0.12.66.1.2.3", "1.0.8802.1.1.2.1.4.1.1.9", "1.2.840.10006.300.43.1.2.1.1.13"):
            tag, val, _ = S._dec_tlv(S._enc_oid(S.parse_oid(oid)), 0)
            self.assertEqual(S.oid_str(S._dec_oid(val)), oid)

    def _agent(self, versions):
        data = {f"1.3.6.1.2.1.2.2.1.2.{i}": f"port{i}" for i in range(1, 61)}
        data.update({"1.3.6.1.2.1.1.5.0": "sw", "1.3.6.1.2.1.31.1.1.1.15.1": Gauge(1000),
                     "1.3.6.1.2.1.2.2.1.10.1": Counter(5)})
        return FakeSnmpAgent(data, versions=versions)

    def test_walk_v2c_getbulk(self):
        ag = self._agent(("2c",))
        try:
            with S.SnmpClient("127.0.0.1", port=ag.port, version="2c", timeout=1, max_repetitions=10) as c:
                rows = c.table("1.3.6.1.2.1.2.2.1.2")
                self.assertEqual(len(rows), 60)
                self.assertEqual(rows[(42,)], b"port42")
                self.assertEqual(c.get("1.3.6.1.2.1.1.5.0"), {(1, 3, 6, 1, 2, 1, 1, 5, 0): b"sw"})
                self.assertEqual(c.get("1.3.6.1.2.1.1.6.0"), {})  # noSuchObject filtré
            self.assertLess(ag.requests, 12)  # GETBULK : peu d'allers-retours
        finally:
            ag.close()

    def test_walk_v1_getnext_and_end_of_mib(self):
        ag = self._agent(("1",))
        try:
            with S.SnmpClient("127.0.0.1", port=ag.port, version="1", timeout=1) as c:
                self.assertEqual(len(c.walk("1.3.6.1.2.1.2.2.1.2")), 60)
                self.assertEqual(c.walk("1.3.6.1.2.1.31.1.1.1.15"), [((1, 3, 6, 1, 2, 1, 31, 1, 1, 1, 15, 1), 1000)])
                self.assertEqual(c.walk("1.3.6.1.4"), [])  # au-delà de la fin
        finally:
            ag.close()

    def test_timeout_on_wrong_community(self):
        ag = self._agent(("2c",))
        try:
            with S.SnmpClient("127.0.0.1", port=ag.port, community="faux", timeout=0.2, retries=1) as c:
                with self.assertRaises(S.SnmpTimeout):
                    c.get("1.3.6.1.2.1.1.5.0")
        finally:
            ag.close()


if __name__ == "__main__":
    unittest.main()
