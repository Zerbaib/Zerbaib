"""Client minimal pour l'API RouterOS (port 8728, ou 8729 en TLS).

Protocole : https://help.mikrotik.com/docs/display/ROS/API
Une « phrase » = suite de « mots » préfixés par leur longueur, terminée par un mot vide.
Réponses : !re (une ligne de résultat), !done, !trap (erreur), !fatal, !empty.
"""

from __future__ import annotations

import hashlib
import socket
import ssl
from typing import Iterable


class RosError(Exception):
    pass


class RosTrap(RosError):
    """Erreur renvoyée par RouterOS (!trap) : commande inconnue, droits insuffisants..."""


def encode_length(n: int) -> bytes:
    if n < 0x80:
        return bytes([n])
    if n < 0x4000:
        return (n | 0x8000).to_bytes(2, "big")
    if n < 0x200000:
        return (n | 0xC00000).to_bytes(3, "big")
    if n < 0x10000000:
        return (n | 0xE0000000).to_bytes(4, "big")
    return b"\xf0" + n.to_bytes(4, "big")


def encode_word(word: str) -> bytes:
    data = word.encode("utf-8")
    return encode_length(len(data)) + data


def _decode_text(data: bytes) -> str:
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace")


class RouterOS:
    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        port: int | None = None,
        tls: bool = False,
        tls_verify: bool = True,
        timeout: float = 10.0,
    ):
        self.host = host
        self.username = username
        self.password = password
        self.port = port or (8729 if tls else 8728)
        self.tls = tls
        self.tls_verify = tls_verify
        self.timeout = timeout
        self.sock: socket.socket | None = None
        self._buf = b""

    # -- connexion ---------------------------------------------------------
    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.close()

    def connect(self) -> None:
        raw = socket.create_connection((self.host, self.port), timeout=self.timeout)
        if self.tls:
            ctx = ssl.create_default_context()
            if not self.tls_verify:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            raw = ctx.wrap_socket(raw, server_hostname=self.host)
        self.sock = raw
        try:
            self._login()
        except BaseException:
            self.close()
            raise

    def close(self) -> None:
        if self.sock:
            try:
                self.sock.close()
            finally:
                self.sock = None

    def _login(self) -> None:
        replies = self._talk(["/login", f"=name={self.username}", f"=password={self.password}"])
        # RouterOS < 6.43 : authentification par défi MD5 (=ret=)
        for kind, attrs in replies:
            if kind == "!done" and "ret" in attrs:
                challenge = bytes.fromhex(attrs["ret"])
                digest = hashlib.md5(b"\x00" + self.password.encode() + challenge).hexdigest()
                self._talk(["/login", f"=name={self.username}", f"=response=00{digest}"])

    # -- bas niveau ----------------------------------------------------------
    def _send(self, words: Iterable[str]) -> None:
        assert self.sock is not None, "non connecté"
        payload = b"".join(encode_word(w) for w in words) + b"\x00"
        self.sock.sendall(payload)

    def _recv_exact(self, n: int) -> bytes:
        assert self.sock is not None
        while len(self._buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise RosError("connexion fermée par le routeur")
            self._buf += chunk
        data, self._buf = self._buf[:n], self._buf[n:]
        return data

    def _read_length(self) -> int:
        b = self._recv_exact(1)[0]
        if b < 0x80:
            return b
        if b < 0xC0:
            return ((b & 0x3F) << 8) | self._recv_exact(1)[0]
        if b < 0xE0:
            rest = self._recv_exact(2)
            return ((b & 0x1F) << 16) | int.from_bytes(rest, "big")
        if b < 0xF0:
            rest = self._recv_exact(3)
            return ((b & 0x0F) << 24) | int.from_bytes(rest, "big")
        return int.from_bytes(self._recv_exact(4), "big")

    def _read_sentence(self) -> list[str]:
        words = []
        while True:
            n = self._read_length()
            if n == 0:
                return words
            words.append(_decode_text(self._recv_exact(n)))

    def _talk(self, words: list[str]) -> list[tuple[str, dict[str, str]]]:
        self._send(words)
        replies: list[tuple[str, dict[str, str]]] = []
        trap: str | None = None
        while True:
            sentence = self._read_sentence()
            if not sentence:
                continue
            kind, attrs = sentence[0], {}
            for w in sentence[1:]:
                if w.startswith("="):
                    key, _, val = w[1:].partition("=")
                    attrs[key] = val
                elif w.startswith(".tag="):
                    attrs[".tag"] = w[5:]
            if kind == "!fatal":
                raise RosError(sentence[1] if len(sentence) > 1 else "erreur fatale")
            if kind == "!trap":
                trap = attrs.get("message", "erreur")
                continue
            replies.append((kind, attrs))
            # !empty (RouterOS ≥ 7.18, aucun résultat) est lui aussi suivi de !done
            if kind == "!done":
                break
        if trap is not None:
            raise RosTrap(trap)
        return replies

    # -- haut niveau ---------------------------------------------------------
    def call(self, path: str, *args: str, **params) -> list[dict[str, str]]:
        """Exécute une commande, ex. call('/ip/neighbor/print').

        Les paramètres nommés deviennent des attributs `=clé=valeur`
        (les `_` du nom sont convertis en `-`).
        """
        words = [path]
        for k, v in params.items():
            if isinstance(v, bool):
                v = "yes" if v else "no"
            words.append(f"={k.replace('_', '-')}={v}")
        words.extend(args)
        return [attrs for kind, attrs in self._talk(words) if kind == "!re"]

    def print(self, menu: str, proplist: list[str] | None = None) -> list[dict[str, str]]:
        """Équivalent de `menu print`. Renvoie [] si le menu n'existe pas (paquet absent)."""
        args = [f"=.proplist={','.join(proplist)}"] if proplist else []
        try:
            return self.call(f"{menu.rstrip('/')}/print", *args)
        except RosTrap as e:
            msg = str(e).lower()
            if "no such command" in msg or "unknown" in msg:
                return []
            raise


def as_bool(value: str | None) -> bool | None:
    if value is None:
        return None
    return value.lower() in ("true", "yes")
