"""Tests de bout en bout : config TOML, CLI `scan` contre de faux équipements, serveur web."""

import base64
import contextlib
import http.client
import io
import json
import os
import tempfile
import threading
import time
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path

from netmap import cli
from netmap.config import ConfigError, load
from netmap.demo import demo_config, demo_raw
from netmap.server import Scanner, make_handler
from netmap.store import Store
from netmap.topology import build

from .fakes import FakeRouterOS, FakeSnmpAgent, Gauge, mac_bytes, mac_index
from .test_collectors import ROS_MENUS


class ConfigTest(unittest.TestCase):
    def test_env_substitution_and_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp, "netmap.toml")
            p.write_text("""
[routeros]
username = "netmap"
password = "${NETMAP_ROS_PASSWORD}"

[snmp]
community = "lecture"

[[device]]
name = "R1"
host = "192.168.200.1"
type = "routeros"
wan_port = "ether1"

[[device]]
name = "SW1"
host = "192.168.200.3"
type = "snmp"
snmp = { version = "1" }

[[subnet]]
cidr = "10.0.0.0/8"
kind = "server"

[[endpoint]]
mac = "aa-bb-cc-dd-ee-ff"
name = "Onduleur"
kind = "iot"
""")
            os.environ["NETMAP_ROS_PASSWORD"] = "s3cr3t"
            try:
                cfg = load(p)
            finally:
                del os.environ["NETMAP_ROS_PASSWORD"]
            r1, sw1 = cfg.devices
            self.assertEqual((r1.username, r1.password, r1.role), ("netmap", "s3cr3t", "router"))
            self.assertEqual((sw1.role, sw1.snmp.version, sw1.snmp.community), ("switch", "1", "lecture"))
            self.assertEqual(cfg.endpoints[0].mac, "AA:BB:CC:DD:EE:FF")
            with self.assertRaises(ConfigError):
                load(p)  # variable d'environnement absente


class EndToEndScanTest(unittest.TestCase):
    """`netmap scan` contre un faux RouterOS et un faux switch SwOS (SNMP v1)."""

    def test_cli_scan(self):
        menus = dict(ROS_MENUS)
        ros = FakeRouterOS(menus, monitor={"sfp-sfpplus1": "10Gbps", "ether1": "1Gbps"})
        # Le CSS326 voit le routeur sur Port26 (SFP1+) et le NAS sur Port5
        names = {i: f"Port{i}" for i in range(1, 27)}
        data = {"1.3.6.1.2.1.1.5.0": "SW1-CSS326", "1.3.6.1.2.1.1.1.0": "CSS326-24G-2S+",
                "1.3.6.1.2.1.17.1.1.0": mac_bytes("74:4D:28:30:00:01")}
        for i, n in names.items():
            data[f"1.3.6.1.2.1.2.2.1.2.{i}"] = n
            data[f"1.3.6.1.2.1.2.2.1.8.{i}"] = 1 if i in (5, 26) else 2
            data[f"1.3.6.1.2.1.31.1.1.1.15.{i}"] = Gauge(10000 if i == 26 else 1000)
            data[f"1.3.6.1.2.1.17.1.4.1.2.{i}"] = i
        for mac, port in (("48:8F:5A:10:00:02", 26), ("00:08:9B:AA:00:01", 5)):
            idx = ".".join(map(str, mac_index(mac)))
            data[f"1.3.6.1.2.1.17.4.3.1.2.{idx}"] = port
            data[f"1.3.6.1.2.1.17.4.3.1.3.{idx}"] = 3
        snmp = FakeSnmpAgent(data, versions=("1",))
        try:
            with tempfile.TemporaryDirectory() as tmp:
                cfgp = Path(tmp, "netmap.toml")
                cfgp.write_text(f"""
[general]
reverse_dns = false
database = "{tmp}/netmap.db"

[[device]]
name = "R1"
host = "127.0.0.1"
type = "routeros"
port = {ros.port}
username = "netmap"
password = "secret"
wan_port = "ether1"
timeout = 3

[[device]]
name = "SW1"
host = "127.0.0.1"
type = "snmp"
snmp = {{ version = "1", port = {snmp.port}, timeout = 1 }}

[[subnet]]
cidr = "10.0.0.0/8"
kind = "server"
""")
                out = io.StringIO()
                dump = Path(tmp, "raw.json")
                with contextlib.redirect_stdout(out):
                    rc = cli.main(["-c", str(cfgp), "scan", "--dump", str(dump)])
                text = out.getvalue()
                self.assertEqual(rc, 0, text)
                self.assertIn("sfp-sfpplus1→Port26 10G", text)
                self.assertIn("SW1-CSS326", text)
                self.assertIn("10.0.0.10", text)
                self.assertTrue(json.loads(dump.read_text())["devices"])
                # rejouer hors ligne
                out2 = io.StringIO()
                with contextlib.redirect_stdout(out2):
                    self.assertEqual(cli.main(["-c", str(cfgp), "build", str(dump)]), 0)
                self.assertIn("sfp-sfpplus1→Port26", out2.getvalue())
                # export Graphviz depuis la base
                out3 = io.StringIO()
                with contextlib.redirect_stdout(out3):
                    self.assertEqual(cli.main(["-c", str(cfgp), "export", "--format", "dot"]), 0)
                self.assertIn('"dev:R1" -- "dev:SW1"', out3.getvalue())
        finally:
            ros.close()
            snmp.close()


class WebServerTest(unittest.TestCase):
    def setUp(self):
        self.store = Store(":memory:")
        self.cfg = demo_config()
        self.cfg.web_username, self.cfg.web_password = "admin", "motdepasse"

        def run():
            raw = demo_raw()
            return self.store.save_scan(raw.to_dict(), build(raw, self.cfg, resolve_dns=False))

        run()
        self.scanner = Scanner(run)
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.store, self.scanner, self.cfg))
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        self.port = self.httpd.server_address[1]
        self.auth = {"Authorization": "Basic " + base64.b64encode(b"admin:motdepasse").decode()}

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.store.close()

    def req(self, method, path, body=None, headers=None, auth=True):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        h = dict(self.auth if auth else {})
        h.update(headers or {})
        c.request(method, path, body=json.dumps(body) if body is not None else None, headers=h)
        r = c.getresponse()
        data = r.read()
        c.close()
        return r.status, data

    def test_auth_required(self):
        self.assertEqual(self.req("GET", "/api/graph", auth=False)[0], 401)
        self.assertEqual(self.req("GET", "/api/graph", headers={"Authorization": "Basic eDp5"}, auth=False)[0], 401)

    def test_pages_and_graph(self):
        st, body = self.req("GET", "/")
        self.assertEqual(st, 200)
        self.assertIn(b"cytoscape.min.js", body)
        self.assertEqual(self.req("GET", "/static/app.js")[0], 200)
        self.assertEqual(self.req("GET", "/vendor/cytoscape.min.js")[0], 200)
        st, body = self.req("GET", "/api/graph")
        g = json.loads(body)
        self.assertEqual(st, 200)
        self.assertEqual(g["stats"]["managed"], 4)
        self.assertIn("positions", g)
        self.assertEqual(self.req("GET", "/static/../server.py")[0], 403)
        self.assertEqual(self.req("GET", "/static/%2e%2e/server.py")[0] in (403, 404), True)
        st, body = self.req("GET", f"/api/export/{g['scan_id']}.dot")
        self.assertEqual(st, 200)
        self.assertIn(b"graph topologie", body)

    def test_positions_and_scan(self):
        self.assertEqual(self.req("PUT", "/api/positions", {"dev:R1": {"x": 10, "y": 20}})[0], 200)
        g = json.loads(self.req("GET", "/api/graph")[1])
        self.assertEqual(g["positions"]["dev:R1"], {"x": 10.0, "y": 20.0})
        self.assertEqual(self.req("PUT", "/api/positions", {"x": 1}, headers={"Origin": "http://evil.example"})[0], 403)
        self.assertEqual(self.req("DELETE", "/api/positions")[0], 200)
        st, _ = self.req("POST", "/api/scan")
        self.assertIn(st, (202, 409))
        for _ in range(50):
            s = json.loads(self.req("GET", "/api/status")[1])
            if not s["running"]:
                break
            time.sleep(0.05)
        self.assertIsNone(s["last_error"])
        g = json.loads(self.req("GET", "/api/graph")[1])
        self.assertEqual(g["diff"]["new_nodes"], [])
        self.assertEqual(len(json.loads(self.req("GET", "/api/scans")[1])), 2)


if __name__ == "__main__":
    unittest.main()
