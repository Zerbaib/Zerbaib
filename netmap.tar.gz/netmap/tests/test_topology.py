import copy
import unittest

from netmap.demo import demo_config, demo_raw
from netmap.export import to_dot
from netmap.model import RawScan
from netmap.store import Store
from netmap.topology import build, text_tree


def links_by_pair(g):
    return {tuple(sorted((l["source"], l["target"]))): l for l in g["links"]}


def ports(link, a):
    """Ports (côté a, côté b) du premier membre."""
    m = link["members"][0]
    return (m["source_port"], m["target_port"]) if link["source"] == a else (m["target_port"], m["source_port"])


class DemoTopologyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.g = build(demo_raw(), demo_config(), resolve_dns=False)
        cls.nodes = {n["id"]: n for n in cls.g["nodes"]}
        cls.links = links_by_pair(cls.g)

    def test_infrastructure_links(self):
        L = self.links
        r1sw1 = L[("dev:R1", "dev:SW1")]
        self.assertEqual(ports(r1sw1, "dev:R1"), ("sfp-sfpplus1", "SFP1+"))
        self.assertEqual(r1sw1["speed"], 10000)
        self.assertTrue(r1sw1["inferred"])  # SwOS : pas de LLDP -> tables MAC
        self.assertEqual(ports(L[("dev:SW1", "dev:SW2")], "dev:SW1"), ("Port24", "g24"))
        r2sw2 = L[("dev:R2", "dev:SW2")]
        self.assertEqual(ports(r2sw2, "dev:R2"), ("ether2", "g1"))
        self.assertFalse(r2sw2["inferred"])
        blocked = L[("dev:R1", "dev:SW2")]
        self.assertTrue(blocked["blocked"])
        self.assertEqual(ports(blocked, "dev:R1"), ("ether2", "g2"))

    def test_no_false_links_from_mndp_broadcast(self):
        # R1 et R2 se voient en MNDP à travers les switchs, mais ne sont pas reliés en direct
        self.assertNotIn(("dev:R1", "dev:R2"), self.links)
        infra = [l for l in self.g["links"] if l["kind"] == "infra"]
        self.assertEqual(len(infra), 4)

    def test_wan(self):
        self.assertEqual(self.nodes["wan"]["kind"], "internet")
        self.assertIn(("dev:R1", "wan"), self.links)
        self.assertIn(("dev:R2", "wan"), self.links)

    def test_hypervisors_dual_homed_and_guests(self):
        L = self.links
        pve1 = "pve:homelab/pve1"
        self.assertEqual(self.nodes[pve1]["kind"], "hypervisor")
        self.assertEqual(ports(L[("dev:SW1", pve1)], "dev:SW1")[0], "Port1")
        self.assertEqual(ports(L[("dev:SW2", pve1)], "dev:SW2")[0], "g3")  # 2e carte (MAC sœur / LLDP)
        self.assertEqual(len(self.nodes[pve1]["macs"]), 2)
        guests = [n for n in self.g["nodes"] if n["kind"] in ("vm", "ct")]
        self.assertEqual(len(guests), 9)
        for gn in guests:
            self.assertIn(tuple(sorted((gn["parent"], gn["id"]))), L)
        jelly = next(n for n in guests if n["label"] == "jellyfin")
        self.assertEqual(jelly["parent"], "pve:homelab/pve2")
        stopped = next(n for n in guests if n["label"] == "status-page")
        self.assertEqual(stopped["status"], "stopped")

    def test_endpoints_and_unmanaged(self):
        by_label = {n["label"]: n for n in self.g["nodes"]}
        self.assertEqual(by_label["nas-omv"]["kind"], "server")
        self.assertEqual(by_label["nas-omv"]["attach"], ["SW1:Port5"])
        self.assertEqual(by_label["pc-fixe"]["kind"], "client")
        self.assertTrue(by_label["Pixel-8"]["random_mac"])
        hub = "unmanaged:SW1:Port10"
        self.assertEqual(self.nodes[hub]["kind"], "unmanaged")
        for name in ("HP-LaserJet", "LG-TV", "raspberrypi"):
            self.assertIn(tuple(sorted((hub, by_label[name]["id"]))), self.links)
        cap = by_label["cAP-salon"]
        self.assertEqual(cap["kind"], "ap")
        for name in ("Pixel-8", "MacBook-Air"):
            self.assertIn(tuple(sorted((cap["id"], by_label[name]["id"]))), self.links)
        unknown = next(n for n in self.g["nodes"] if n["kind"] == "unknown")
        self.assertEqual(unknown["attach"], ["SW1:Port15"])

    def test_ports_view(self):
        sw2 = self.nodes["dev:SW2"]
        rows = {p["name"]: p for p in sw2["ports"]}
        self.assertEqual(rows["g1"]["peers"][0]["label"], "R2-RB3011")
        self.assertTrue(rows["g2"]["stp_blocked"])
        self.assertTrue(rows["g24"]["uplink"])
        self.assertEqual(rows["g12"]["peers"][0]["label"], "cAP-salon")

    def test_exports(self):
        txt = text_tree(self.g)
        self.assertIn("SW1-CSS326", txt)
        self.assertIn("STP bloqué", txt)
        dot = to_dot(self.g)
        self.assertTrue(dot.startswith("graph topologie {"))
        self.assertIn('"dev:R1" -- "dev:SW1"', dot)


class InferenceTest(unittest.TestCase):
    def test_fdb_only_without_any_neighbor_protocol(self):
        raw = demo_raw()
        for d in raw.devices:
            d.neighbors = []
        g = build(raw, demo_config(), resolve_dns=False)
        L = links_by_pair(g)
        self.assertEqual(ports(L[("dev:R1", "dev:SW1")], "dev:R1"), ("sfp-sfpplus1", "SFP1+"))
        self.assertEqual(ports(L[("dev:SW1", "dev:SW2")], "dev:SW1"), ("Port24", "g24"))
        self.assertEqual(ports(L[("dev:R2", "dev:SW2")], "dev:R2"), ("ether2", "g1"))
        self.assertNotIn(("dev:R1", "dev:R2"), L)
        # sans LLDP, le lien bloqué par STP est invisible (aucune MAC apprise dessus)
        self.assertNotIn(("dev:R1", "dev:SW2"), L)

    def test_unreachable_device_keeps_graph_usable(self):
        raw = demo_raw()
        sw1 = next(d for d in raw.devices if d.id == "SW1")
        sw1.reachable, sw1.fdb, sw1.neighbors, sw1.ports = False, [], [], {}
        sw1.errors = ["SnmpTimeout: pas de réponse"]
        g = build(raw, demo_config(), resolve_dns=False)
        nodes = {n["id"]: n for n in g["nodes"]}
        self.assertEqual(nodes["dev:SW1"]["status"], "unreachable")
        self.assertIn("SW1", g["errors"])
        self.assertEqual(g["stats"]["unreachable"], ["SW1-CSS326"])

    def test_roundtrip_raw_json(self):
        raw = demo_raw()
        again = RawScan.from_dict(copy.deepcopy(raw.to_dict()))
        g1 = build(raw, demo_config(), resolve_dns=False)
        g2 = build(again, demo_config(), resolve_dns=False)
        self.assertEqual([l["id"] for l in g1["links"]], [l["id"] for l in g2["links"]])


class StoreDiffTest(unittest.TestCase):
    def test_diff_between_scans(self):
        st = Store(":memory:")
        cfg = demo_config()
        raw1 = demo_raw()
        st.save_scan(raw1.to_dict(), build(raw1, cfg, resolve_dns=False))
        raw2 = demo_raw()
        # le PC fixe disparaît, le NAS change de port
        for d in raw2.devices:
            d.fdb = [e for e in d.fdb if e.mac != "D8:BB:C1:12:34:56"]
        sw1 = next(d for d in raw2.devices if d.id == "SW1")
        for e in sw1.fdb:
            if e.mac == "00:08:9B:AA:00:01":
                e.port = "Port6"
        sid = st.save_scan(raw2.to_dict(), build(raw2, cfg, resolve_dns=False))
        g = st.graph_with_diff(sid)
        gone = [n["label"] for n in g["diff"]["gone_nodes"]]
        self.assertEqual(gone, ["pc-fixe"])
        moved = {m["label"]: m for m in g["diff"]["moved"]}
        self.assertEqual(moved["nas-omv"]["to"], ["SW1:Port6"])
        self.assertEqual(len(st.list_scans()), 2)
        st.save_positions({"dev:R1": {"x": 1, "y": 2}})
        self.assertEqual(st.positions(), {"dev:R1": {"x": 1.0, "y": 2.0}})


if __name__ == "__main__":
    unittest.main()
