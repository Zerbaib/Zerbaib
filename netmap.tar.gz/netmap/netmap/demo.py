"""Jeu de données de démonstration réaliste (sert aussi aux tests).

On décrit un réseau physique (calqué sur un homelab MikroTik + Proxmox), puis on
SIMULE ce que chaque équipement verrait réellement : tables MAC selon l'arbre
STP, voisins LLDP (lien direct uniquement), MNDP (broadcast, traverse les
switchs), ARP et baux DHCP. Le moteur de topologie doit retrouver le réseau
d'origine à partir de ces seules données.
"""

from __future__ import annotations

from collections import deque
from datetime import datetime, timezone

from .config import Config, from_dict
from .model import ArpEntry, DeviceData, FdbEntry, Guest, HvNode, HypervisorData, Lease, Neighbor, Port, RawScan

# --- équipements gérés ------------------------------------------------------------
MANAGED = {
    "R1": dict(name="R1-RB4011", host="192.168.200.1", platform="routeros", role="router", model="RB4011iGS+",
               version="7.20.1 (stable)", mac="48:8F:5A:10:00:01", wan="ether1", lldp=True, mndp=True, qvlan=True,
               ports=[f"ether{i}" for i in range(1, 11)] + ["sfp-sfpplus1"]),
    "R2": dict(name="R2-RB3011", host="192.168.200.2", platform="routeros", role="router", model="RB3011UiAS",
               version="7.20.1 (stable)", mac="48:8F:5A:20:00:01", wan="ether1", lldp=True, mndp=True, qvlan=True,
               ports=[f"ether{i}" for i in range(1, 11)] + ["sfp1"]),
    "SW1": dict(name="SW1-CSS326", host="192.168.200.3", platform="snmp", role="switch",
                model="CSS326-24G-2S+ SwOS 2.18", mac="74:4D:28:30:00:01", lldp=False, mndp=True, qvlan=False,
                ports=[f"Port{i}" for i in range(1, 25)] + ["SFP1+", "SFP2+"]),
    "SW2": dict(name="SW2-GS724T", host="192.168.200.4", platform="snmp", role="switch",
                model="GS724Tv4 ProSafe 24-port Gigabit Smart Switch", mac="A0:40:A0:40:00:01", lldp=True,
                mndp=False, qvlan=True, ports=[f"g{i}" for i in range(1, 25)] + ["g25", "g26"]),
}

# Liens physiques entre équipements gérés : (A, portA, B, portB, Mbps, port_bloqué_STP)
INFRA_LINKS = [
    ("R1", "sfp-sfpplus1", "SW1", "SFP1+", 10000, None),
    ("SW1", "Port24", "SW2", "g24", 1000, None),
    ("R2", "ether2", "SW2", "g1", 1000, None),
    ("R1", "ether2", "SW2", "g2", 1000, ("SW2", "g2")),  # lien redondant, bloqué par RSTP
]

# Appareils finaux : id -> dict(macs, ports=[(switch, port)], ip, hostname, vlan, ...)
ENDPOINTS = {
    "pve1": dict(macs=["58:47:CA:00:01:10", "58:47:CA:00:01:11"], ports=[("SW1", "Port1"), ("SW2", "g3")],
                 ip="10.0.0.1", vlan=100, lldpd=True),
    "pve2": dict(macs=["58:47:CA:00:02:10", "58:47:CA:00:02:11"], ports=[("SW1", "Port2"), ("SW2", "g4")],
                 ip="10.0.0.2", vlan=100),
    "pve3": dict(macs=["58:47:CA:00:03:10", "58:47:CA:00:03:11"], ports=[("SW1", "Port3"), ("SW2", "g5")],
                 ip="10.0.0.3", vlan=100),
    "nas": dict(macs=["00:08:9B:AA:00:01"], ports=[("SW1", "Port5")], ip="10.0.0.10", vlan=100, hostname="nas-omv"),
    "pc-fixe": dict(macs=["D8:BB:C1:12:34:56"], ports=[("SW2", "g10")], ip="192.168.0.20", vlan=10, hostname="pc-fixe"),
    "cap": dict(macs=["DC:2C:6E:50:00:01"], ports=[("SW2", "g12")], ip="192.168.255.20", vlan=1000,
                lldp_name="cAP-salon", lldp_caps=["bridge", "wlan-ap", "router"], mndp_name="cAP-salon"),
    "telephone": dict(macs=["7A:11:22:33:44:55"], behind="cap", ip="192.168.0.101", vlan=11, hostname="Pixel-8"),
    "portable": dict(macs=["3C:22:FB:66:77:88"], behind="cap", ip="192.168.0.102", vlan=11, hostname="MacBook-Air"),
    "imprimante": dict(macs=["00:1E:0B:44:55:66"], behind="desk", ip="192.168.0.50", vlan=10, hostname="HP-LaserJet"),
    "tv": dict(macs=["A8:23:FE:01:02:03"], behind="desk", ip="192.168.0.60", vlan=10, hostname="LG-TV"),
    "rpi": dict(macs=["DC:A6:32:0A:0B:0C"], behind="desk", ip="192.168.0.70", vlan=10, hostname="raspberrypi"),
    "iot": dict(macs=["24:0A:C4:99:88:77"], ports=[("SW1", "Port15")], vlan=1),
}
DESK_SWITCH_PORT = ("SW1", "Port10")  # switch de bureau non géré

GUESTS = [  # (vmid, nom, type, nœud, statut, vlan, ip)
    (101, "ns1", "lxc", "pve1", "running", 100, "10.53.53.1"),
    (102, "zabbix", "lxc", "pve1", "running", 100, "10.100.100.102"),
    (103, "jellyfin", "qemu", "pve2", "running", 100, "10.100.100.103"),
    (104, "coder", "qemu", "pve2", "running", 100, "10.100.100.104"),
    (105, "ns2", "lxc", "pve3", "running", 100, "10.53.53.2"),
    (106, "proxy", "lxc", "pve3", "running", 100, "10.100.100.106"),
    (107, "mail", "qemu", "pve3", "running", 100, "10.100.100.107"),
    (108, "status-page", "lxc", "pve1", "stopped", 100, None),
    (109, "netmap", "lxc", "pve2", "running", 1000, "192.168.255.10"),
]

DEMO_CONFIG = {
    "general": {"wan_label": "Internet (Livebox Orange)", "reverse_dns": False},
    "subnet": [
        {"cidr": "10.0.0.0/8", "kind": "server", "label": "VLAN 100 · serveurs"},
        {"cidr": "192.168.0.0/24", "kind": "client", "label": "VLAN 10/11 · clients"},
        {"cidr": "192.168.255.0/26", "kind": "management", "label": "VLAN 1000 · management"},
        {"cidr": "192.168.200.0/24", "kind": "management", "label": "Management (actuel)"},
    ],
    "device": [
        {"name": k, "host": v["host"], "type": v["platform"], "role": v["role"], **({"wan_port": v["wan"]} if v.get("wan") else {})}
        for k, v in MANAGED.items()
    ],
}


def demo_config() -> Config:
    return from_dict(DEMO_CONFIG)


def _speed(dev: str, port: str) -> int:
    for a, pa, b, pb, sp, _ in INFRA_LINKS:
        if (a, pa) == (dev, port) or (b, pb) == (dev, port):
            return sp
    if port.lower().startswith("sfp"):
        return 10000
    return 1000


def demo_raw() -> RawScan:
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    devs: dict[str, DeviceData] = {}
    used_ports: dict[str, set[str]] = {k: set() for k in MANAGED}
    for a, pa, b, pb, *_ in INFRA_LINKS:
        used_ports[a].add(pa)
        used_ports[b].add(pb)
    for ep in ENDPOINTS.values():
        for d, p in ep.get("ports", []):
            used_ports[d].add(p)
    used_ports[DESK_SWITCH_PORT[0]].add(DESK_SWITCH_PORT[1])

    for k, m in MANAGED.items():
        d = DeviceData(id=k, host=m["host"], platform=m["platform"], role=m["role"], name=m["name"],
                       model=m["model"], version=m.get("version"), wan_port=m.get("wan"),
                       macs=[m["mac"]], ips=[m["host"]], duration_s=0.4)
        for p in m["ports"]:
            up = p in used_ports[k] or p == m.get("wan")
            d.ports[p] = Port(name=p, type="sfp" if p.lower().startswith("sfp") else "ether",
                              up=up, speed_mbps=_speed(k, p) if up else None)
        devs[k] = d
    for a, pa, b, pb, sp, blocked in INFRA_LINKS:
        if blocked:
            devs[blocked[0]].ports[blocked[1]].stp_forwarding = False

    # --- arbre STP (liens actifs) -------------------------------------------------
    adj: dict[str, list[tuple[str, str]]] = {k: [] for k in MANAGED}  # dev -> [(voisin, port_local)]
    for a, pa, b, pb, _sp, blocked in INFRA_LINKS:
        if blocked:
            continue
        adj[a].append((b, pa))
        adj[b].append((a, pb))

    def port_towards(src: str, dst: str) -> str | None:
        if src == dst:
            return None
        q = deque([(src, None)])
        seen = {src}
        while q:
            cur, first = q.popleft()
            for nb, port in adj[cur]:
                if nb in seen:
                    continue
                f = first or port
                if nb == dst:
                    return f
                seen.add(nb)
                q.append((nb, f))
        return None

    # Où se trouve chaque MAC : (équipement géré, port) d'accès
    locations: list[tuple[str, str, str, int | None]] = []  # mac, dev, port, vlan
    for name, ep in ENDPOINTS.items():
        if "behind" in ep:
            where = [("SW2", "g12")] if ep["behind"] == "cap" else [DESK_SWITCH_PORT]
        else:
            where = ep["ports"]
        for i, mac in enumerate(ep["macs"]):
            dev, port = where[min(i, len(where) - 1)]
            locations.append((mac, dev, port, ep.get("vlan")))
    pve_mac = {n: ENDPOINTS[n]["macs"][0] for n in ("pve1", "pve2", "pve3")}
    guest_macs = {}
    for vmid, name, typ, node, status, vlan, ip in GUESTS:
        mac = f"BC:24:11:00:{vmid // 100:02X}:{vmid % 100:02X}"
        guest_macs[vmid] = mac
        if status == "running":
            dev, port = ENDPOINTS[node]["ports"][0]
            locations.append((mac, dev, port, vlan))

    for k in MANAGED:
        for mac, dev, port, vlan in locations:
            p = port if dev == k else port_towards(k, dev)
            if p:
                devs[k].fdb.append(FdbEntry(mac=mac, port=p, vlan=vlan if MANAGED[k]["qvlan"] else None))
        for other, om in MANAGED.items():
            p = port_towards(k, other)
            if p:
                devs[k].fdb.append(FdbEntry(mac=om["mac"], port=p, vlan=1000 if MANAGED[k]["qvlan"] else None))

    # --- voisins LLDP (lien direct, même bloqué par STP) -------------------------
    for a, pa, b, pb, *_ in INFRA_LINKS:
        for x, px, y, py in ((a, pa, b, pb), (b, pb, a, pa)):
            if MANAGED[x]["lldp"] and MANAGED[y]["lldp"]:
                both_ros = MANAGED[x]["platform"] == MANAGED[y]["platform"] == "routeros"
                devs[x].neighbors.append(Neighbor(
                    local_port=px, protocol="cdp,lldp,mndp" if both_ros else "lldp",
                    remote_name=MANAGED[y]["name"], remote_port=py, remote_mac=MANAGED[y]["mac"],
                    remote_ip=MANAGED[y]["host"], platform="MikroTik" if MANAGED[y]["platform"] == "routeros" else None,
                    caps=["bridge", "router"] if MANAGED[y]["role"] == "router" else ["bridge"]))
    cap = ENDPOINTS["cap"]
    devs["SW2"].neighbors.append(Neighbor(local_port="g12", protocol="lldp", remote_name=cap["lldp_name"],
                                          remote_port="ether1", remote_mac=cap["macs"][0], remote_ip=cap["ip"],
                                          platform="MikroTik RouterOS 7.20", caps=cap["lldp_caps"]))
    p1 = ENDPOINTS["pve1"]
    devs["SW2"].neighbors.append(Neighbor(local_port="g3", protocol="lldp", remote_name="pve1",
                                          remote_port="enp2s0", remote_mac=p1["macs"][0], remote_ip=p1["ip"],
                                          platform="Debian GNU/Linux 13 (trixie)", caps=["bridge", "station"]))

    # --- MNDP (broadcast : vu à travers les switchs, sur le port vers l'émetteur) --
    for k in MANAGED:
        if MANAGED[k]["platform"] != "routeros":
            continue
        for other, om in MANAGED.items():
            if other == k or not om["mndp"]:
                continue
            if any(n.remote_mac == om["mac"] for n in devs[k].neighbors):
                continue
            p = port_towards(k, other)
            if p:
                devs[k].neighbors.append(Neighbor(local_port=p, protocol="mndp", remote_name=om["name"],
                                                  remote_port="SFP1+" if other == "SW1" else None,
                                                  remote_mac=om["mac"], remote_ip=om["host"],
                                                  platform="MikroTik", model=om["model"].split()[0]))
        p = port_towards(k, "SW2")
        devs[k].neighbors.append(Neighbor(local_port=p, protocol="mndp", remote_name=cap["mndp_name"],
                                          remote_mac=cap["macs"][0], remote_ip=cap["ip"], platform="MikroTik",
                                          model="cAP ax"))

    # --- ARP / DHCP -----------------------------------------------------------------
    for name, ep in ENDPOINTS.items():
        if not ep.get("ip"):
            continue
        for r in ("R1", "R2"):
            devs[r].arp.append(ArpEntry(ip=ep["ip"], mac=ep["macs"][0], interface="BR1"))
        if ep.get("hostname"):
            devs["R1"].leases.append(Lease(ip=ep["ip"], mac=ep["macs"][0], hostname=ep["hostname"]))
    for vmid, name, typ, node, status, vlan, ip in GUESTS:
        if ip and status == "running":
            devs["R1"].arp.append(ArpEntry(ip=ip, mac=guest_macs[vmid], interface=f"vlan{vlan}"))

    # --- Proxmox --------------------------------------------------------------------
    hv = HypervisorData(cluster="homelab")
    for n in ("pve1", "pve2", "pve3"):
        hv.nodes.append(HvNode(name=n, ip=ENDPOINTS[n]["ip"], online=True))
    for vmid, name, typ, node, status, vlan, ip in GUESTS:
        hv.guests.append(Guest(vmid=vmid, name=name, type=typ, node=node, status=status,
                               macs=[guest_macs[vmid]], vlans=[vlan], ips=[ip] if ip else []))
    _ = pve_mac
    return RawScan(ts=ts, devices=list(devs.values()), hypervisors=[hv], duration_s=1.7)
