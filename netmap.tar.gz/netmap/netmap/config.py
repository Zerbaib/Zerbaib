"""Lecture de la configuration TOML (tomllib, inclus dans Python 3.11+).

Les valeurs de la forme ${NOM} sont remplacées par la variable d'environnement NOM,
ce qui évite de laisser les mots de passe en clair dans le fichier
(ex. via un EnvironmentFile systemd).
"""

from __future__ import annotations

import ipaddress
import os
import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

from .util import norm_mac

_ENV = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


class ConfigError(Exception):
    pass


def _expand(value):
    if isinstance(value, str):
        def repl(m):
            name = m.group(1)
            if name not in os.environ:
                raise ConfigError(f"Variable d'environnement manquante : {name}")
            return os.environ[name]
        return _ENV.sub(repl, value)
    if isinstance(value, list):
        return [_expand(v) for v in value]
    if isinstance(value, dict):
        return {k: _expand(v) for k, v in value.items()}
    return value


@dataclass
class SnmpAuth:
    version: str = "2c"  # "1" ou "2c"
    community: str = "public"
    port: int = 161
    timeout: float = 2.0
    retries: int = 2
    max_repetitions: int = 25


@dataclass
class DeviceConfig:
    name: str
    host: str
    type: str  # "routeros" | "snmp"
    role: str = "switch"  # "router" | "switch" | "ap"
    # RouterOS
    username: str = ""
    password: str = ""
    port: int | None = None
    tls: bool = False
    tls_verify: bool = True
    # SNMP
    snmp: SnmpAuth = field(default_factory=SnmpAuth)
    # Divers
    wan_port: str | None = None
    timeout: float = 10.0
    label: str | None = None


@dataclass
class ProxmoxConfig:
    host: str
    token_id: str
    token_secret: str
    port: int = 8006
    tls_verify: bool = False
    guest_agent: bool = True
    timeout: float = 10.0


@dataclass
class ManualEndpoint:
    mac: str
    name: str | None = None
    kind: str | None = None
    note: str | None = None


@dataclass
class ManualLink:
    a: str
    a_port: str | None
    b: str
    b_port: str | None
    speed: str | None = None


@dataclass
class SubnetRule:
    network: ipaddress.IPv4Network | ipaddress.IPv6Network
    kind: str
    label: str | None = None


@dataclass
class Config:
    devices: list[DeviceConfig]
    proxmox: list[ProxmoxConfig] = field(default_factory=list)
    endpoints: list[ManualEndpoint] = field(default_factory=list)
    links: list[ManualLink] = field(default_factory=list)
    subnets: list[SubnetRule] = field(default_factory=list)
    # Topologie
    wan_label: str = "Internet"
    unmanaged_threshold: int = 2  # nb d'appareils distincts sur un port => switch/AP non géré
    merge_sibling_nics: bool = True
    reverse_dns: bool = True
    hide_macs: list[str] = field(default_factory=list)
    oui_file: str | None = None
    # Stockage / web
    database: str = "netmap.db"
    retention: int = 500
    web_host: str = "127.0.0.1"
    web_port: int = 8650
    web_username: str | None = None
    web_password: str | None = None
    scan_interval: int = 0  # secondes ; 0 = pas de scan automatique par `serve`
    parallel: int = 8
    source_path: Path | None = None


def _snmp_from(d: dict, defaults: SnmpAuth) -> SnmpAuth:
    base = dict(defaults.__dict__)
    base.update({k: v for k, v in d.items() if k in base})
    base["version"] = str(base["version"]).lower().removeprefix("v")
    if base["version"] not in ("1", "2c"):
        raise ConfigError("SNMP : seules les versions 1 et 2c sont gérées")
    return SnmpAuth(**base)


def load(path: str | os.PathLike) -> Config:
    p = Path(path)
    if not p.is_file():
        raise ConfigError(f"Fichier de configuration introuvable : {p}")
    with p.open("rb") as fh:
        raw = tomllib.load(fh)
    raw = _expand(raw)
    return from_dict(raw, source=p)


def from_dict(raw: dict, source: Path | None = None) -> Config:
    general = raw.get("general", {})
    web = raw.get("web", {})
    snmp_defaults = _snmp_from(raw.get("snmp", {}), SnmpAuth())
    ros_defaults = raw.get("routeros", {})

    devices: list[DeviceConfig] = []
    seen = set()
    for d in raw.get("device", []):
        if "name" not in d or "host" not in d or "type" not in d:
            raise ConfigError(f"[[device]] incomplet (name, host, type requis) : {d}")
        typ = d["type"].lower()
        if typ not in ("routeros", "snmp"):
            raise ConfigError(f"type inconnu pour {d['name']} : {typ} (routeros|snmp)")
        if d["name"] in seen:
            raise ConfigError(f"Nom d'équipement en double : {d['name']}")
        seen.add(d["name"])
        merged = {**(ros_defaults if typ == "routeros" else {}), **d}
        devices.append(
            DeviceConfig(
                name=merged["name"],
                host=merged["host"],
                type=typ,
                role=merged.get("role", "router" if typ == "routeros" and merged.get("wan_port") else "switch"),
                username=merged.get("username", ""),
                password=merged.get("password", ""),
                port=merged.get("port"),
                tls=bool(merged.get("tls", False)),
                tls_verify=bool(merged.get("tls_verify", True)),
                snmp=_snmp_from(merged.get("snmp", {}), snmp_defaults),
                wan_port=merged.get("wan_port"),
                timeout=float(merged.get("timeout", 10.0)),
                label=merged.get("label"),
            )
        )

    proxmox = []
    for px in raw.get("proxmox", []):
        try:
            proxmox.append(
                ProxmoxConfig(
                    host=px["host"],
                    token_id=px["token_id"],
                    token_secret=px["token_secret"],
                    port=int(px.get("port", 8006)),
                    tls_verify=bool(px.get("tls_verify", False)),
                    guest_agent=bool(px.get("guest_agent", True)),
                    timeout=float(px.get("timeout", 10.0)),
                )
            )
        except KeyError as e:
            raise ConfigError(f"[[proxmox]] : clé manquante {e}") from None

    endpoints = []
    for e in raw.get("endpoint", []):
        mac = norm_mac(e.get("mac"))
        if not mac:
            raise ConfigError(f"[[endpoint]] : MAC invalide : {e.get('mac')}")
        endpoints.append(ManualEndpoint(mac=mac, name=e.get("name"), kind=e.get("kind"), note=e.get("note")))

    links = []
    for lk in raw.get("link", []):
        try:
            links.append(ManualLink(a=lk["a"], a_port=lk.get("a_port"), b=lk["b"], b_port=lk.get("b_port"), speed=lk.get("speed")))
        except KeyError as e:
            raise ConfigError(f"[[link]] : clé manquante {e}") from None

    subnets = []
    for s in raw.get("subnet", []):
        try:
            subnets.append(SubnetRule(network=ipaddress.ip_network(s["cidr"], strict=False), kind=s.get("kind", "client"), label=s.get("label")))
        except (KeyError, ValueError) as e:
            raise ConfigError(f"[[subnet]] invalide : {s} ({e})") from None

    return Config(
        devices=devices,
        proxmox=proxmox,
        endpoints=endpoints,
        links=links,
        subnets=subnets,
        wan_label=general.get("wan_label", "Internet"),
        unmanaged_threshold=int(general.get("unmanaged_threshold", 2)),
        merge_sibling_nics=bool(general.get("merge_sibling_nics", True)),
        reverse_dns=bool(general.get("reverse_dns", True)),
        hide_macs=[m for m in (norm_mac(x) for x in general.get("hide_macs", [])) if m],
        oui_file=general.get("oui_file"),
        database=general.get("database", "netmap.db"),
        retention=int(general.get("retention", 500)),
        web_host=web.get("host", "127.0.0.1"),
        web_port=int(web.get("port", 8650)),
        web_username=web.get("username"),
        web_password=web.get("password"),
        scan_interval=int(web.get("scan_interval", 0)),
        parallel=int(general.get("parallel", 8)),
        source_path=source,
    )
