"""Petites fonctions partagées : MAC, débits, fabricants (OUI), journalisation."""

from __future__ import annotations

import logging
import re
from pathlib import Path

log = logging.getLogger("netmap")

_HEX = re.compile(r"[0-9a-fA-F]")


def norm_mac(value) -> str | None:
    """Normalise une MAC (str, bytes, 'aa-bb..', 'aabb.ccdd..') en 'AA:BB:CC:DD:EE:FF'."""
    if value is None:
        return None
    if isinstance(value, (bytes, bytearray)):
        if len(value) != 6:
            # Certains agents renvoient la MAC sous forme de texte ASCII
            try:
                return norm_mac(value.decode("ascii"))
            except UnicodeDecodeError:
                return None
        return ":".join(f"{b:02X}" for b in value)
    digits = "".join(_HEX.findall(str(value)))
    if len(digits) != 12:
        return None
    mac = ":".join(digits[i : i + 2] for i in range(0, 12, 2)).upper()
    if mac in ("00:00:00:00:00:00", "FF:FF:FF:FF:FF:FF"):
        return None
    return mac


def mac_int(mac: str) -> int:
    return int(mac.replace(":", ""), 16)


def is_random_mac(mac: str) -> bool:
    """Bit « administré localement » : MAC aléatoire (téléphones) ou virtuelle."""
    return bool(int(mac[0:2], 16) & 0x02)


def is_multicast_mac(mac: str) -> bool:
    return bool(int(mac[0:2], 16) & 0x01)


_RATE = re.compile(r"^\s*([\d.]+)\s*([kKmMgGtT]?)(?:bps|b/s|bit/s)?\s*$")


def parse_rate_mbps(value) -> int | None:
    """'1Gbps' -> 1000, '10Gbps' -> 10000, '100Mbps' -> 100, '2.5Gbps' -> 2500."""
    if value in (None, ""):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    m = _RATE.match(str(value))
    if not m:
        return None
    num = float(m.group(1))
    unit = m.group(2).lower()
    factor = {"": 1e-6, "k": 1e-3, "m": 1, "g": 1000, "t": 1_000_000}[unit]
    return int(round(num * factor))


def fmt_speed(mbps: int | None) -> str:
    if not mbps:
        return ""
    if mbps >= 1000:
        g = mbps / 1000
        return f"{g:g}G"
    return f"{mbps}M"


# --- Fabricants (OUI) -------------------------------------------------------
# Petite table intégrée ; complétée automatiquement par le fichier IEEE si présent
# (paquet Debian `ieee-data` -> /usr/share/ieee-data/oui.txt) ou `manuf` de Wireshark.
_BUILTIN_OUI = {
    "BC:24:11": "Proxmox (VM/CT)",
    "52:54:00": "QEMU/KVM",
    "00:50:56": "VMware",
    "00:0C:29": "VMware",
    "02:42:AC": "Docker",
    "B8:27:EB": "Raspberry Pi",
    "DC:A6:32": "Raspberry Pi",
    "E4:5F:01": "Raspberry Pi",
    "D8:3A:DD": "Raspberry Pi",
    "2C:CF:67": "Raspberry Pi",
    "00:0C:42": "MikroTik",
    "4C:5E:0C": "MikroTik",
    "64:D1:54": "MikroTik",
    "6C:3B:6B": "MikroTik",
    "B8:69:F4": "MikroTik",
    "CC:2D:E0": "MikroTik",
    "D4:CA:6D": "MikroTik",
    "E4:8D:8C": "MikroTik",
    "18:FD:74": "MikroTik",
    "2C:C8:1B": "MikroTik",
    "48:8F:5A": "MikroTik",
    "74:4D:28": "MikroTik",
    "DC:2C:6E": "MikroTik",
    "C4:AD:34": "MikroTik",
    "08:55:31": "MikroTik",
}

_OUI_FILES = (
    "/usr/share/ieee-data/oui.txt",
    "/usr/share/wireshark/manuf",
    "/usr/share/misc/oui.txt",
)
_oui_cache: dict[str, str] | None = None


def _load_oui(extra: str | None = None) -> dict[str, str]:
    table = dict(_BUILTIN_OUI)
    paths = [extra] if extra else []
    paths += list(_OUI_FILES)
    for p in paths:
        if not p:
            continue
        path = Path(p)
        if not path.is_file():
            continue
        try:
            with path.open(encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    # IEEE : "28-6F-B9   (hex)\t\tNokia Shanghai Bell"
                    if "(hex)" in line:
                        pre, _, name = line.partition("(hex)")
                        key = norm_mac(pre.strip() + "000000")
                        if key:
                            table.setdefault(key[:8], name.strip())
                    # Wireshark manuf : "00:00:0C\tCisco\tCisco Systems, Inc"
                    elif line[:1] not in ("#", "\n") and "\t" in line:
                        parts = line.rstrip("\n").split("\t")
                        if len(parts[0]) == 8:
                            key = parts[0].upper().replace("-", ":")
                            table.setdefault(key, (parts[2] if len(parts) > 2 else parts[1]).strip())
        except OSError:
            continue
        log.debug("Table OUI chargée depuis %s", p)
        break
    return table


def init_oui(extra_path: str | None = None) -> None:
    global _oui_cache
    _oui_cache = _load_oui(extra_path)


def vendor(mac: str | None) -> str | None:
    global _oui_cache
    if not mac:
        return None
    if _oui_cache is None:
        _oui_cache = _load_oui()
    if is_random_mac(mac) and mac[:8] not in _oui_cache:
        return None
    return _oui_cache.get(mac[:8])


def slug(text: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9_.-]+", "-", text.strip()).strip("-").lower()
    return s or "x"
