"""Collecteur Proxmox VE (API REST, jeton en lecture seule).

Création du jeton (sur un nœud) :
    pveum user add netmap@pve
    pveum aclmod / -user netmap@pve -role PVEAuditor
    pveum user token add netmap@pve topo --privsep 0
=> token_id = "netmap@pve!topo", token_secret = <uuid affiché>
"""

from __future__ import annotations

import json
import re
import ssl
import urllib.error
import urllib.parse
import urllib.request

from ..config import ProxmoxConfig
from ..model import Guest, HvNode, HypervisorData
from ..util import log, norm_mac

_QEMU_NIC = re.compile(r"^(?:virtio|e1000e?|rtl8139|vmxnet3|ne2k_pci|i82551|i82557b|i82559er|pcnet)=([0-9A-Fa-f:]{17})")


class PveClient:
    def __init__(self, cfg: ProxmoxConfig):
        self.base = f"https://{cfg.host}:{cfg.port}/api2/json"
        self.headers = {"Authorization": f"PVEAPIToken={cfg.token_id}={cfg.token_secret}"}
        self.timeout = cfg.timeout
        self.ctx = ssl.create_default_context()
        if not cfg.tls_verify:
            self.ctx.check_hostname = False
            self.ctx.verify_mode = ssl.CERT_NONE

    def get(self, path: str):
        req = urllib.request.Request(self.base + path, headers=self.headers)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout, context=self.ctx) as r:
                return json.load(r).get("data")
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"{path} : HTTP {e.code} {e.reason}") from None


def _parse_net(conf: dict, kind: str) -> tuple[list[str], list[int], list[str]]:
    macs, vlans, ips = [], [], []
    for key, val in conf.items():
        if not re.fullmatch(r"net\d+", key) or not isinstance(val, str):
            continue
        opts = dict(p.split("=", 1) for p in val.split(",") if "=" in p)
        mac = None
        if kind == "lxc":
            mac = norm_mac(opts.get("hwaddr"))
            ip = opts.get("ip", "")
            if ip and ip not in ("dhcp", "manual"):
                ips.append(ip.split("/")[0])
        else:
            m = _QEMU_NIC.match(val)
            mac = norm_mac(m.group(1)) if m else None
        if mac:
            macs.append(mac)
        if opts.get("tag", "").isdigit():
            vlans.append(int(opts["tag"]))
    return macs, vlans, ips


def collect(cfg: ProxmoxConfig) -> HypervisorData:
    api = PveClient(cfg)
    status = api.get("/cluster/status") or []
    cluster = next((s.get("name") for s in status if s.get("type") == "cluster"), None) or cfg.host
    data = HypervisorData(cluster=cluster)
    node_ip = {s.get("name"): s.get("ip") for s in status if s.get("type") == "node"}

    for n in api.get("/nodes") or []:
        name = n.get("node")
        online = n.get("status") == "online"
        hv = HvNode(name=name, ip=node_ip.get(name), online=online)
        data.nodes.append(hv)
        if not online:
            continue
        # MAC des interfaces physiques du nœud (si l'API les expose)
        try:
            for iface in api.get(f"/nodes/{name}/network") or []:
                mac = norm_mac(iface.get("hwaddr") or iface.get("mac"))
                if mac and mac not in hv.macs:
                    hv.macs.append(mac)
        except Exception as e:
            log.debug("Proxmox %s network : %s", name, e)

        for kind in ("qemu", "lxc"):
            try:
                guests = api.get(f"/nodes/{name}/{kind}") or []
            except Exception as e:
                data.errors.append(f"{name}/{kind} : {e}")
                continue
            for g in guests:
                vmid = int(g.get("vmid"))
                try:
                    conf = api.get(f"/nodes/{name}/{kind}/{vmid}/config") or {}
                except Exception as e:
                    data.errors.append(f"{name}/{kind}/{vmid} : {e}")
                    conf = {}
                macs, vlans, ips = _parse_net(conf, kind)
                guest = Guest(vmid=vmid, name=g.get("name") or conf.get("hostname") or f"{kind}-{vmid}",
                              type=kind, node=name, status=g.get("status"), macs=macs, vlans=vlans, ips=ips)
                if kind == "qemu" and cfg.guest_agent and g.get("status") == "running" and str(conf.get("agent", "")).startswith(("1", "enabled=1")):
                    try:
                        res = api.get(f"/nodes/{name}/qemu/{vmid}/agent/network-get-interfaces") or {}
                        for itf in res.get("result", []):
                            if itf.get("name") == "lo":
                                continue
                            for a in itf.get("ip-addresses", []):
                                if a.get("ip-address-type") == "ipv4" and a["ip-address"] not in guest.ips:
                                    guest.ips.append(a["ip-address"])
                    except Exception:
                        pass  # agent absent ou arrêté
                data.guests.append(guest)
    return data
