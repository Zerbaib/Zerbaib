"""Données brutes collectées sur chaque équipement (indépendantes du protocole).

Tout est sérialisable en JSON : un scan brut peut être sauvegardé (`netmap scan --dump`)
puis rejoué hors ligne (`netmap build`), pratique pour déboguer.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields


@dataclass
class Port:
    name: str
    type: str = "ether"  # ether | sfp | bond | wifi | other
    mac: str | None = None
    speed_mbps: int | None = None
    up: bool | None = None
    alias: str | None = None
    members: list[str] = field(default_factory=list)  # pour un bond / LAG
    bond: str | None = None  # bond parent si membre
    stp_forwarding: bool | None = None  # False = bloqué par STP/RSTP
    pvid: int | None = None


@dataclass
class Neighbor:
    local_port: str | None
    protocol: str  # lldp | cdp | mndp (ou combinaison "lldp,mndp")
    remote_name: str | None = None
    remote_port: str | None = None
    remote_mac: str | None = None
    remote_ip: str | None = None
    platform: str | None = None
    model: str | None = None
    caps: list[str] = field(default_factory=list)


@dataclass
class FdbEntry:
    mac: str
    port: str
    vlan: int | None = None


@dataclass
class ArpEntry:
    ip: str
    mac: str
    interface: str | None = None


@dataclass
class Lease:
    ip: str
    mac: str
    hostname: str | None = None
    comment: str | None = None


@dataclass
class DeviceData:
    id: str  # nom donné dans la config (stable)
    host: str
    platform: str  # routeros | snmp
    role: str
    name: str | None = None  # identity / sysName
    model: str | None = None
    version: str | None = None
    serial: str | None = None
    macs: list[str] = field(default_factory=list)
    ips: list[str] = field(default_factory=list)
    ports: dict[str, Port] = field(default_factory=dict)
    neighbors: list[Neighbor] = field(default_factory=list)
    fdb: list[FdbEntry] = field(default_factory=list)
    arp: list[ArpEntry] = field(default_factory=list)
    leases: list[Lease] = field(default_factory=list)
    wan_port: str | None = None
    label: str | None = None
    reachable: bool = True
    errors: list[str] = field(default_factory=list)
    duration_s: float | None = None

    def to_dict(self) -> dict:
        d = asdict(self)
        d["ports"] = {k: asdict(v) for k, v in self.ports.items()}
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "DeviceData":
        d = dict(d)
        d["ports"] = {k: _mk(Port, v) for k, v in d.get("ports", {}).items()}
        d["neighbors"] = [_mk(Neighbor, n) for n in d.get("neighbors", [])]
        d["fdb"] = [_mk(FdbEntry, n) for n in d.get("fdb", [])]
        d["arp"] = [_mk(ArpEntry, n) for n in d.get("arp", [])]
        d["leases"] = [_mk(Lease, n) for n in d.get("leases", [])]
        return _mk(cls, d)


@dataclass
class Guest:
    vmid: int
    name: str
    type: str  # qemu | lxc
    node: str
    status: str | None = None
    macs: list[str] = field(default_factory=list)
    vlans: list[int] = field(default_factory=list)
    ips: list[str] = field(default_factory=list)


@dataclass
class HvNode:
    name: str
    ip: str | None = None
    online: bool | None = None
    macs: list[str] = field(default_factory=list)


@dataclass
class HypervisorData:
    cluster: str
    nodes: list[HvNode] = field(default_factory=list)
    guests: list[Guest] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "HypervisorData":
        d = dict(d)
        d["nodes"] = [_mk(HvNode, n) for n in d.get("nodes", [])]
        d["guests"] = [_mk(Guest, g) for g in d.get("guests", [])]
        return _mk(cls, d)


@dataclass
class RawScan:
    ts: str
    devices: list[DeviceData] = field(default_factory=list)
    hypervisors: list[HypervisorData] = field(default_factory=list)
    duration_s: float | None = None

    def to_dict(self) -> dict:
        return {
            "ts": self.ts,
            "duration_s": self.duration_s,
            "devices": [d.to_dict() for d in self.devices],
            "hypervisors": [h.to_dict() for h in self.hypervisors],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "RawScan":
        return cls(
            ts=d["ts"],
            duration_s=d.get("duration_s"),
            devices=[DeviceData.from_dict(x) for x in d.get("devices", [])],
            hypervisors=[HypervisorData.from_dict(x) for x in d.get("hypervisors", [])],
        )


def _mk(cls, d: dict):
    """Construit un dataclass en ignorant les clés inconnues (compatibilité ascendante)."""
    names = {f.name for f in fields(cls)}
    return cls(**{k: v for k, v in d.items() if k in names})
