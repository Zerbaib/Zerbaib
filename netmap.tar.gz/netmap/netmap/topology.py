"""Moteur de topologie : transforme un scan brut en graphe (nœuds + liens).

Ordre de déduction (du plus fiable au moins fiable) :
  1. LLDP / CDP      : protocoles « link-local », le voisin est forcément en direct.
  2. Tables MAC (FDB): deux équipements gérés S:P et D:Q sont reliés en direct si
                       ce que voit S derrière P et ce que voit D derrière Q sont
                       disjoints et couvrent tout le réseau (algorithme classique).
  3. MNDP            : diffusé en broadcast (traverse les switchs) -> utilisé
                       seulement s'il est sans ambiguïté sur le port.
  4. Config          : liens [[link]] ajoutés à la main, port WAN.
Puis les appareils finaux sont placés sur les ports « d'accès » (non-uplink)
où leur MAC est apprise, enrichis par ARP, DHCP, Proxmox et le DNS inverse.
"""

from __future__ import annotations

import ipaddress
import socket
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, wait
from dataclasses import dataclass, field

from .config import Config
from .model import DeviceData, Neighbor, RawScan
from .util import fmt_speed, init_oui, is_multicast_mac, is_random_mac, mac_int, norm_mac, slug, vendor

WAN_ID = "wan"


def _ignored_mac(mac: str | None, hidden: set[str]) -> bool:
    if not mac:
        return True
    return (
        mac.startswith(("00:00:5E:00:01:", "00:00:5E:00:02:"))  # MAC virtuelles VRRP
        or is_multicast_mac(mac)
        or mac in hidden
    )


# --- liens --------------------------------------------------------------------

@dataclass
class Member:
    a_port: str | None
    b_port: str | None
    via: set[str] = field(default_factory=set)


class Links:
    """Liens non orientés entre deux nœuds ; un lien peut avoir plusieurs membres (LAG)."""

    def __init__(self):
        self.by_pair: dict[tuple[str, str], list[Member]] = {}

    def add(self, a: str, a_port: str | None, b: str, b_port: str | None, via: str) -> None:
        if a == b:
            return
        if b < a:
            a, b, a_port, b_port = b, a, b_port, a_port
        members = self.by_pair.setdefault((a, b), [])
        for m in members:
            a_ok = m.a_port == a_port or m.a_port is None or a_port is None
            b_ok = m.b_port == b_port or m.b_port is None or b_port is None
            if a_ok and b_ok:
                m.a_port = m.a_port or a_port
                m.b_port = m.b_port or b_port
                m.via.add(via)
                return
        members.append(Member(a_port, b_port, {via}))

    def has_pair(self, a: str, b: str) -> bool:
        return (min(a, b), max(a, b)) in self.by_pair

    def ports_of(self, node: str) -> set[str]:
        out = set()
        for (a, b), members in self.by_pair.items():
            for m in members:
                if a == node and m.a_port:
                    out.add(m.a_port)
                if b == node and m.b_port:
                    out.add(m.b_port)
        return out

    def fill_remote_port(self, a: str, a_port: str | None, b: str, b_port: str | None, via: str) -> bool:
        """Complète un port manquant sur un lien existant, sans créer de membre."""
        key = (a, b) if a < b else (b, a)
        if key not in self.by_pair:
            return False
        if a > b:
            a_port, b_port = b_port, a_port
        for m in self.by_pair[key]:
            if a_port and m.a_port == a_port and m.b_port is None:
                m.b_port = b_port
                m.via.add(via)
                return True
            if b_port and m.b_port == b_port and m.a_port is None:
                m.a_port = a_port
                m.via.add(via)
                return True
        return True


# --- appareils finaux -----------------------------------------------------------

@dataclass
class Endpoint:
    id: str
    macs: set[str] = field(default_factory=set)
    attach: set[tuple[str, str]] = field(default_factory=set)  # (device_id, port)
    lldp_attach: set[tuple[str, str]] = field(default_factory=set)
    kind: str | None = None
    names: dict[str, str] = field(default_factory=dict)  # source -> nom
    ips: list[str] = field(default_factory=list)
    vlans: set[int] = field(default_factory=set)
    caps: set[str] = field(default_factory=set)
    platform: str | None = None
    model: str | None = None
    note: str | None = None
    status: str | None = None
    parent: str | None = None  # hyperviseur pour une VM / un CT
    guest: dict | None = None

    def add_ip(self, ip: str | None):
        if ip and ip not in self.ips:
            self.ips.append(ip)


_NAME_PRIORITY = ["manual", "proxmox", "dhcp", "lldp", "mndp", "dns", "comment"]


def build(raw: RawScan, cfg: Config, resolve_dns: bool | None = None) -> dict:
    init_oui(cfg.oui_file)
    hidden = set(cfg.hide_macs)
    devs: dict[str, DeviceData] = {d.id: d for d in raw.devices}
    dnode = lambda did: f"dev:{did}"  # noqa: E731

    # --- index des équipements gérés ------------------------------------------
    dev_by_mac: dict[str, str] = {}
    dev_by_ip: dict[str, str] = {}
    dev_by_name: dict[str, str] = {}
    for d in devs.values():
        all_macs = set(d.macs) | {p.mac for p in d.ports.values() if p.mac}
        for m in all_macs:
            if not _ignored_mac(m, hidden):
                dev_by_mac.setdefault(m, d.id)
        dev_by_ip[d.host] = d.id
        for ip in d.ips:
            dev_by_ip.setdefault(ip, d.id)
        for nm in (d.id, d.name):
            if nm:
                dev_by_name.setdefault(nm.lower(), d.id)

    def resolve(n: Neighbor) -> str | None:
        if n.remote_mac and n.remote_mac in dev_by_mac:
            return dev_by_mac[n.remote_mac]
        if n.remote_ip and n.remote_ip in dev_by_ip:
            return dev_by_ip[n.remote_ip]
        if n.remote_name and n.remote_name.lower() in dev_by_name:
            return dev_by_name[n.remote_name.lower()]
        return None

    links = Links()
    direct_neighbors: dict[tuple[str, str], list[Neighbor]] = defaultdict(list)
    mndp_info: dict[str, Neighbor] = {}

    # 1. LLDP / CDP ------------------------------------------------------------
    for d in devs.values():
        for n in d.neighbors:
            protos = set(n.protocol.split(","))
            if not protos & {"lldp", "cdp"}:
                continue
            r = resolve(n)
            if r and r != d.id:
                links.add(dnode(d.id), n.local_port, dnode(r), n.remote_port, "lldp" if "lldp" in protos else "cdp")
            elif not r and n.local_port:
                direct_neighbors[(d.id, n.local_port)].append(n)

    # 2. Inférence par tables MAC ----------------------------------------------
    seen: dict[tuple[str, str], set[str]] = defaultdict(set)
    for d in devs.values():
        for e in d.fdb:
            other = dev_by_mac.get(e.mac)
            if other and other != d.id:
                seen[(d.id, e.port)].add(other)
    universe = set()
    for (s, _p), ds in seen.items():
        universe.add(s)
        universe |= ds
    has_fdb = {d.id for d in devs.values() if d.fdb}
    for (s, p), behind_s in seen.items():
        for target in behind_s:
            if links.has_pair(dnode(s), dnode(target)):
                continue
            if target not in has_fdb:
                if behind_s == {target}:
                    links.add(dnode(s), p, dnode(target), None, "fdb")
                continue
            for (t2, q), behind_t in seen.items():
                if t2 != target or s not in behind_t:
                    continue
                if behind_s.isdisjoint(behind_t) and (behind_s | behind_t) >= universe:
                    links.add(dnode(s), p, dnode(target), q, "fdb")

    # 3. MNDP (sans ambiguïté uniquement) ----------------------------------------
    mndp_by_port: dict[tuple[str, str], set[str]] = defaultdict(set)
    mndp_entries: list[tuple[DeviceData, Neighbor, str | None]] = []
    for d in devs.values():
        for n in d.neighbors:
            protos = set(n.protocol.split(","))
            if protos & {"lldp", "cdp"}:
                continue
            r = resolve(n)
            if r and r != d.id and n.local_port:
                mndp_by_port[(d.id, n.local_port)].add(r)
                mndp_entries.append((d, n, r))
            elif not r and n.remote_mac:
                mndp_info.setdefault(n.remote_mac, n)
    for d, n, r in mndp_entries:
        if len(mndp_by_port[(d.id, n.local_port)]) != 1:
            continue
        if links.has_pair(dnode(d.id), dnode(r)):
            links.fill_remote_port(dnode(d.id), n.local_port, dnode(r), n.remote_port, "mndp")
            continue
        if n.local_port in links.ports_of(dnode(d.id)):
            continue  # port déjà relié à un autre équipement : MNDP vient de plus loin
        links.add(dnode(d.id), n.local_port, dnode(r), n.remote_port, "mndp")

    # 4. WAN ---------------------------------------------------------------------
    for d in devs.values():
        if d.wan_port:
            links.add(dnode(d.id), d.wan_port, WAN_ID, None, "config")

    # Ports « uplink » (vers un autre équipement d'infrastructure)
    uplinks: set[tuple[str, str]] = set()
    for (a, b), members in links.by_pair.items():
        for m in members:
            if a.startswith("dev:") and m.a_port:
                uplinks.add((a[4:], m.a_port))
            if b.startswith("dev:") and m.b_port:
                uplinks.add((b[4:], m.b_port))
    for did, p in list(uplinks):
        port = devs[did].ports.get(p) if did in devs else None
        if port and port.bond:
            uplinks.add((did, port.bond))
        if port and port.members:
            uplinks.update((did, mm) for mm in port.members)

    def access_port(did: str, p: str) -> str:
        """Membre d'un bond -> le bond (on raisonne par LAG)."""
        port = devs[did].ports.get(p)
        return port.bond if port and port.bond else p

    # --- connaissances L3 / Proxmox --------------------------------------------
    ip_of: dict[str, list[str]] = defaultdict(list)
    mac_of_ip: dict[str, str] = {}
    dhcp_name: dict[str, str] = {}
    dhcp_comment: dict[str, str] = {}
    for d in devs.values():
        for a in d.arp:
            if a.ip not in ip_of[a.mac]:
                ip_of[a.mac].append(a.ip)
            mac_of_ip.setdefault(a.ip, a.mac)
        for l in d.leases:
            if l.ip not in ip_of[l.mac]:
                ip_of[l.mac].append(l.ip)
            mac_of_ip.setdefault(l.ip, l.mac)
            if l.hostname:
                dhcp_name.setdefault(l.mac, l.hostname)
            if l.comment:
                dhcp_comment.setdefault(l.mac, l.comment)

    eps: dict[str, Endpoint] = {}
    ep_by_mac: dict[str, str] = {}

    def new_ep(eid: str) -> Endpoint:
        if eid not in eps:
            eps[eid] = Endpoint(id=eid)
        return eps[eid]

    def bind_mac(ep: Endpoint, mac: str):
        if mac in ep_by_mac and ep_by_mac[mac] != ep.id:
            return
        ep.macs.add(mac)
        ep_by_mac[mac] = ep.id

    guest_eps: set[str] = set()
    for hv in raw.hypervisors:
        cl = slug(hv.cluster)
        for node in hv.nodes:
            ep = new_ep(f"pve:{cl}/{node.name}")
            ep.kind = "hypervisor"
            ep.names["proxmox"] = node.name
            ep.status = "ok" if node.online else "offline"
            ep.note = f"Cluster {hv.cluster}"
            ep.add_ip(node.ip)
            for m in node.macs:
                bind_mac(ep, m)
            if node.ip and node.ip in mac_of_ip:
                bind_mac(ep, mac_of_ip[node.ip])
        for g in hv.guests:
            ep = new_ep(f"{'ct' if g.type == 'lxc' else 'vm'}:{cl}/{g.vmid}")
            ep.kind = "ct" if g.type == "lxc" else "vm"
            ep.names["proxmox"] = g.name
            ep.status = g.status
            ep.parent = f"pve:{cl}/{g.node}"
            ep.vlans.update(g.vlans)
            ep.guest = {"vmid": g.vmid, "node": g.node, "type": g.type}
            for ip in g.ips:
                ep.add_ip(ip)
            for m in g.macs:
                bind_mac(ep, m)
            guest_eps.add(ep.id)

    for me in cfg.endpoints:
        ep = eps.get(ep_by_mac.get(me.mac, "")) or new_ep(f"mac:{me.mac}")
        bind_mac(ep, me.mac)
        if me.name:
            ep.names["manual"] = me.name
        if me.kind:
            ep.kind = me.kind
        if me.note:
            ep.note = me.note

    # Voisins LLDP non gérés (serveur avec lldpd, AP, téléphone IP...) : en direct sur le port
    for (did, p), neighs in direct_neighbors.items():
        for n in neighs:
            if n.remote_mac and n.remote_mac in ep_by_mac:
                ep = eps[ep_by_mac[n.remote_mac]]
            elif n.remote_mac:
                ep = new_ep(f"mac:{n.remote_mac}")
                bind_mac(ep, n.remote_mac)
            else:
                ep = new_ep(f"lldp:{slug(n.remote_name or 'inconnu')}")
            if n.remote_name:
                ep.names.setdefault("lldp", n.remote_name)
            ep.caps.update(n.caps)
            ep.platform = ep.platform or n.platform
            ep.model = ep.model or n.model
            ep.add_ip(n.remote_ip)
            ep.lldp_attach.add((did, access_port(did, p)))
            ep.attach.add((did, access_port(did, p)))

    # --- observations FDB sur les ports d'accès --------------------------------
    sightings: dict[str, set[tuple[str, str]]] = defaultdict(set)
    mac_vlans: dict[str, set[int]] = defaultdict(set)
    for d in devs.values():
        for e in d.fdb:
            if _ignored_mac(e.mac, hidden) or e.mac in dev_by_mac:
                continue
            if (d.id, e.port) in uplinks:
                continue
            ap = access_port(d.id, e.port)
            if (d.id, ap) in uplinks:
                continue
            sightings[e.mac].add((d.id, ap))
            if e.vlan:
                mac_vlans[e.mac].add(e.vlan)

    # Uplinks non découverts : un port qui « voit » surtout des MAC présentes
    # sur des ports d'accès d'autres équipements est en réalité un lien inter-switch.
    port_macs: dict[tuple[str, str], set[str]] = defaultdict(set)
    for mac, sp in sightings.items():
        for x in sp:
            port_macs[x].add(mac)
    fake = set()
    for x, macs in port_macs.items():
        shared = sum(1 for m in macs if any(y[0] != x[0] for y in sightings[m]))
        if shared >= 3 and shared / len(macs) >= 0.5:
            fake.add(x)
    if fake:
        for mac in sightings:
            sightings[mac] -= fake
        uplinks |= fake

    guest_seen: dict[str, Counter] = defaultdict(Counter)
    for mac, where in sightings.items():
        if not where:
            continue
        eid = ep_by_mac.get(mac)
        if eid in guest_eps:
            hvid = eps[eid].parent
            for w in where:
                guest_seen[hvid][w] += 1
            eps[eid].vlans |= mac_vlans.get(mac, set())
            continue
        ep = eps[eid] if eid else new_ep(f"mac:{mac}")
        bind_mac(ep, mac)
        ep.attach |= where
        ep.vlans |= mac_vlans.get(mac, set())

    # IP / noms pour tout le monde
    for ep in eps.values():
        for m in sorted(ep.macs):
            for ip in ip_of.get(m, []):
                ep.add_ip(ip)
            if m in dhcp_name:
                ep.names.setdefault("dhcp", dhcp_name[m])
            if m in dhcp_comment:
                ep.names.setdefault("comment", dhcp_comment[m])
            if m in mndp_info:
                n = mndp_info[m]
                if n.remote_name:
                    ep.names.setdefault("mndp", n.remote_name)
                ep.platform = ep.platform or n.platform
                ep.model = ep.model or n.model

    # Cartes réseau « sœurs » : MAC inconnue très proche d'un appareil identifié
    # (serveur multi-ports, NAS en bond...) -> même appareil.
    if cfg.merge_sibling_nics:
        known = [e for e in eps.values() if (e.names or e.ips) and e.id not in guest_eps]
        for ep in list(eps.values()):
            if not ep.id.startswith("mac:") or ep.names or ep.ips or len(ep.macs) != 1 or ep.kind:
                continue
            mac = next(iter(ep.macs))
            if is_random_mac(mac):
                continue
            best = None
            for k in known:
                for km in k.macs:
                    if km[:8] == mac[:8] and 0 < abs(mac_int(km) - mac_int(mac)) <= 8:
                        best = k
                        break
                if best:
                    break
            if best:
                best.macs |= ep.macs
                best.attach |= ep.attach
                best.vlans |= ep.vlans
                for m in ep.macs:
                    ep_by_mac[m] = best.id
                del eps[ep.id]

    # Hyperviseur sans MAC connue : placé là où ses VM sont vues
    for hvid, counter in guest_seen.items():
        ep = eps.get(hvid)
        if ep and not ep.attach and counter:
            top = counter.most_common()
            best_count = top[0][1]
            ep.attach |= {w for w, c in top if c == best_count}

    # Les VM d'un hyperviseur vues sur un port ne sont pas « plusieurs appareils »
    port_eps: dict[tuple[str, str], list[Endpoint]] = defaultdict(list)
    for ep in eps.values():
        if ep.id in guest_eps:
            continue
        for w in ep.attach:
            port_eps[w].append(ep)

    # --- équipements non gérés (switch bureau, AP...) ----------------------------
    pseudo: dict[str, dict] = {}
    behind: dict[str, str] = {}  # ep.id -> nœud intermédiaire
    for (did, p), lst in port_eps.items():
        if len(lst) < 2:
            continue
        lldp_here = [e for e in lst if (did, p) in e.lldp_attach]
        others = [e for e in lst if e not in lldp_here]
        hub = None
        if len(lldp_here) == 1 and (lldp_here[0].caps & {"bridge", "wlan-ap", "router", "repeater"} or len(others) >= cfg.unmanaged_threshold):
            hub = lldp_here[0].id
            if lldp_here[0].kind is None:
                caps = lldp_here[0].caps
                lldp_here[0].kind = "ap" if "wlan-ap" in caps else ("switch-unmanaged" if "bridge" in caps else None)
        elif not lldp_here and len(others) >= max(2, cfg.unmanaged_threshold):
            hub = f"unmanaged:{did}:{p}"
            pseudo[hub] = {"device": did, "port": p}
        if not hub:
            continue
        for e in others:
            if len(e.attach) == 1:
                behind[e.id] = hub

    # --- DNS inverse ---------------------------------------------------------------
    if resolve_dns if resolve_dns is not None else cfg.reverse_dns:
        _reverse_dns([e for e in eps.values() if not e.names and e.ips])

    # --- construction du graphe -----------------------------------------------
    nodes: dict[str, dict] = {}
    edges: dict[tuple[str, str], dict] = {}

    for d in devs.values():
        nodes[dnode(d.id)] = {
            "id": dnode(d.id),
            "label": d.label or d.name or d.id,
            "kind": d.role,
            "managed": True,
            "status": "ok" if d.reachable else "unreachable",
            "ip": d.host,
            "ips": sorted(set([d.host] + d.ips), key=_ip_key),
            "macs": sorted(d.macs)[:8],
            "model": d.model,
            "version": d.version,
            "serial": d.serial,
            "platform": "RouterOS" if d.platform == "routeros" else "SNMP",
            "vendor": "MikroTik" if d.platform == "routeros" else vendor(d.macs[0] if d.macs else None),
            "errors": d.errors,
            "duration_s": d.duration_s,
            "ports": [],
        }
    if any(d.wan_port for d in devs.values()):
        nodes[WAN_ID] = {"id": WAN_ID, "label": cfg.wan_label, "kind": "internet", "managed": False, "status": "ok"}

    for hub, info in pseudo.items():
        nodes[hub] = {
            "id": hub,
            "label": "Équipement non géré",
            "kind": "unmanaged",
            "managed": False,
            "status": "ok",
            "note": f"Déduit : plusieurs appareils derrière {devs[info['device']].label or devs[info['device']].name or info['device']} / {info['port']}",
        }
        links.add(dnode(info["device"]), info["port"], hub, None, "fdb")

    for ep in eps.values():
        if ep.id not in guest_eps and not ep.attach and not ep.parent:
            if not (ep.kind == "hypervisor" or ep.names.get("manual")):
                continue
        nodes[ep.id] = _endpoint_node(ep, cfg, mac_vlans)

    for ep in eps.values():
        if ep.id not in nodes:
            continue
        if ep.id in guest_eps:
            if ep.parent in nodes:
                links.add(ep.parent, None, ep.id, None, "proxmox")
            continue
        hub = behind.get(ep.id)
        if hub and hub in nodes:
            links.add(hub, None, ep.id, None, "fdb")
            continue
        for did, p in ep.attach:
            via = "lldp" if (did, p) in ep.lldp_attach else "fdb"
            links.add(dnode(did), p, ep.id, None, via)

    # Liens manuels
    label_index = {n["label"].lower(): nid for nid, n in nodes.items()}
    for ml in cfg.links:
        a = _manual_ref(ml.a, devs, label_index, ep_by_mac, nodes)
        b = _manual_ref(ml.b, devs, label_index, ep_by_mac, nodes)
        links.add(a, ml.a_port, b, ml.b_port, "manual")

    # Arêtes finales (vitesse, LAG, STP)
    def port_info(nid: str, p: str | None):
        if not p or not nid.startswith("dev:") or nid[4:] not in devs:
            return None
        return devs[nid[4:]].ports.get(p)

    port_peer: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for (a, b), members in links.by_pair.items():
        if a not in nodes or b not in nodes:
            continue
        mlist = []
        for m in members:
            pa, pb = port_info(a, m.a_port), port_info(b, m.b_port)
            speeds = [x.speed_mbps for x in (pa, pb) if x and x.speed_mbps]
            n_members = max(len(pa.members) if pa and pa.members else 1, len(pb.members) if pb and pb.members else 1)
            blocked = any(x is not None and x.stp_forwarding is False for x in (pa, pb))
            mlist.append({
                "source_port": m.a_port,
                "target_port": m.b_port,
                "speed": min(speeds) if speeds else None,
                "lag_members": n_members if n_members > 1 else None,
                "blocked": blocked,
                "via": sorted(m.via),
            })
            if m.a_port:
                port_peer[(a, m.a_port)].append({"node": b, "port": m.b_port})
            if m.b_port:
                port_peer[(b, m.b_port)].append({"node": a, "port": m.a_port})
        kinds = {nodes[a]["kind"], nodes[b]["kind"]}
        if kinds & {"vm", "ct"}:
            kind = "virtual"
        elif WAN_ID in (a, b):
            kind = "wan"
        elif nodes[a].get("managed") and nodes[b].get("managed"):
            kind = "infra"
        else:
            kind = "access"
        speed_sum = sum(x["speed"] or 0 for x in mlist if not x["blocked"]) or None
        lag = len(mlist) > 1 or any(x["lag_members"] for x in mlist)
        vias = sorted({v for x in mlist for v in x["via"]})
        edges[(a, b)] = {
            "id": f"{a}|{b}",
            "source": a,
            "target": b,
            "kind": kind,
            "members": mlist,
            "speed": speed_sum,
            "speed_label": fmt_speed(speed_sum),
            "lag": lag,
            "blocked": all(x["blocked"] for x in mlist),
            "partially_blocked": any(x["blocked"] for x in mlist) and not all(x["blocked"] for x in mlist),
            "via": vias,
            "inferred": not set(vias) & {"lldp", "cdp", "config", "manual", "proxmox"},
        }

    # Vue « ports » des équipements gérés (comme la page Ports d'UniFi)
    for d in devs.values():
        nid = dnode(d.id)
        rows = []
        for p in sorted(d.ports.values(), key=lambda x: _natural(x.name)):
            peers = port_peer.get((nid, p.name), [])
            if p.bond and not peers:
                peers = port_peer.get((nid, p.bond), [])
            rows.append({
                "name": p.name,
                "type": p.type,
                "up": p.up,
                "speed": fmt_speed(p.speed_mbps),
                "alias": p.alias,
                "bond": p.bond,
                "members": p.members,
                "pvid": p.pvid,
                "stp_blocked": p.stp_forwarding is False,
                "uplink": (d.id, p.name) in uplinks,
                "peers": [{"node": x["node"], "label": nodes.get(x["node"], {}).get("label", x["node"]), "port": x["port"]} for x in peers],
                "fdb_count": sum(1 for e in d.fdb if e.port == p.name),
            })
        nodes[nid]["ports"] = rows

    graph = {
        "ts": raw.ts,
        "duration_s": raw.duration_s,
        "nodes": sorted(nodes.values(), key=lambda n: n["id"]),
        "links": sorted(edges.values(), key=lambda e: e["id"]),
        "errors": {d.id: d.errors for d in devs.values() if d.errors}
                  | {f"proxmox:{h.cluster}": h.errors for h in raw.hypervisors if h.errors},
    }
    graph["stats"] = _stats(graph)
    return graph


def _endpoint_node(ep: Endpoint, cfg: Config, mac_vlans) -> dict:
    name = next((ep.names[k] for k in _NAME_PRIORITY if ep.names.get(k)), None)
    macs = sorted(ep.macs)
    primary_mac = macs[0] if macs else None
    vend = vendor(primary_mac)
    rule = None
    for ip in ep.ips:
        rule = _subnet_rule(ip, cfg)
        if rule:
            break
    kind = ep.kind
    if not kind:
        caps = ep.caps
        if "wlan-ap" in caps:
            kind = "ap"
        elif "telephone" in caps:
            kind = "phone"
        elif "router" in caps:
            kind = "router-unmanaged"
        elif "bridge" in caps and "station" not in caps:
            kind = "switch-unmanaged"
        elif rule:
            kind = rule.kind
        elif ep.ips:
            kind = "client"
        else:
            kind = "unknown"
    if not name:
        name = ep.ips[0] if ep.ips else (f"{vend} {primary_mac[-5:]}" if vend and primary_mac else primary_mac or ep.id)
    return {
        "id": ep.id,
        "label": name,
        "kind": kind,
        "managed": False,
        "status": ep.status if ep.status in ("stopped", "offline") else "ok",
        "ip": ep.ips[0] if ep.ips else None,
        "ips": sorted(ep.ips, key=_ip_key),
        "macs": macs,
        "vendor": vend,
        "random_mac": bool(primary_mac and is_random_mac(primary_mac) and not ep.guest),
        "vlans": sorted(ep.vlans),
        "subnet": rule.label if rule and rule.label else None,
        "names": ep.names,
        "platform": ep.platform,
        "model": ep.model,
        "note": ep.note,
        "parent": ep.parent,
        "guest": ep.guest,
        "attach": sorted(f"{d}:{p}" for d, p in ep.attach),
    }


def _subnet_rule(ip: str, cfg: Config):
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return None
    best = None
    for r in cfg.subnets:
        if addr.version == r.network.version and addr in r.network:
            if best is None or r.network.prefixlen > best.network.prefixlen:
                best = r
    return best


def _manual_ref(ref: str, devs, label_index, ep_by_mac, nodes) -> str:
    if ref in devs:
        return f"dev:{ref}"
    mac = norm_mac(ref)
    if mac and mac in ep_by_mac:
        return ep_by_mac[mac]
    if ref.lower() in label_index:
        return label_index[ref.lower()]
    nid = f"manual:{slug(ref)}"
    nodes.setdefault(nid, {"id": nid, "label": ref, "kind": "unknown", "managed": False, "status": "ok",
                           "note": "Ajouté par un lien manuel"})
    return nid


def _reverse_dns(eps: list[Endpoint], timeout: float = 3.0):
    def lookup(ip):
        try:
            return socket.gethostbyaddr(ip)[0]
        except OSError:
            return None
    pool = ThreadPoolExecutor(max_workers=16)
    futures = {pool.submit(lookup, e.ips[0]): e for e in eps}
    done, _ = wait(futures, timeout=timeout)
    for f in done:
        name = f.result()
        if name:
            futures[f].names["dns"] = name.split(".")[0] if not name[0].isdigit() else name
    pool.shutdown(wait=False, cancel_futures=True)


def _ip_key(ip: str):
    try:
        a = ipaddress.ip_address(ip)
        return (a.version, int(a))
    except ValueError:
        return (9, 0)


def _natural(s: str):
    import re
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


def _stats(graph: dict) -> dict:
    c = Counter(n["kind"] for n in graph["nodes"])
    return {
        "nodes": len(graph["nodes"]),
        "links": len(graph["links"]),
        "by_kind": dict(c),
        "managed": sum(1 for n in graph["nodes"] if n.get("managed")),
        "unreachable": [n["label"] for n in graph["nodes"] if n.get("status") == "unreachable"],
    }


def text_tree(graph: dict) -> str:
    """Rendu texte de la topologie (pour le terminal)."""
    nodes = {n["id"]: n for n in graph["nodes"]}
    adj: dict[str, list[tuple[str, dict]]] = defaultdict(list)
    for e in graph["links"]:
        adj[e["source"]].append((e["target"], e))
        adj[e["target"]].append((e["source"], e))
    order = {"internet": 0, "router": 1, "switch": 2, "ap": 3}
    roots = [n for n in nodes if nodes[n]["kind"] == "internet"] or \
            [n for n in nodes if nodes[n]["kind"] == "router"] or \
            sorted(nodes, key=lambda n: (not nodes[n].get("managed"), -len(adj[n])))[:1]
    lines: list[str] = []
    visited: set[str] = set()

    def label(nid):
        n = nodes[nid]
        extra = f" [{n['ip']}]" if n.get("ip") else ""
        st = " (injoignable)" if n.get("status") == "unreachable" else ""
        return f"{n['label']} <{n['kind']}>{extra}{st}"

    def edge_txt(e, frm):
        parts = []
        for m in e["members"]:
            sp, tp = (m["source_port"], m["target_port"]) if e["source"] == frm else (m["target_port"], m["source_port"])
            parts.append(f"{sp or '?'}→{tp or '?'}")
        s = ", ".join(parts)
        if e["speed_label"]:
            s += f" {e['speed_label']}"
        if e["blocked"]:
            s += " [STP bloqué]"
        if e["inferred"]:
            s += " (déduit)"
        return s

    def walk(nid, prefix, edge, frm):
        visited.add(nid)
        head = f"{edge_txt(edge, frm)} · " if edge else ""
        lines.append(f"{prefix}{head}{label(nid)}")
        children = [(t, e) for t, e in adj[nid] if t not in visited]
        children.sort(key=lambda x: (order.get(nodes[x[0]]["kind"], 9), nodes[x[0]]["label"].lower()))
        for t, e in children:
            if t in visited:
                lines.append(f"{prefix}    ↺ {edge_txt(e, nid)} · {nodes[t]['label']} (lien redondant)")
                continue
            walk(t, prefix + "    ", e, nid)

    for r in roots:
        if r not in visited:
            walk(r, "", None, None)
    for n in sorted(nodes):
        if n not in visited:
            walk(n, "", None, None)
    return "\n".join(lines)
