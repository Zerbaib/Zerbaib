/* Disposition hiérarchique façon UniFi : Internet > routeurs > switchs > appareils.
 * Les appareils « feuilles » d'un même parent sont rangés en grille sous lui,
 * les sous-arbres (switch en cascade, hyperviseur + VM) en dessous.
 * Utilisable dans le navigateur (window.NetmapLayout) et sous Node (tests). */
(function (root) {
  "use strict";

  const RANK = {
    internet: 0, router: 1, switch: 2, "router-unmanaged": 2, ap: 3, "switch-unmanaged": 3,
    unmanaged: 3, hypervisor: 4, server: 5, nas: 5, management: 6, client: 7, phone: 7,
    printer: 7, tv: 7, iot: 7, vm: 8, ct: 8, unknown: 9,
  };
  const INFRA = new Set(["internet", "router", "switch", "ap", "unmanaged", "switch-unmanaged", "router-unmanaged"]);
  const SIZE = { node: 120, cellW: 118, cellH: 104, vmCellW: 100, vmCellH: 86, gapX: 40, level: 150, leafTop: 112 };

  function rank(n) { return RANK[n.kind] ?? 9; }

  function compute(graph, opts) {
    opts = opts || {};
    const maxCols = opts.maxCols || 6;
    const nodes = new Map(graph.nodes.map((n) => [n.id, n]));
    const adj = new Map();
    for (const id of nodes.keys()) adj.set(id, []);
    for (const l of graph.links) {
      if (!nodes.has(l.source) || !nodes.has(l.target)) continue;
      adj.get(l.source).push({ to: l.target, link: l });
      adj.get(l.target).push({ to: l.source, link: l });
    }

    // Racines : Internet, sinon routeurs, sinon l'équipement géré le plus connecté
    let roots = [...nodes.values()].filter((n) => n.kind === "internet").map((n) => n.id);
    if (!roots.length) roots = [...nodes.values()].filter((n) => n.kind === "router").map((n) => n.id);
    if (!roots.length) {
      const managed = [...nodes.values()].filter((n) => n.managed);
      const pool = managed.length ? managed : [...nodes.values()];
      pool.sort((a, b) => adj.get(b.id).length - adj.get(a.id).length);
      roots = pool.slice(0, 1).map((n) => n.id);
    }

    const parent = new Map();
    const kids = new Map();
    for (const id of nodes.keys()) kids.set(id, []);
    const visited = new Set(roots);
    const sortNb = (list) => list.sort((a, b) => rank(nodes.get(a.to)) - rank(nodes.get(b.to)) ||
      String(nodes.get(a.to).label).localeCompare(String(nodes.get(b.to).label), "fr", { numeric: true }));

    // Parcours en largeur : d'abord l'infrastructure par les liens actifs,
    // puis les appareils, puis ce qui reste (liens bloqués par STP).
    function bfs(allowBlocked) {
      let frontier = [...visited].filter((id) => INFRA.has(nodes.get(id).kind) || roots.includes(id));
      while (frontier.length) {
        const next = [];
        for (const u of frontier) {
          const uk = nodes.get(u).kind;
          const uInfra = INFRA.has(uk) || roots.includes(u);
          for (const { to, link } of sortNb([...adj.get(u)])) {
            if (visited.has(to)) continue;
            if (link.blocked && !allowBlocked) continue;
            const tn = nodes.get(to);
            const virtual = tn.kind === "vm" || tn.kind === "ct";
            // un appareil n'est jamais « parent » d'un équipement réseau ;
            // seul un hyperviseur porte des VM/CT
            if (!uInfra && !(uk === "hypervisor" && virtual)) continue;
            if (virtual && uk !== "hypervisor") continue;
            visited.add(to);
            parent.set(to, u);
            kids.get(u).push(to);
            next.push(to);
          }
        }
        frontier = next;
      }
    }
    bfs(false);
    // VM / CT sous leur hyperviseur
    for (const n of nodes.values()) {
      if ((n.kind === "vm" || n.kind === "ct") && !visited.has(n.id) && n.parent && nodes.has(n.parent) && visited.has(n.parent)) {
        visited.add(n.id); parent.set(n.id, n.parent); kids.get(n.parent).push(n.id);
      }
    }
    bfs(true);
    // Composantes isolées : nouvelles racines
    for (const n of [...nodes.values()].sort((a, b) => rank(a) - rank(b))) {
      if (visited.has(n.id)) continue;
      roots.push(n.id); visited.add(n.id);
      const stack = [n.id];
      while (stack.length) {
        const u = stack.pop();
        for (const { to } of adj.get(u)) {
          if (visited.has(to)) continue;
          visited.add(to); parent.set(to, u); kids.get(u).push(to); stack.push(to);
        }
      }
    }

    const cmp = (a, b) => rank(nodes.get(a)) - rank(nodes.get(b)) ||
      String(nodes.get(a).label).localeCompare(String(nodes.get(b).label), "fr", { numeric: true });
    const isLeaf = (id) => kids.get(id).length === 0 && !INFRA.has(nodes.get(id).kind);

    const box = new Map();
    function measure(id) {
      const ch = kids.get(id).slice().sort(cmp);
      const leaves = ch.filter(isLeaf);
      const subs = ch.filter((c) => !isLeaf(c));
      const virtual = leaves.length && leaves.every((c) => ["vm", "ct"].includes(nodes.get(c).kind));
      const cw = virtual ? SIZE.vmCellW : SIZE.cellW;
      const chh = virtual ? SIZE.vmCellH : SIZE.cellH;
      const cols = Math.min(leaves.length, virtual ? Math.max(3, maxCols - 1) : maxCols);
      const rows = cols ? Math.ceil(leaves.length / cols) : 0;
      const leafW = cols * cw;
      let subW = 0;
      for (const s of subs) subW += measure(s) + SIZE.gapX;
      if (subs.length) subW -= SIZE.gapX;
      const w = Math.max(SIZE.node, leafW, subW);
      box.set(id, { w, leaves, subs, cols, rows, cw, chh, leafW, subW });
      return w;
    }

    const pos = {};
    function place(id, x0, y) {
      const b = box.get(id);
      pos[id] = { x: x0 + b.w / 2, y };
      if (b.leaves.length) {
        const lx0 = x0 + (b.w - b.leafW) / 2;
        b.leaves.forEach((c, i) => {
          const col = i % b.cols;
          const row = Math.floor(i / b.cols);
          const inRow = Math.min(b.cols, b.leaves.length - row * b.cols);
          const shift = ((b.cols - inRow) * b.cw) / 2; // dernière ligne centrée
          pos[c] = { x: lx0 + shift + col * b.cw + b.cw / 2, y: y + SIZE.leafTop + row * b.chh };
        });
      }
      let ySub = y + SIZE.level;
      if (b.leaves.length) ySub = y + SIZE.leafTop + b.rows * b.chh + SIZE.level * 0.55;
      let x = x0 + (b.w - b.subW) / 2;
      for (const s of b.subs) {
        place(s, x, ySub);
        x += box.get(s).w + SIZE.gapX;
      }
      // Parent centré au-dessus de ses sous-arbres (quand il n'a pas de grille d'appareils)
      if (b.subs.length && !b.leaves.length) {
        pos[id].x = (pos[b.subs[0]].x + pos[b.subs[b.subs.length - 1]].x) / 2;
      }
    }

    // Plusieurs routeurs sous Internet : même ligne, côte à côte
    roots.sort(cmp);
    let x = 0;
    for (const r of roots) {
      const w = measure(r);
      place(r, x, 0);
      x += w + SIZE.gapX * 2;
    }
    return { positions: pos, parent: Object.fromEntries(parent), roots };
  }

  const api = { compute, RANK, INFRA };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.NetmapLayout = api;
})(typeof window !== "undefined" ? window : globalThis);
